# WPSBot 3.3.6 - Startup readiness fix

## Fixed
- Downloader prewarm remains disabled so startup does not compete with the first command.
- `yt-dlp` is initialized only when a download command is actually used.
- Release version is synchronized to `3.3.6` to prevent deploying a stale ZIP.

# Chills 3.3.12 - Console konsisten berwarna (bukan cuma chat log) - 28 Agustus 2026

## Changed
- `out()`/`ui.info/ok/warn/error` di `src/utils/logger.js` sekarang pakai
  chalk truecolor per level (cyan/hijau/kuning/merah) — sebelumnya cuma
  `ui.chatLog` (kotak GROUP/PRIVATE) yang berwarna, sisanya (startup,
  connect, disconnect, command error) tampil polos hitam-putih.
- `ui.box()` sekarang punya border berwarna (default cyan, bisa dikustom
  per pemanggilan). Padding dihitung dari teks mentah SEBELUM dibungkus
  chalk supaya kode ANSI (invisible tapi tetap dihitung karakter) tidak
  bikin box miring — diverifikasi manual pakai stub chalk yang beneran
  hasilkan ANSI code, semua baris box terbukti sama lebar setelah kode
  ANSI di-strip.
- Baris boot pertama (`${botName} v${botVersion} — booting...`) yang tadinya
  teks polos sekarang pakai `ui.box()` juga, jadi kesan pertama pas bot
  nyala di console Pterodactyl sudah rapi dari baris pertama.

# Chills 3.3.12 - Menu duplikat, tagall/hidetag, stderr subprocess bocor - 28 Agustus 2026

## Fixed
- **Menu masih menampilkan command duplikat.** Audit AI sebelumnya cuma cek
  `FEATURE_COMMANDS`/`ALIASES` (dispatch level) dan menyimpulkan semua alias
  sudah rapi — ternyata `menu.js` (presentation level) masih menampilkan 6
  baris yang deskripsinya SENDIRI mengaku "Alias X" tapi tetap dikasih baris
  terpisah di `!allmenu`: `!hdvideo` ("Alias enhancement video"), `!download`
  ("Alias download media"), `!ytmp3` ("Alias audio YouTube"), `!fakequote`
  ("Alias fake chat"), `!say` ("Alias TTS"), `!animesearch` ("Alias pencarian
  anime"). Baris-baris ini dihapus dari menu; command-nya sendiri tetap
  berfungsi sebagai alias tersembunyi (persis pola `!s`/`!stiker` yang sudah
  benar sejak 3.3.11) — jadi tidak ada perilaku yang hilang, cuma menu yang
  tidak lagi dobel.
- **`!hidetag` ternyata 100% kode yang sama dengan `!tagall`**, padahal
  deskripsi menu sendiri sudah lama bilang "tanpa daftar teks" — bukan alias
  yang disengaja, tapi fitur yang belum betulan diimplementasikan. Sekarang
  `!hidetag` benar-benar tidak menampilkan daftar @tag di teks (`!tagall`
  masih menampilkan), tapi `mentions` tetap diisi semua peserta di kedua
  command supaya semua tetap ke-notify seperti biasa.
- **stderr mentah dari yt-dlp/ffmpeg bocor ke console DAN ke pesan error
  WhatsApp tanpa dibersihkan** — kemungkinan besar ini sumber "console
  Pterodactyl kebanjiran random string" yang dilaporkan. `ffmpeg` terutama
  menulis progress overwrite pakai `\r` tanpa newline (`frame=... fps=...`
  berulang ribuan kali) dan kadang ANSI escape code; kode lama slice mentah
  N-karakter-terakhir dari buffer itu lalu bungkus langsung ke `new
  Error(...)`, gampang kepotong di tengah sequence dan tampil acak. Ditambah
  helper `cleanProcessOutput()` (`src/utils/bin.js`) yang strip ANSI +
  karakter kontrol, ambil beberapa baris teks terakhir yang benar-benar
  terbaca, dibatasi 500 karakter. Dipasang di SEMUA titik yang punya pola
  sama: `src/services/downloader.js` (yt-dlp), `src/services/media.js`
  (ffmpeg sticker), `src/services/banner.js` (ffmpeg banner),
  `src/services/menu-card.js` (ffmpeg menu card).

## Test
- `test/core.test.js`: assert menu tidak lagi memuat teks "Alias enhancement
  video" / "Alias download media" / dst; test baru untuk `cleanProcessOutput`
  (strip ANSI, strip `\r`, hasil tetap terbaca, panjang dibatasi).
- Diverifikasi via smoke test terpisah (fetch/child_process di-mock):
  `!tagall` menampilkan daftar @tag + `mentions` berisi semua peserta;
  `!hidetag` TIDAK menampilkan daftar @tag tapi `mentions` tetap berisi
  semua peserta (tetap notify); `cleanProcessOutput` diuji dengan simulasi
  stderr ffmpeg asli (progress `\r` berulang + ANSI + baris error) dan
  dengan 500 baris progress spam sekaligus — hasil akhir tetap pendek &
  terbaca. Regresi `!ai`/`!gemini`/`!groq` dari perbaikan sebelumnya dicek
  ulang, tidak ada yang kesenggol.

# Chills 3.3.12 - Gemini + Groq (dua provider bernama jelas, bukan generic slot) - 28 Agustus 2026

## Fixed
- Root cause "Gemini sering error" ditemukan lewat riset ulang: model `gemini-2.0-flash`
  yang di-hardcode sudah resmi di-retire Google per 1 Juni 2026 — bukan soal rate limit
  atau format API key seperti dugaan sebelumnya. Sejak itu setiap panggilan Gemini gagal
  dan diam-diam jatuh ke fallback.
- Kegagalan tiap provider sekarang dicatat dengan alasan spesifik (`Gemini: HTTP 429`,
  `Groq: API key belum diisi`, dst) dan alasan itu dikirim balik ke WhatsApp kalau semua
  provider gagal — sebelumnya cuma "Semua provider AI tidak mengembalikan jawaban" tanpa
  detail, harus buka log debug Pterodactyl untuk tahu penyebabnya.
- Komentar `settings.js` yang saling bertentangan soal format key Gemini (`AQ.Ab...`)
  dihapus; hanya versi yang benar (kedua format valid) yang tersisa.

## Changed
- `!ai` sekarang otomatis coba Gemini dulu, fallback ke Groq kalau Gemini gagal/kosong —
  menggantikan generic OpenAI-compatible slot yang sebelumnya berdefault ke DeepSeek.
- `!gemini` dan `!groq` jadi command sungguhan yang memaksa satu provider tertentu.
  Sebelumnya `!gemini` cuma alias tersembunyi yang memanggil handler sama persis dengan
  `!ai` (begitu juga `!chatgpt`/`!openai`/`!cai`/`!blackbox`/`!blackboxai` — none of
  mereka pernah benar-benar menghubungi ChatGPT/OpenAI/Character.AI/BlackboxAI).
- `!chatgpt`, `!openai`, `!cai`, `!blackbox`, `!blackboxai` dihapus total dari
  `FEATURE_COMMANDS` — bukan cuma disembunyikan dari menu (itu sudah terjadi sejak
  3.3.11), sekarang command-nya sendiri tidak lagi dikenali bot.
- `geminiModel` dan `groqModel` sekarang env var (`GEMINI_MODEL` / `GROQ_MODEL`),
  bukan hardcode — supaya kalau Google/Groq pensiunkan model lagi, tinggal ganti env
  var di Pterodactyl tanpa redeploy kode.
- Fallback publik `zenzxz`/`btch.us.kg` dihapus dari rantai `!ai` — sekarang murni
  2 provider yang diminta: Gemini dan Groq.
- Slot generic `AI_API_URL`/`DEEPSEEK_API_URL`/`DEEPSEEK_API_KEY`/`DEEPSEEK_MODEL`/
  `OPENROUTER_API_KEY` dihapus, diganti `GROQ_API_KEY`/`GROQ_MODEL` (tetap baca
  `AI_API_KEY`/`AI_MODEL` lama sebagai fallback kompatibilitas).
- Menu `AI` menampilkan `!gemini` dan `!groq` sebagai entry baru yang sah (real
  provider, bukan alias palsu lagi).

## Audit command duplikat (diminta user, hasil: sudah bersih di luar AI)
- Semua alias command lain (`!s`/`!stiker`/`!sticker`, `!aimage`/`!aiimage`/`!imagine`,
  `!say`/`!tts`/`!gtts`, `!rvo`/`!readviewonce`/`!viewonce`, grup stalk, dll) diperiksa
  satu per satu: semuanya sudah 1 implementasi dengan banyak nama pemicu (bukan kode
  terduplikasi), sebagian besar sudah dirapikan di 3.3.11. Satu-satunya kasus command
  yang MENGAKU beda tapi sebenarnya 100% handler yang sama adalah grup AI di atas —
  itu yang dibenahi di versi ini.

## Test
- `test/core.test.js`: assert `FEATURE_COMMANDS` tidak lagi berisi `chatgpt`/`openai`/
  `cai`/`blackbox`/`blackboxai`, dan menu menampilkan `!gemini`/`!groq` dengan benar.
- Diverifikasi dengan stub lokal (`node --test` beneran jalan, bukan cuma `node --check`)
  + smoke test terpisah yang mock `fetch` untuk membuktikan: `!ai` pakai Gemini dulu dan
  tidak memanggil Groq kalau Gemini sukses; fallback ke Groq baru terjadi kalau Gemini
  gagal; `!gemini`/`!groq` tidak diam-diam fallback ke provider lain; pesan error saat
  keduanya gagal menyebut alasan spesifik masing-masing provider.

# Chills 3.3.12 - Configurable AI provider

## Fixed
- `!ai` can use an OpenAI-compatible endpoint configured through environment variables.
- DeepSeek-compatible defaults are available without adding a new command.
- Provider HTTP errors, empty answers, and network failures are logged.

# Chills 3.3.11 - AI and download command cleanup

## Fixed
- `!dl` can download a URL from a replied message, not only replied media.
- AI providers retry temporary server failures and log non-OK/empty responses.

## Changed
- `!ai` is the only AI chat entry shown in the menu; old aliases remain compatible.
- `!sticker` is the only sticker entry shown; `!s` and `!stiker` remain compatible aliases.

# Chills 3.3.10 - Complete preflight

## Fixed
- Bootstrap now checks every dependency from `dependencies` and `optionalDependencies` before importing the bot.
- Pairing is requested only after package resolution and preflight complete.
- Native optional packages may fail at feature load without blocking WhatsApp pairing.

# Chills 3.3.9 - Stability test baseline

## Added
- Built-in Node test runner for startup, JID, message parser, AFK, and queue regressions.

## Fixed
- Downloader prewarm is disabled again to keep startup responsive.

# WPSBot 3.3.8 - Media reply fix

## Fixed
- `!convert mp3` now recognizes and downloads replied audio messages.
- Audio media uses the same input-size limit as image/video media.

# WPSBot 3.3.7 - Preflight before pairing

## Fixed
- Startup now checks required packages before importing the WhatsApp bot.
- Missing packages are installed once before pairing code is requested.
- Startup progress is shown in the panel; no automatic reconnect was added.
- Launcher uses its own project directory even when Pterodactyl starts it from another working directory.
- Optional sticker packages are not allowed to block pairing when native sharp is unavailable.

# WPSBot 3.3.5 — Duplicate Event Fix

## Fixed
- Duplicate `messages.upsert` events are ignored by chat and message ID.
- Personal-bot cooldown remains disabled without allowing duplicate commands.

## Deployment
- Confirm the startup log reports `チル v3.3.5` after replacing the old package.

# WPSBot 3.3.4 — Maintenance Update

## Changed
- Global command cooldown disabled for personal-bot usage.
- Cooldown map is bypassed when `commandCooldownMs` is `0`.
- Version synchronized to `3.3.4`.

## Scope
- No new features added; existing AFK, media, menu, and command flows remain unchanged.
- AFK notification was shortened to keep only useful status information.

# WPSBot 3.3.0
# WPSBot 3.2.1

## Menu / UX
- `!menu` kembali menjadi landing page singkat.
- `!allmenu` sekarang berupa teks lengkap bergaya ALYA: kategori, command, dan deskripsi.
- `!help` dan `!info` digabung menjadi satu command center.
- `!info` menjadi alias `!help`.
- Menu tidak lagi memakai selector sebagai output utama `!allmenu`.
- Kategori tetap tersedia lewat command seperti `!downloadmenu`, `!aimenu`, `!messagemenu`, `!groupmenu`, dan lainnya.
- Menu catalog hanya menampilkan command yang memang ditangani WPSBot; command ALYA yang tidak ada di WPSBot tidak dipalsukan.

## Command guide
- Download tanpa URL sekarang membalas contoh `!dl <link>` / `!mp3 <link>`.
- `!help` menampilkan info bot, quick usage command utama, serta kontak bantuan.

## Validasi
- Seluruh source yang tercakup script `npm run check` lolos `node --check`.
- ZIP integrity diverifikasi setelah packaging.

## 3.3.0 — Performance Booster + Spotify
- Added bounded downloader queue (`downloadConcurrency`) to prevent simultaneous heavy jobs from saturating the container.
- Added downloader warm-up/singleton initialization so repeated downloads reuse the same yt-dlp/ffmpeg readiness promise.
- Throttled temp sweeps to avoid scanning the temp directory on every download.
- Added `!booster` and `!supporter` performance diagnostics.
- Added Spotify search and metadata (`!spotify`, `!spotifyinfo`, `!spotifyembed`) using official API credentials supplied through environment variables, with short-lived result/token caching.
- Spotify is not presented as a fake downloader; unofficial third-party ripping endpoints are not bundled.
- Kept existing 3.2.1 feature pack and ALYA-style full-text `!allmenu` as the base.


## 3.3.2 — Feature dispatcher fix
- Fixed a routing bug in `index.js` where `FEATURE_COMMANDS` and category-menu checks were placed inside the `switch` body. Unmatched command names never reached those checks.
- Commands such as `!rvo`, `!hd`, `!removebg`, `!ai`, `!tagall`, and other feature-pack commands are now evaluated before the switch.
- `!menu`, `!help`, `!allmenu`, downloader, Spotify, status, delete, sticker, and converter routes remain on the normal switch path.
- Version bumped to 3.3.2.


# 3.3.3 — Feature Audit + UI Polish
- Audited menu entries against actual dispatch/handlers; removed `!img2prompt` from the public catalog because it is intentionally unconfigured rather than pretending it works.
- `!help` remains the single visible help/info entry; `!info` stays only as a backward-compatible hidden alias.
- Added `!welcome` to the full catalog.
- Spotify URL lookup now falls back to public oEmbed metadata when Web API credentials are unavailable; title search still requires Web API credentials.
- Reworked the `!menu` card to use the supplied banner frame as a background with a translucent overlay, custom Chill/QueerStreet/Zahraaa fonts, profile block, quick access, and version/access/mode information.
- Version synchronized to 3.3.3 in package.json and settings.js.

## v14.3 — fix.md patch list (26 Agustus 2026)
- FIX 2: alias map `ALIASES` + `normalizeCommand()` di index.js, semua `case` duplikat dihapus (17 case tersisa). Command milik CATEGORY_ALIASES / FEATURE_COMMANDS sengaja tidak dinormalisasi.
- FIX 3: `!dl` tanpa argumen + reply media → `src/commands/download-reply.js` (image/video/audio/sticker/document, termasuk unwrap view-once & ephemeral).
- FIX 4: `fetchAnime()` — retry 2x + backoff ke Jikan, fallback Kitsu, hasil dinormalisasi ke satu format.
- FIX 1: `bannerCaptionLimit` 4000 → 8000 (banner `!allmenu` kembali muncul).
- FIX 5: empty catch di features.js diganti `logger.debug` (remini vyro, uselessfacts, JSON parse).
- FIX 6/7/8: sudah ada di v14.2 (timeout `groupMetadata`, TaskQueue timeout, pesan TikTok blokir IP) — diverifikasi.
- FIX 9: pesan error `!rvo` diperjelas (CDN expired 5-30 menit + solusi).
- Catatan Gemini: komentar settings.js diperbarui — key `AIza...` dan `AQ.Ab...` sama-sama valid.
