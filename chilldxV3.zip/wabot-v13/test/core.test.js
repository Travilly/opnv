import test from 'node:test'
import assert from 'node:assert/strict'

import { settings, normalizeOwnerJid } from '../settings.js'
import {
  getQuotedMessage,
  messageText,
  parseCommand,
  unwrapMessage
} from '../src/utils/message.js'
import { extractDownloadUrl } from '../src/commands/download-reply.js'
import { allMenuText } from '../src/commands/menu.js'
import { FEATURE_COMMANDS } from '../src/commands/features.js'
import { cleanProcessOutput } from '../src/utils/bin.js'
import { formatDuration, isReturnPhrase } from '../src/services/afk.js'
import { downloadQueue } from '../src/services/performance.js'

test('startup settings keep downloader lazy and reconnect disabled', () => {
  assert.equal(settings.botName, 'チル')
  assert.equal(settings.prewarmDownloader, false)
  assert.equal(settings.autoReconnect, false)
})

test('owner JID normalization supports device suffixes', () => {
  assert.equal(normalizeOwnerJid('628123456789:7@s.whatsapp.net'), '628123456789@s.whatsapp.net')
  assert.equal(normalizeOwnerJid('628123456789'), '628123456789@s.whatsapp.net')
})

test('message parser handles commands and quoted audio', () => {
  assert.deepEqual(parseCommand('!convert mp3'), {
    command: 'convert',
    args: ['mp3'],
    rawArgs: 'mp3'
  })
  const quoted = { audioMessage: { mimetype: 'audio/ogg' } }
  const message = { audioMessage: { contextInfo: { quotedMessage: quoted } } }
  assert.equal(getQuotedMessage(message), quoted)
  assert.equal(messageText({ imageMessage: { caption: ' !sticker cat ' } }), '!sticker cat')
  assert.equal(unwrapMessage({ ephemeralMessage: { message: { conversation: '!menu' } } }).conversation, '!menu')
})

test('download reply extracts URL and menu exposes canonical commands, no redundant alias rows', () => {
  assert.equal(extractDownloadUrl('lihat https://youtu.be/test).'), 'https://youtu.be/test')
  const menu = allMenuText()
  assert.match(menu, /!ai <pertanyaan>/)
  assert.match(menu, /!gemini <pertanyaan>/)
  assert.match(menu, /!groq <pertanyaan>/)
  assert.match(menu, /!sticker/)
  assert.doesNotMatch(menu, /!chatgpt|!openai <pertanyaan>|!cai <pertanyaan>|!blackbox/)
  // Baris menu yang cuma alias (mis. "!hdvideo — Alias enhancement video")
  // dulu tampil sebagai command terpisah di !allmenu meski deskripsinya
  // sendiri ngaku "Alias ..." — sekarang hanya nama kanonik yang tampil.
  assert.doesNotMatch(menu, /Alias enhancement video|Alias download media|Alias audio YouTube|Alias fake chat|Alias TTS|Alias pencarian anime/)
})

test('AI command set only exposes real providers — no fake chatgpt/openai/cai/blackbox aliases', () => {
  for (const real of ['ai', 'gemini', 'groq']) {
    assert.equal(FEATURE_COMMANDS.has(real), true, `!${real} harus tetap terdaftar`)
  }
  for (const fake of ['chatgpt', 'openai', 'cai', 'blackbox', 'blackboxai']) {
    assert.equal(FEATURE_COMMANDS.has(fake), false, `!${fake} tidak boleh terdaftar lagi (dulu diam-diam manggil handler yang sama dengan !ai)`)
  }
})

test('cleanProcessOutput strips ANSI/control chars from yt-dlp/ffmpeg stderr and bounds length', () => {
  const raw = 'frame=1 fps=25 size=1kB\rframe=2 fps=25 size=2kB\r\x1b[1;31mError:\x1b[0m Conversion failed!\n'
  const out = cleanProcessOutput(raw)
  assert.ok(!out.includes('\x1b'), 'ANSI escape code harus dibuang')
  assert.ok(!out.includes('\r'), 'carriage return progress-bar harus dibuang')
  assert.match(out, /Conversion failed!/)
  assert.equal(cleanProcessOutput(''), 'Tidak ada detail dari proses (exit tanpa output).')
  const huge = 'x'.repeat(5000)
  assert.ok(cleanProcessOutput(huge).length <= 500, 'harus dibatasi panjangnya')
})

test('AFK helpers format duration and return phrases', () => {
  assert.equal(formatDuration(65_000), '1m 5s')
  assert.equal(isReturnPhrase('aku kembali guys'), true)
  assert.equal(isReturnPhrase('aku kembali sekarang juga nanti'), false)
})

test('download queue returns task result and releases its slot', async () => {
  const result = await downloadQueue.add(async () => 'ok', 1_000)
  assert.equal(result, 'ok')
  assert.equal(downloadQueue.running, 0)
  assert.equal(downloadQueue.size, 0)
})
