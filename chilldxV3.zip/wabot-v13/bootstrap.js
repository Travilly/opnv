import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const ROOT = path.dirname(fileURLToPath(import.meta.url))
process.chdir(ROOT)
const PACKAGE_FILE = path.join(ROOT, 'package.json')

async function showProgress(label, action) {
  const frames = ['|', '/', '-', '\\']
  let index = 0
  let active = true
  const timer = setInterval(() => {
    if (active) process.stdout.write(`\r${frames[index++ % frames.length]} ${label}`)
  }, 120)
  try {
    return await action()
  } finally {
    active = false
    clearInterval(timer)
    process.stdout.write(`\r✓ ${label}\n`)
  }
}

function packageNames(manifest) {
  return [...new Set([
    ...Object.keys(manifest.dependencies || {}),
    ...Object.keys(manifest.optionalDependencies || {})
  ])]
}

async function missingPackages(manifest) {
  const missing = []
  for (const name of packageNames(manifest)) {
    try {
      await import.meta.resolve(name)
    } catch {
      missing.push(name)
    }
  }
  return missing
}

async function installMissing(packages) {
  if (!packages.length) return
  const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm'
  const result = spawnSync(npm, [
    'install',
    '--omit=dev',
    '--no-audit',
    '--no-fund',
    ...packages
  ], { cwd: ROOT, stdio: 'inherit' })
  if (result.error) throw result.error
  if (result.status !== 0) throw new Error(`npm install gagal dengan exit code ${result.status}`)
}

async function main() {
  if (!fs.existsSync(PACKAGE_FILE)) throw new Error(`package.json tidak ditemukan di ${ROOT}`)
  const manifest = JSON.parse(fs.readFileSync(PACKAGE_FILE, 'utf8'))
  const packages = packageNames(manifest)

  process.stdout.write('\nチル startup preflight\n')
  const missing = await showProgress('Memeriksa semua package...', () => missingPackages(manifest))
  if (missing.length) {
    process.stdout.write(`Package belum terinstall: ${missing.join(', ')}\n`)
    await showProgress('Menginstall package yang kurang...', () => installMissing(missing))
  } else {
    process.stdout.write('Semua package sudah siap.\n')
  }

  await showProgress('Menyiapkan bot sebelum pairing...', async () => {
    for (const name of packages) {
      try {
        await import.meta.resolve(name)
      } catch {
        throw new Error(`Package ${name} belum tersedia setelah install`)
      }
    }
  })
  process.stdout.write('Preflight selesai. Menunggu koneksi WhatsApp...\n\n')
  await import('./index.js')
}

main().catch(error => {
  process.stderr.write(`\nStartup gagal sebelum pairing: ${error.message || error}\n`)
  process.exitCode = 1
})
