import path from 'node:path'

const ROOT       = process.cwd()
const cleanPhone = (value = '') => String(value).replace(/\D/g, '')

export const settings = Object.freeze({
  // ── Identitas ──
  botName:    'チル',
  botVersion: '3.3.12',
  adminName:  'スギ Fall',
  prefix:     '!',

  pairingNumber: cleanPhone('6281563123814'), // format 628xxxxxxxx
  ownerJid:      '6281563123814',             // kosong = ikut nomor pairing

  // ── Path ──
  root:       ROOT,
  authDir:    path.join(ROOT, 'sessions'),
  dataDir:    path.join(ROOT, 'data'),
  tempDir:    path.join(ROOT, 'tmp'),
  bannerPath: path.join(ROOT, 'assets', 'banner.mp4'),
  menuFontPath: path.join(ROOT, 'assets', 'fonts', 'ChillMenu.ttf'),
  menuAccentFontPath: path.join(ROOT, 'assets', 'fonts', 'ChillAccent.ttf'),
  menuTitleFontPath: path.join(ROOT, 'assets', 'fonts', 'Roboto_Medium.ttf'),

  // ── Menu ──
  menuTitle:       '私はワイルドなスキです',
  menuQuote:       'Kerjakan yang penting.\\nSederhanakan yang rumit.\\nTetap tenang, tetap fokus, terus maju.',
  footerText:      'Private ToolBot - Owner Only',
  menuShowRuntime: true,

  // ── Banner ─────────────────────────────────────────────────────────────────
  // PENTING: bannerLoopSeconds: 0  = FULL DURASI (tidak dipotong)
  // Ubah ke angka > 0 kalau mau memotong durasi, mis: 10 = 10 detik saja
  bannerLoopSeconds: 0,        // 0 = full durasi banner tanpa dipotong ✓
  bannerWidth:       480,
  bannerFps:         20,
  bannerCrf:         26,
  bannerPrewarm:     true,
  bannerAspectRatio: '16:9',
  bannerFit:         'pad',    // 'pad' = letterbox | 'crop' = penuh, kepotong
  // true = banner muncul di SEMUA command (!help, !menu, !afk, !search, dll)
  // false = banner hanya di !menu
  bannerOnEveryCommand: true,
  // Batas karakter caption agar banner + teks tetap satu bubble.
  // WhatsApp sebenarnya limit ~65536 tapi bot kita pakai 8000 sebagai batas
  // aman agar tidak ada command apapun yang kehilangan banner karena teks
  // panjang. (4000 masih kepotong di !allmenu → banner hilang)
  bannerCaptionLimit: 8000,

  // ── AI: Gemini + Groq (dua provider bernama jelas, bukan generic slot) ────
  // !ai     = auto — coba Gemini dulu, fallback ke Groq kalau Gemini gagal/kosong.
  // !gemini = paksa Gemini saja.  !groq = paksa Groq saja.
  //
  // Gemini — daftar API key di https://aistudio.google.com (free tier ada).
  // Kalau lebih dari 1 key, bot otomatis rotate ke key berikutnya saat rate limit.
  // FORMAT VALID: 'AIza...' (standard key) ATAU 'AQ.Ab...' (auth key baru dari AI Studio).
  // Keduanya diterima native endpoint generativelanguage.googleapis.com — jangan difilter cuma AIza.
  geminiApiKeys: [
    process.env.GEMINI_API_KEY || ''
    // Tambahin lebih banyak key di sini untuk lebih jarang kena rate limit:
    // 'AIzaSyC...key2',  // standard key (lama, valid sampe Sept 2026)
    // 'AQ.Ab...key3',    // auth key (baru, default di AI Studio sekarang)
  ].filter(k => typeof k === 'string' && (k.startsWith('AIza') || k.startsWith('AQ.'))),
  // Nama model Gemini SENGAJA lewat env var, bukan hardcode di features.js.
  // Model generatif Google rutin dipensiunkan — gemini-2.0-flash (versi lama yang
  // dipakai sebelumnya) resmi di-retire Google per 1 Juni 2026, ini kemungkinan
  // besar penyebab utama "Gemini sering error" (bukan rate limit/format key).
  // Kalau Google pensiunkan gemini-3.6-flash nanti, ganti GEMINI_MODEL di
  // Pterodactyl saja — tidak perlu ubah/redeploy kode.
  geminiModel: process.env.GEMINI_MODEL || 'gemini-3.6-flash',

  // Groq — daftar API key di https://console.groq.com (free tier tersedia,
  // umumnya limit lebih longgar & lebih stabil daripada free tier Gemini).
  // Fallback ke AI_API_KEY/AI_MODEL lama supaya kompatibel kalau sebelumnya
  // sempat diisi mengikuti saran audit versi lama; ke depan pakai GROQ_*.
  groqApiKey: process.env.GROQ_API_KEY || process.env.AI_API_KEY || '',
  // openai/gpt-oss-120b = general-purpose, rekomendasi Groq saat ini.
  // openai/gpt-oss-20b  = lebih ringan/cepat kalau mau hemat kuota.
  // Cek ulang https://api.groq.com/openai/v1/models kalau model ini di-deprecate.
  groqModel: process.env.GROQ_MODEL || process.env.AI_MODEL || 'openai/gpt-oss-120b',

  // ── Auto-react ke Status/Story ───────────────────────────────────────────
  // true = bot otomatis react dengan emoji random ke setiap status WA
  autoReactStatus: false,
  autoReactEmoji: ['🥶','😳','😒','🥰','😎','🫣','😍','😨','😁','👀','😮','🤩','💀','🔥'],

  // ── Response templates ───────────────────────────────────────────────────
  // Pesan standar yang dipakai di seluruh bot. Edit sesuai selera.
  messages: {
    wait:    '⏳ Sabar ya, lagi diproses...',
    success: '✅ Selesai!',
    onFeat:  '✅ Fitur berhasil diaktifkan.',
    offFeat: '❌ Fitur berhasil dimatikan.',
    groupOnly:   '⚠️ Fitur ini hanya bisa dipakai di dalam grup.',
    privateOnly: '⚠️ Fitur ini hanya bisa dipakai di chat pribadi.',
    needAdmin:   '⚠️ Bot harus jadi *admin grup* untuk fitur ini.',
    noQuery:     '⚠️ Masukin teks atau link dulu ya.',
    error:       '❌ Terjadi kesalahan. Coba lagi nanti.'
  },
  // Daftarkan API key di https://tavily.com (free tier tersedia)
  tavilyApiKey:       process.env.TAVILY_API_KEY || '',
  searchMaxResults:   3,         // jumlah hasil yang ditampilkan (1–10)
  searchTimeoutMs:    15_000,    // batas waktu request Tavily

  // ── Download / sticker ──
  maxDownloadMb:     80,
  downloadTimeoutMs: 180_000,
  downloadConcurrency: 2,
  tempSweepIntervalMs: 60_000,
  prewarmDownloader: false,
  // Spotify: credentials MUST come from Pterodactyl environment variables.
  spotifyClientId: process.env.SPOTIFY_CLIENT_ID || '',
  spotifyClientSecret: process.env.SPOTIFY_CLIENT_SECRET || '',
  spotifyRedirectUri: process.env.SPOTIFY_REDIRECT_URI || 'https://private.gervhosting.my.id/spotify/callback',
  spotifyApiTimeoutMs: 12_000,
  defaultDownloadVideoQuality: 'bv*[ext=mp4][height<=720]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b',
  defaultDownloadAudioQuality: 'bestaudio[ext=m4a]/bestaudio/best',
  noFfmpegVideoQuality: 'b[ext=mp4][height<=720]/b[ext=mp4]/b',
  noFfmpegAudioQuality: 'ba[ext=m4a]/ba[ext=mp3]/ba/b',
  stickerMaxInputMb:   20,
  stickerVideoSeconds: 6,
  stickerOutputMaxMb:  1,
  stickerSize:         512,
  stickerVideoFps:     15,        // 12 → 15: sticker video lebih halus
  stickerQuality:      90,        // kualitas webp (pipeline utama & fallback)
  stickerPackName:     'チル Sticker',
  stickerAuthorName:   'スギ Fall',
  stickerPendingMs:    120_000,

  // ── Koneksi ──
  logLevel:            'debug',
  waLogLevel:          'silent',
  reconnectDelayMs:    3_000,
  markOnlineOnConnect: false,
  autoReconnect: false,
  syncFullHistory:     false,
  commandCooldownMs:   0,        // bot pribadi: tanpa cooldown global
  keepAliveIntervalMs: 20_000,
  waVersionOverride:   null,

  // ── Console ──
  chatLogEnabled:      true,     // kotak GROUP/PRIVATE CHAT LOG (chalk)
  debugMode:           true,
  sessionCleanupHours: 72,       // bersihkan pre-key/sender-key basi; creds TIDAK disentuh

  // ── AFK ──
  afkMentionCooldownMs:        300_000,
  afkOffOnOwnerChat:           true,
  afkOffGraceMs:               3_000,
  afkReturnPhrases: [
    'aku kembali', 'gw kembali', 'saya kembali', 'kembali',
    'aku balik', 'gw balik', 'udah balik', 'sudah balik', 'balik',
    'im back', "i'm back", 'im back guys', 'back',
    'afk off', 'off afk', 'udahan afk', 'stop afk'
  ]
})

export const cleanPhoneNumber  = cleanPhone
export const isConfiguredPhone = (value) => /^\d{8,15}$/.test(cleanPhone(value))

export function normalizeOwnerJid(value) {
  const raw = String(value || '').trim()
  if (!raw) return ''
  if (raw.includes('@')) {
    const [user, server] = raw.split('@')
    const normalizedUser = user.split(':')[0]
    return normalizedUser && server ? `${normalizedUser}@${server}` : ''
  }
  const phone = cleanPhone(raw)
  return phone ? `${phone}@s.whatsapp.net` : ''
}
