import fs from 'node:fs'
import path from 'node:path'
import makeWASocket, {
  Browsers,
  DisconnectReason,
  makeCacheableSignalKeyStore,
  useMultiFileAuthState
} from '@whiskeysockets/baileys'
import { Boom } from '@hapi/boom'

import { settings, isConfiguredPhone, normalizeOwnerJid } from './settings.js'
import { logger, waLogger, ui } from './src/utils/logger.js'
import { statsStore, store, closeDatabase } from './src/database.js'
import { getAfk, clearAfk } from './src/services/afk.js'
import {
  getMentionedJids,
  getReplyTargetJid,
  getSenderCandidates,
  getSenderJid,
  isGroupJid,
  messageText,
  normalizeJid,
  parseCommand,
  getQuotedMessage,
  unwrapMessage
} from './src/utils/message.js'
import { sendMenu, sendAllMenu, sendCategoryMenu, infoText, helpText, CATEGORY_ALIASES, prewarmBanner } from './src/commands/menu.js'
import { handleFeatures, FEATURE_COMMANDS } from './src/commands/features.js'
import { sendHelp } from './src/commands/help.js'
import { handleAfk, afkOffText, afkMentionText } from './src/commands/afk.js'
import { handleSticker, consumePendingSticker, handlePendingSticker } from './src/commands/sticker.js'
import { handleDelete } from './src/commands/delete.js'
import { handleDownload, handlePlay } from './src/commands/download.js'
import { extractDownloadUrl, handleDownloadReply } from './src/commands/download-reply.js'
import { handleSearch } from './src/commands/search.js'
import { sweepTemp } from './src/services/downloader.js'
import { sendBranded } from './src/services/banner.js'
import { hasDirectMedia } from './src/services/media.js'
import { handleConvert } from './src/commands/convert.js'
import { handleStatus } from './src/commands/status.js'
import { trackOutgoing, isBotOwnMessage } from './src/utils/self.js'
import { handleSpotify, handleSpotifyInfo, handleSpotifyEmbed } from './src/commands/spotify.js'
import { downloadQueue, getPerformanceSnapshot, countTempFiles } from './src/services/performance.js'
import { warmDownloader, isDownloaderWarm } from './src/services/downloader.js'

// ─── Command aliases ─────────────────────────────────────────────────────────
// Satu fitur = satu case di switch. Semua nama lain didaftarkan di sini supaya
// tidak ada `case` duplikat yang harus dijaga manual.
// Catatan: command yang ditangani menu kategori (CATEGORY_ALIASES) atau
// features.js (FEATURE_COMMANDS) TIDAK dinormalisasi — handler mereka memang
// membedakan nama command (mis. !hd vs !remini pakai provider berbeda).
const ALIASES = {
  // navigasi
  start:        'menu',
  commands:     'help',
  info:         'help',
  supporter:    'booster',
  // spotify
  spoti:        'spotify',
  // status
  stats:        'status',
  health:       'status',
  // converter
  konversi:     'convert',
  // search
  cari:         'search',
  find:         'search',
  // sticker
  s:            'sticker',
  stiker:       'sticker',
  // delete
  delete:       'del',
  d:            'del',
  // download video
  video:        'download',
  dl:           'download',
  tiktok:       'download',
  tt:           'download',
  ig:           'download',
  instagram:    'download',
  fb:           'download',
  facebook:     'download',
  twitter:      'download',
  x:            'download',
  threads:      'download',
  pinterest:    'download',
  mediafire:    'download',
  yt:           'download',
  youtube:      'download',
  // download audio
  music:        'audio',
  mp3:          'audio',
  ytmp3:        'audio',
  tiktokmp3:    'audio',
  ttaudio:      'audio'
}

function normalizeCommand(command) {
  if (!command) return command
  // Jangan sentuh command milik menu kategori / features.js
  if (CATEGORY_ALIASES[command] || FEATURE_COMMANDS.has(command)) return command
  return ALIASES[command] || command
}

let sockRef        = null
let reconnectTimer = null
let shuttingDown   = false
let retryCount     = 0
let connectionGeneration = 0

const cooldowns = new Map()
const afkNotifyCooldowns = new Map()
const groupNameCache = new Map()
const processedMessageIds = new Map()
const MAX_GROUP_CACHE = 500
const welcomeGroups = new Set(String(store.get('welcome_groups', '') || '').split(',').filter(Boolean))
const GROUP_NAME_TTL = 10 * 60 * 1000
const MAX_COOLDOWNS = 5000
const MAX_AFK_COOLDOWNS = 5000
const MAX_PROCESSED_MESSAGES = 2000
const PROCESSED_MESSAGE_TTL = 10 * 60 * 1000

function trimMapToSize(map, maxSize) {
  while (map.size > maxSize) {
    const first = map.keys().next().value
    if (first === undefined) break
    map.delete(first)
  }
}

function isDuplicateMessage(msg) {
  const id = msg?.key?.id
  if (!id) return false
  const key = `${msg.key.remoteJid || ''}:${id}`
  const now = Date.now()
  const previous = processedMessageIds.get(key)
  if (previous && now - previous < PROCESSED_MESSAGE_TTL) return true
  processedMessageIds.set(key, now)
  trimMapToSize(processedMessageIds, MAX_PROCESSED_MESSAGES)
  return false
}

// Jenis pesan internal WhatsApp yang tidak perlu diproses maupun dicatat
// di console. Tanpa filter ini, setiap !del atau reaksi emoji munculin
// "protocolMessage" / "reactionMessage" di kotak chat log Pterodactyl.
const INTERNAL_TYPES = new Set([
  'protocolMessage',              // hapus/revoke pesan, ephemeral timer, dsb.
  'senderKeyDistributionMessage', // distribusi key Signal internal WA
  'messageContextInfo',           // metadata konteks, bukan pesan nyata
  'pollUpdateMessage',            // update vote polling
  'reactionMessage',              // reaksi emoji ke pesan
  'keepInChatMessage',            // notifikasi pin pesan
  'callLogMesssage'               // log panggilan (typo intentional di proto WA)
])

// ─── Direktori ───────────────────────────────────────────────────────────────
function prepareDirectories() {
  for (const dir of [settings.authDir, settings.dataDir, settings.tempDir]) {
    fs.mkdirSync(dir, { recursive: true })
  }
  if (!fs.existsSync(settings.bannerPath)) {
    logger.warn({ path: settings.bannerPath }, 'assets/banner.mp4 tidak ditemukan')
  }
  if (!isConfiguredPhone(settings.pairingNumber)) {
    logger.warn('pairingNumber belum valid — format: 628xxxxxxxx')
  }
}

// ─── Session hygiene ──────────────────────────────────────────────────────────
// Pola auto-clean dipinjam dari bot teman (alya.js), tapi LEBIH AMAN:
// hanya file pre-key/sender-key yang sudah tua (>7 hari) yang dibuang —
// file ini di-replenish otomatis oleh WA. creds.json & app-state TIDAK
// PERNAH disentuh, jadi sesi tidak akan kehapus oleh bot sendiri.
const SESSION_STALE_AGE_MS = 7 * 24 * 60 * 60 * 1000

function cleanStaleSessionFiles() {
  try {
    if (!fs.existsSync(settings.authDir)) return
    const now = Date.now()
    let removed = 0

    for (const file of fs.readdirSync(settings.authDir)) {
      if (!file.startsWith('pre-key-') && !file.startsWith('sender-key-')) continue
      const full = path.join(settings.authDir, file)
      try {
        const stat = fs.statSync(full)
        if (now - stat.mtimeMs < SESSION_STALE_AGE_MS) continue
        fs.rmSync(full, { force: true })
        removed++
      } catch { /* file hilang di tengah jalan — abaikan */ }
    }

    if (removed > 0) {
      ui.info(`Session hygiene: ${removed} file pre-key/sender-key basi dibersihkan (creds aman)`)
    }
  } catch (error) {
    logger.warn({ err: error }, 'session cleanup gagal')
  }
}

const sessionCleanupHours = Math.max(1, Number(settings.sessionCleanupHours) || 72)
setInterval(cleanStaleSessionFiles, sessionCleanupHours * 60 * 60 * 1000).unref()

// ─── Owner ────────────────────────────────────────────────────────────────────
function configuredOwnerCandidates(sock) {
  const saved      = normalizeOwnerJid(store.get('owner_jid', ''))
  const configured = normalizeOwnerJid(settings.ownerJid)
  const pairing    = normalizeOwnerJid(settings.pairingNumber)
  const account    = normalizeOwnerJid(sock?.user?.id || '')
  return [configured, saved, pairing, account].filter(Boolean)
}

function isOwnerMessage(sock, msg) {
  if (msg?.key?.fromMe) return true
  const owners     = configuredOwnerCandidates(sock)
  const candidates = getSenderCandidates(msg).map(normalizeJid)
  return candidates.some(candidate => owners.some(owner => sameJidIdentity(candidate, owner)))
}

function sameJidIdentity(left, right) {
  const a = String(left || '').trim().toLowerCase()
  const b = String(right || '').trim().toLowerCase()
  if (!a || !b) return false
  if (a === b) return true

  const [aValue, aType] = a.split('@')
  const [bValue, bType] = b.split('@')
  if (!aValue || !bValue || aType !== bType) return false
  return aValue.split(':')[0] === bValue.split(':')[0]
}

function targetsOwner(sock, message) {
  const owners    = configuredOwnerCandidates(sock).map(normalizeJid)
  const mentioned = getMentionedJids(message).map(normalizeJid)
  if (mentioned.some(j => owners.some(owner => sameJidIdentity(j, owner)))) return true
  const replyTo = normalizeJid(getReplyTargetJid(message))
  return Boolean(replyTo) && owners.some(owner => sameJidIdentity(replyTo, owner))
}

function isAfkNotifyCooldownBlocked(jid) {
  const now  = Date.now()
  const last = afkNotifyCooldowns.get(jid) || 0
  if (now - last < settings.afkMentionCooldownMs) return true
  afkNotifyCooldowns.set(jid, now)
  trimMapToSize(afkNotifyCooldowns, MAX_AFK_COOLDOWNS)
  return false
}

function rememberOwner(sock) {
  const accountJid = normalizeOwnerJid(sock?.user?.id || '')
  const pairingJid = normalizeOwnerJid(settings.pairingNumber)
  const configured = normalizeOwnerJid(settings.ownerJid)
  const chosen     = configured || pairingJid || accountJid
  if (chosen && store.get('owner_jid') !== chosen) store.set('owner_jid', chosen)
  return chosen
}

// ─── Cooldown command ─────────────────────────────────────────────────────────
// Optimasi: cleanup cooldown map berkala, bukan per-hit
function isCooldownBlocked(jid) {
  if (Number(settings.commandCooldownMs) <= 0) return false
  const now  = Date.now()
  const last = cooldowns.get(jid) || 0
  if (now - last < settings.commandCooldownMs) return true
  cooldowns.set(jid, now)
  trimMapToSize(cooldowns, MAX_COOLDOWNS)
  return false
}

// Cleanup cooldown map setiap 5 menit agar tidak tumbuh tak terbatas
setInterval(() => {
  const now = Date.now()
  const maxAge = Math.max(settings.commandCooldownMs * 20, 60_000)
  for (const [k, ts] of cooldowns) {
    if (now - ts > maxAge) cooldowns.delete(k)
  }
  for (const [k, ts] of afkNotifyCooldowns) {
    if (now - ts > settings.afkMentionCooldownMs * 2) afkNotifyCooldowns.delete(k)
  }
  for (const [k, entry] of groupNameCache) {
    if (!entry || now - entry.at > GROUP_NAME_TTL) groupNameCache.delete(k)
  }
}, 5 * 60 * 1000).unref()

// ─── Chat log console (gaya alya.js) ──────────────────────────────────────────

async function resolveGroupName(sock, jid) {
  const hit = groupNameCache.get(jid)
  if (hit && Date.now() - hit.at < GROUP_NAME_TTL) return hit.name
  const meta = await sock.groupMetadata(jid)
  groupNameCache.set(jid, { name: meta?.subject || '', at: Date.now() })
  trimMapToSize(groupNameCache, MAX_GROUP_CACHE)
  return meta?.subject || ''
}

function logIncoming(sock, rawMsg, jid, message, text) {
  if (settings.chatLogEnabled === false) return
  const isGroup = isGroupJid(jid)
  const mtype   = Object.keys(message || {})[0] || 'unknown'

  // Fire-and-forget: fetch nama grup tidak boleh memperlambat handler pesan.
  ;(async () => {
    const groupName = isGroup ? await resolveGroupName(sock, jid) : ''
    ui.chatLog({
      isGroup,
      message:    text || mtype,
      senderName: rawMsg.pushName || settings.adminName,
      senderJid:  getSenderJid(rawMsg) || jid,
      groupName,
      chatJid: jid
    })
  })().catch(err => logger.debug({ err: err?.message, jid }, 'chat log group lookup failed'))
}

// ─── Disconnect reason ────────────────────────────────────────────────────────
function getDisconnectReason(lastDisconnect) {
  const error      = lastDisconnect?.error
  const statusCode = error instanceof Boom
    ? error.output?.statusCode
    : error?.output?.statusCode
  return {
    statusCode,
    loggedOut:        statusCode === DisconnectReason.loggedOut,
    restartRequired:  statusCode === DisconnectReason.restartRequired,
    connectionClosed: statusCode === DisconnectReason.connectionClosed,
    timedOut:         statusCode === DisconnectReason.timedOut,
    replaced:         statusCode === DisconnectReason.connectionReplaced
  }
}

export function wipeSession() {
  try {
    if (fs.existsSync(settings.authDir)) {
      fs.rmSync(settings.authDir, { recursive: true, force: true })
      logger.info('Folder sessions dihapus. Restart bot untuk pairing ulang.')
    }
  } catch (e) {
    logger.error({ err: e }, 'Gagal hapus sessions')
  }
}

function persistWelcomeGroups() {
  store.set('welcome_groups', [...welcomeGroups].join(','))
}

async function handleWelcomeCommand(sock, jid, args) {
  if (!isGroupJid(jid)) return sock.sendMessage(jid, { text: '!welcome hanya untuk grup.' })
  const mode = String(args[0] || '').toLowerCase()
  if (!['on', 'off', 'status'].includes(mode)) return sock.sendMessage(jid, { text: 'Format: !welcome on | off | status' })
  if (mode === 'status') return sock.sendMessage(jid, { text: `Welcome: ${welcomeGroups.has(jid) ? 'ON' : 'OFF'}` })
  if (mode === 'on') welcomeGroups.add(jid)
  else welcomeGroups.delete(jid)
  persistWelcomeGroups()
  return sock.sendMessage(jid, { text: `Welcome ${mode === 'on' ? 'diaktifkan' : 'dinonaktifkan'}.` })
}

async function handleGroupParticipantsUpdate(sock, update) {
  const jid = update?.id
  if (!jid || !welcomeGroups.has(jid)) return
  if (!['add', 'remove'].includes(update.action)) return
  const meta = await sock.groupMetadata(jid).catch(() => null)
  if (!meta) return
  const mentions = update.participants || []
  if (update.action === 'add') {
    return sock.sendMessage(jid, { text: `Selamat datang ${mentions.map(x => '@' + x.split('@')[0]).join(', ')}.\nSelamat bergabung di ${meta.subject}.`, mentions })
  }
  return sock.sendMessage(jid, { text: `Sampai jumpa ${mentions.map(x => '@' + x.split('@')[0]).join(', ')}.`, mentions })
}

// ─── Message handler ──────────────────────────────────────────────────────────
async function handleIncoming(sock, rawMsg) {
  if (!rawMsg?.message)                              return
  if (rawMsg.key?.remoteJid === 'status@broadcast') return

  // Lewati pesan internal WhatsApp (protocol, reaction, poll update, dsb.)
  // yang BUKAN pesan nyata dari pengguna. Ini sumber utama spam "protocolMessage"
  // di console Pterodactyl setiap kali seseorang menghapus pesan atau memberi reaksi.
  const rawMsgType = Object.keys(rawMsg.message)[0] ?? ''
  if (INTERNAL_TYPES.has(rawMsgType)) return

  // Abaikan pesan bot sendiri (auto-reply, hasil command, dll)
  // supaya AFK tidak mati karena echo balasan bot sendiri.
  if (isBotOwnMessage(rawMsg)) return

  const message    = unwrapMessage(rawMsg.message)
  const jid        = rawMsg.key?.remoteJid || ''
  const fromOwner  = isOwnerMessage(sock, rawMsg)
  if (!jid) return

  const text = messageText(message)

  // Kotak GROUP/PRIVATE CHAT LOG di console (gaya bot teman)
  logIncoming(sock, rawMsg, jid, message, text)

  // ── AFK per-chat: balas orang lain yang tag/reply/DM owner saat AFK ──────
  // getAfk(jid) → AFK cuma hidup di chat tempat !afk diketik. Orang lain
  // chat di grup B tidak memicu balasan AFK dari grup A.
  if (!fromOwner) {
    const afk = getAfk(jid)
    if (afk) {
      const addressed = isGroupJid(jid) ? targetsOwner(sock, message) : true
      if (addressed && !isAfkNotifyCooldownBlocked(normalizeJid(jid))) {
        await sendBranded(sock, jid, afkMentionText(afk, settings.adminName)).catch(() => {})
      } else if (!addressed) {
        logger.debug({ jid, mentioned: getMentionedJids(message), replyTo: getReplyTargetJid(message) }, 'AFK tidak aktif: pesan tidak menargetkan owner')
      }
    }
    return
  }

  if (isCooldownBlocked(normalizeJid(jid))) return

  const parsed = text ? parseCommand(text, settings.prefix) : null
  if (parsed) parsed.command = normalizeCommand(parsed.command)

  // ── !dl tanpa argumen + reply media → ambil ulang media dari WA ──────────
  if (parsed && parsed.command === 'download' && !parsed.args.length) {
    const quoted = getQuotedMessage(message)
    if (quoted) {
      const quotedUrl = extractDownloadUrl(messageText(quoted))
      if (quotedUrl) return handleDownload(sock, jid, [quotedUrl], 'video')
      statsStore.inc('download_video')
      return handleDownloadReply(sock, jid, quoted, rawMsg)
    }
  }

  // ── Sticker mode: ketik !s dulu, kirim foto kemudian ─────────────────────
  if (!parsed && hasDirectMedia(message)) {
    const pendingSticker = consumePendingSticker(jid)
    if (pendingSticker) {
      statsStore.inc('sticker')
      return handlePendingSticker(sock, jid, message, pendingSticker)
    }
  }

  // ── AFK per-chat: kapan sesi berakhir? ────────────────────────────────────
  // • owner chat biasa DI CHAT INI              → AFK chat ini MATI
  // • owner chat di grup lain / japri lain      → AFK chat ini TETAP JALAN
  // • owner pakai command apa pun               → AFK TETAP JALAN
  // • orang lain nge-tag / reply owner          → AFK TETAP JALAN
  // • auto-reply bot sendiri                    → AFK TETAP JALAN
  const wasAfk = getAfk(jid)
  if (wasAfk && !parsed && settings.afkOffOnOwnerChat !== false) {
    const hasBody = Boolean(text) || Boolean(message?.imageMessage) ||
                    Boolean(message?.videoMessage) || Boolean(message?.stickerMessage) ||
                    Boolean(message?.audioMessage) || Boolean(message?.documentMessage)
    const graceMs = Number(settings.afkOffGraceMs) || 0
    const passed  = Date.now() - wasAfk.since >= graceMs

    if (hasBody && passed) {
      clearAfk(jid)
      await sendBranded(sock, jid, afkOffText(wasAfk)).catch(() => {})
      return
    }
  }

  if (!parsed) return

  const { command, args } = parsed
  statsStore.inc('commands_total')

  try {
    // Category menus + expanded feature pack must be handled BEFORE the switch.
    // Unmatched switch cases exit immediately, so keeping these checks inside the
    // switch would make commands such as !rvo, !hd, !ai, !tagall, etc. unreachable.
    if (CATEGORY_ALIASES[command]) {
      return sendCategoryMenu(sock, jid, CATEGORY_ALIASES[command])
    }

    if (FEATURE_COMMANDS.has(command)) {
      const handled = await handleFeatures(sock, jid, message, rawMsg, command, args)
      if (handled !== false) return handled
    }

    switch (command) {
      // ── Navigasi ──
      case 'menu':
        return sendMenu(sock, jid)

      case 'help':
        return sendHelp(sock, jid)

      case 'allmenu':
        return sendAllMenu(sock, jid)

      case 'booster': {
        const snap = getPerformanceSnapshot(isDownloaderWarm())
        const tempFiles = await countTempFiles()
        return sendBranded(sock, jid, [
          `╭──────────〔 ${settings.botName} BOOSTER 〕`,
          '│ Mode     : PERFORMANCE',
          `│ Queue    : ${snap.queueRunning}/${snap.queueLimit} running`,
          `│ Waiting  : ${snap.queueWaiting}`,
          `│ Memory   : ${snap.rssMb} MB RSS`,
          `│ Heap     : ${snap.heapUsedMb} MB`,
          `│ Load     : ${Number(snap.load1m).toFixed(2)}`,
          `│ Temp     : ${tempFiles} files`,
          `│ Warm     : ${isDownloaderWarm() ? 'READY' : 'COLD'}`,
          '╰──────────────────────────',
          '',
          '_Queue + warm-up + cache init + cleanup throttling._'
        ].join('\n'))
      }

      case 'spotify':
        return handleSpotify(sock, jid, args)

      case 'spotifyinfo':
        return handleSpotifyInfo(sock, jid, args)

      case 'spotifyembed':
        return handleSpotifyEmbed(sock, jid, args)

      case 'welcome':
        return handleWelcomeCommand(sock, jid, args)

      // ── Owner dashboard ──
      case 'status':
        return handleStatus(sock, jid)

      // ── Media converter ──
      case 'convert':
        return handleConvert(sock, jid, message, args)

      // ── Search ──
      case 'search':
        statsStore.inc('search')
        return handleSearch(sock, jid, args)

      // ── Sticker ──
      case 'sticker':
        statsStore.inc('sticker')
        return handleSticker(sock, jid, message, args)

      // ── Delete ──
      case 'del':
        statsStore.inc('delete')
        return handleDelete(sock, jid, message, rawMsg)

      // ── Search-to-download ──
      case 'play':
        return handlePlay(sock, jid, args.join(' '), 'audio')

      // ── Download ──
      case 'download':
        statsStore.inc('download_video')
        return handleDownload(sock, jid, args, 'video')

      case 'audio':
        statsStore.inc('download_audio')
        return handleDownload(sock, jid, args, 'audio')

      // ── AFK ──
      case 'afk':
        return handleAfk(sock, jid, args)

      default:
        return sendBranded(
          sock, jid,
          `Command *${command}* tidak dikenal.\nKetik *${settings.prefix}help* untuk daftar command.`
        )
    }
  } catch (error) {
    logger.error({ err: error, command, jid }, 'command error')
    await sendBranded(
      sock, jid,
      `*Error* saat menjalankan *${command}*.\n${error.message || 'Terjadi kesalahan.'}`
    ).catch(() => {})
  }
}

// ─── Connect ──────────────────────────────────────────────────────────────────
async function connect() {
  const generation = ++connectionGeneration
  const { state, saveCreds } = await useMultiFileAuthState(settings.authDir)

  const sock = makeWASocket({
    ...(Array.isArray(settings.waVersionOverride) ? { version: settings.waVersionOverride } : {}),
    auth: {
      creds: state.creds,
      // Cache Signal key store: standar Baileys — mengurangi beban I/O file
      // session dan error decrypt yang bisa berujung sesi korup/putus.
      keys: makeCacheableSignalKeyStore(state.keys, waLogger)
    },
    browser:                        Browsers.windows('Chrome'),
    markOnlineOnConnect:            settings.markOnlineOnConnect,
    syncFullHistory:                settings.syncFullHistory,
    connectTimeoutMs:               60_000,
    defaultQueryTimeoutMs:          60_000,
    logger:                         waLogger,
    generateHighQualityLinkPreview: false,
    keepAliveIntervalMs:            settings.keepAliveIntervalMs ?? 20_000,
    shouldSyncHistoryMessage:       () => false,
    // Abaikan broadcast, status, channel/newsletter — tidak relevan untuk bot ini
    shouldIgnoreJid: jid => {
      const value = String(jid || '')
      return value.endsWith('@broadcast') || value.endsWith('@newsletter')
    },
    getMessage:          async () => undefined,
    retryRequestDelayMs: 250,
    // Optimasi: kurangi buffer event yang tidak perlu
    emitOwnEvents:       false   // echo pesan sendiri tidak perlu di-emit lagi
  })

  trackOutgoing(sock)

  sockRef = sock
  let pairingRequested = false

  async function maybeRequestPairingCode(qr) {
    if (!qr || sock.authState.creds.registered || pairingRequested) return
    pairingRequested = true

    if (!isConfiguredPhone(settings.pairingNumber)) {
      logger.error('pairingNumber tidak valid. Isi di settings.js dengan format 628xxxxxxxx, lalu restart.')
      process.exit(1)
    }

    try {
      ui.info(`Meminta pairing code untuk ${settings.pairingNumber}...`)
      const code   = await sock.requestPairingCode(settings.pairingNumber)
      const pretty = String(code).replace(/(.{4})/g, '$1-').replace(/-$/, '')

      ui.box('WHATSAPP PAIRING CODE', [
        `CODE : ${pretty}`,
        `NOMOR: ${settings.pairingNumber}`,
        '',
        'WA > Perangkat Tertaut > Tautkan Perangkat',
        '> Tautkan dengan nomor telepon > masukkan code',
        'Berlaku +-60 detik'
      ])
    } catch (error) {
      pairingRequested = false
      ui.error(`Pairing code gagal: ${error?.message || error}`)
      ui.error('Stop bot → hapus folder sessions/ → tunggu 2 menit → Start lagi.')
    }
  }

  sock.ev.on('creds.update', saveCreds)
  sock.ev.on('group-participants.update', update => { handleGroupParticipantsUpdate(sock, update).catch(err => logger.debug({ err }, 'welcome handler failed')) })

  sock.ev.on('connection.update', async update => {
    const { connection, lastDisconnect, qr } = update

    if (qr) await maybeRequestPairingCode(qr)

    if (connection === 'open') {
      retryCount = 0
      const owner = rememberOwner(sock)
      ui.ok(`Connected — ${settings.botName} v${settings.botVersion} | owner: ${owner}`)
      prewarmBanner()
      sweepTemp().catch(() => {})
    }

    if (connection === 'close') {
      const reason = getDisconnectReason(lastDisconnect)

      try { sock.ev.removeAllListeners?.() } catch {}
      if (sockRef === sock) sockRef = null

      if (shuttingDown) return

      if (reason.loggedOut) {
        // SATU-SATUNYA kondisi sesi benar-benar mati. Folder sessions TIDAK
        // dihapus otomatis — keputusan pairing ulang tetap di tangan owner.
        ui.error('Logout dari WhatsApp (device dilepas). Hapus folder sessions/ lalu Start lagi untuk pairing ulang.')
        return
      }

      if (settings.autoReconnect !== true) {
        ui.error(`Connection closed (code ${reason.statusCode ?? '-'}) — auto-reconnect disabled.`)
        return
      }

      // Reconnect dengan exponential backoff hanya jika diaktifkan.
      const base  = reason.restartRequired ? 1000 : settings.reconnectDelayMs
      const delay = Math.min(base * Math.pow(2, retryCount), 60_000)
      retryCount  = Math.min(retryCount + 1, 6)

      ui.warn(`Disconnected (code ${reason.statusCode ?? '-'}) — reconnect dalam ${Math.round(delay / 1000)}s...`)

      clearTimeout(reconnectTimer)
      reconnectTimer = setTimeout(() => {
        if (shuttingDown || generation !== connectionGeneration) return
        connect().catch(err => logger.error({ err }, 'reconnect failed'))
      }, delay)
    }
  })

  // ── Message events ────────────────────────────────────────────────────────
  // Fire-and-forget per pesan: 1 command berat tidak blokir command berikutnya.
  sock.ev.on('messages.upsert', ({ messages, type }) => {
    if (type !== 'notify') return
    for (const msg of messages) {
      if (isDuplicateMessage(msg)) {
        logger.debug({ id: msg.key?.id, jid: msg.key?.remoteJid }, 'duplicate message ignored')
        continue
      }
      // Auto-react ke status/story WA (opsional, toggle di settings.js)
      if (settings.autoReactStatus && msg.key?.remoteJid === 'status@broadcast' && !msg.key?.fromMe) {
        const emojis = settings.autoReactEmoji || ['👍']
        const emoji  = emojis[Math.floor(Math.random() * emojis.length)]
        sock.sendMessage(msg.key.remoteJid, { react: { text: emoji, key: msg.key } }).catch(() => {})
      }

      handleIncoming(sock, msg).catch(err => logger.debug({ err }, 'message handling failed'))
    }
  })
}

// ─── Shutdown ─────────────────────────────────────────────────────────────────
async function shutdown(signal) {
  if (shuttingDown) return
  shuttingDown = true
  ui.info(`Stopping bot (${signal})...`)
  clearTimeout(reconnectTimer)
  try { sockRef?.end?.(new Error(signal)) } catch {}
  try { closeDatabase() } catch {}
  process.exit(0)
}

process.on('SIGINT',  () => shutdown('SIGINT'))
process.on('SIGTERM', () => shutdown('SIGTERM'))

// Tangkap unhandled rejection agar bot tidak drop diam-diam
process.on('unhandledRejection', (reason) => {
  logger.error({ err: reason }, 'unhandledRejection — bot tetap jalan')
})
process.on('uncaughtException', (err) => {
  logger.error({ err }, 'uncaughtException — bot tetap jalan')
})

// ─── Boot ─────────────────────────────────────────────────────────────────────
prepareDirectories()
if (settings.prewarmDownloader === true) warmDownloader().catch(() => {})
ui.box(`${settings.botName} v${settings.botVersion}`, ['booting...'])
cleanStaleSessionFiles()
prewarmBanner()
connect().catch(error => {
  logger.fatal({ err: error }, 'Bot failed to start')
  try { closeDatabase() } catch {}
  process.exit(1)
})
