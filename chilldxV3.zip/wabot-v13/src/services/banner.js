import fs from 'node:fs'
import fsp from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'
import { spawn } from 'node:child_process'
import { settings } from '../../settings.js'
import { ffmpegPath, hasFfmpeg, cleanProcessOutput } from '../utils/bin.js'
import { ui } from '../utils/logger.js'

/**
 * ─── BANNER = GIF (mp4 gifPlayback) ──────────────────────────────────────────
 * WhatsApp "GIF" = video mp4 pendek, TANPA audio, flag gifPlayback: true.
 * Autoplay + loop, tanpa tombol play, caption nyatu di bawah media.
 *
 * FIX: bannerLoopSeconds: 0 → full durasi tanpa dipotong.
 * FIX: bannerCaptionLimit: 8000 → banner tetap muncul di !help, !allmenu, dll.
 *      (Nilai lama 1024 terlalu kecil — !help 1288 karakter → banner skip)
 */

function runFFmpeg(args, timeoutMs = 120_000) {
  return new Promise((resolve, reject) => {
    const proc = spawn(ffmpegPath, args, { stdio: ['ignore', 'ignore', 'pipe'] })
    let stderr = ''
    const timer = setTimeout(() => {
      proc.kill('SIGKILL')
      reject(new Error('ffmpeg timeout'))
    }, timeoutMs)

    proc.stderr.on('data', (d) => { stderr += d.toString() })
    proc.on('error', (err) => { clearTimeout(timer); reject(err) })
    proc.on('close', (code) => {
      clearTimeout(timer)
      if (code === 0) resolve()
      else reject(new Error(`ffmpeg exit ${code}: ${cleanProcessOutput(stderr)}`))
    })
  })
}

// ─── Cache banner ─────────────────────────────────────────────────────────────
let bannerBuffer  = null
let bannerPromise = null
let bannerLastFailureAt = 0
let bannerSendFailures = 0
const BANNER_RETRY_MS = 30_000
const BANNER_MAX_SEND_FAILURES = 2
// Simpan mtime file asli untuk deteksi perubahan banner (dev workflow)
let bannerSourceMtime = 0

function buildVideoFilter(width, fps) {
  const parts = String(settings.bannerAspectRatio || '').trim().split(':').map(Number)
  const validRatio = parts.length === 2 && parts.every((n) => Number.isFinite(n) && n > 0)

  if (!validRatio) return `fps=${fps},scale=${width}:-2:flags=lanczos`

  const [rw, rh] = parts
  const height = Math.max(2, Math.round(((width * rh) / rw) / 2) * 2)

  if (settings.bannerFit === 'crop') {
    return `fps=${fps},scale=${width}:${height}:force_original_aspect_ratio=increase:flags=lanczos,crop=${width}:${height}`
  }
  return `fps=${fps},scale=${width}:${height}:force_original_aspect_ratio=decrease:flags=lanczos,pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2:color=black`
}

async function buildBanner() {
  if (!fs.existsSync(settings.bannerPath)) {
    ui.warn('assets/banner.mp4 tidak ditemukan — banner dinonaktifkan')
    return null
  }

  // Catat mtime untuk deteksi perubahan
  try {
    const stat = fs.statSync(settings.bannerPath)
    bannerSourceMtime = stat.mtimeMs
  } catch { bannerSourceMtime = 0 }

  // Tanpa ffmpeg: kirim file aslinya langsung
  if (!(await hasFfmpeg())) {
    ui.warn('ffmpeg tidak tersedia — banner dikirim tanpa kompresi (full durasi)')
    try {
      bannerBuffer = await fsp.readFile(settings.bannerPath)
      return bannerBuffer
    } catch {
      bannerBuffer = null
      return null
    }
  }

  // FIX: seconds = 0 → TIDAK ada flag -t → ffmpeg proses full durasi
  const seconds = Number(settings.bannerLoopSeconds) || 0
  const width   = Number(settings.bannerWidth) || 480
  const fps     = Number(settings.bannerFps) || 20
  const crf     = Number(settings.bannerCrf) || 26
  const outPath = path.join(os.tmpdir(), 'wa-banner-gif.mp4')

  const ffArgs = [
    '-y',
    // Hanya tambah -t kalau seconds > 0 (full durasi = tidak ada -t sama sekali)
    ...(seconds > 0 ? ['-t', String(seconds)] : []),
    '-i', settings.bannerPath,
    '-an',                               // GIF WA selalu bisu
    '-vf', buildVideoFilter(width, fps),
    '-c:v', 'libx264',
    '-profile:v', 'baseline',
    '-level', '3.1',
    '-pix_fmt', 'yuv420p',
    '-crf', String(crf),
    '-preset', 'veryfast',
    '-movflags', '+faststart',
    outPath
  ]

  try {
    await runFFmpeg(ffArgs)
    const buf = await fsp.readFile(outPath)
    bannerBuffer = buf

    const durTag = seconds > 0 ? `${seconds}s` : 'full durasi'
    const sizeMB = (buf.length / 1048576).toFixed(2)
    ui.ok(`Banner GIF siap (${(buf.length / 1024).toFixed(0)} KB / ${sizeMB} MB, ${width}px, ${durTag}, bisu)`)

    // Hapus file tmp setelah dibaca agar tidak numpuk
    fsp.rm(outPath, { force: true }).catch(() => {})

    return buf
  } catch (err) {
    ui.warn(`Compress banner gagal (${err.message}) — pakai file asli`)
    try {
      bannerBuffer = await fsp.readFile(settings.bannerPath)
      return bannerBuffer
    } catch {
      bannerBuffer = null
      return null
    }
  }
}

export function prewarmBanner() {
  if (!settings.bannerPrewarm) return Promise.resolve(null)
  if (!bannerPromise) {
    bannerPromise = buildBanner()
      .then(buf => {
        if (buf) {
          bannerLastFailureAt = 0
          return buf
        }
        bannerLastFailureAt = Date.now()
        bannerPromise = null
        return null
      })
      .catch(() => {
        bannerLastFailureAt = Date.now()
        bannerPromise = null
        return null
      })
  }
  return bannerPromise
}

export async function getBanner() {
  if (bannerBuffer) return bannerBuffer
  const now = Date.now()
  if (!bannerPromise && now - bannerLastFailureAt >= BANNER_RETRY_MS) {
    bannerPromise = buildBanner()
      .then(buf => {
        if (buf) {
          bannerLastFailureAt = 0
          return buf
        }
        bannerLastFailureAt = Date.now()
        bannerPromise = null
        return null
      })
      .catch(() => {
        bannerLastFailureAt = Date.now()
        bannerPromise = null
        return null
      })
  }
  return bannerPromise
}

/** Invalidasi cache (untuk dev: ganti banner.mp4 lalu !reload jika ada) */
export function invalidateBannerCache() {
  bannerBuffer  = null
  bannerPromise = null
  bannerSourceMtime = 0
}

// ─── Batas caption ────────────────────────────────────────────────────────────
// FIX: nilai lama 1024 terlalu kecil → !help (1288 karakter) selalu skip banner.
// Sekarang pakai settings.bannerCaptionLimit (default 8000) sehingga SEMUA
// command (!help, !afk, !search, dll) tetap dapat banner.
// WhatsApp sendiri batas caption video jauh di atas 8000 karakter.
function getCaptionLimit() {
  return Number(settings.bannerCaptionLimit) || 8000
}

function bannerMessage(buffer, caption) {
  const msg = {
    video: buffer,
    mimetype: 'video/mp4',
    gifPlayback: true
  }
  if (caption) msg.caption = caption
  return msg
}

/**
 * Kirim pesan berformat banner GIF + caption.
 * Semua command (!menu, !help, !afk, !search, error, dll) melewati sini.
 * Banner SELALU muncul selama:
 *   1. bannerOnEveryCommand = true di settings
 *   2. file banner tersedia dan sudah dicompress
 *   3. panjang caption <= bannerCaptionLimit (8000 karakter)
 */
export async function sendBranded(sock, jid, caption) {
  const text   = String(caption || '')
  const buffer = settings.bannerOnEveryCommand ? await getBanner() : null

  if (!buffer || text.length > getCaptionLimit()) {
    // Caption terlalu panjang atau banner tidak tersedia → teks saja
    return sock.sendMessage(jid, { text })
  }

  try {
    const sent = await sock.sendMessage(jid, bannerMessage(buffer, text))
    bannerSendFailures = 0
    return sent
  } catch (err) {
    bannerSendFailures++
    ui.warn(`Kirim banner gagal (${err.message}) — kirim teks saja`)
    if (bannerSendFailures >= BANNER_MAX_SEND_FAILURES) {
      bannerBuffer = null
      bannerPromise = null
      bannerLastFailureAt = Date.now()
      bannerSendFailures = 0
    }
    return sock.sendMessage(jid, { text })
  }
}
