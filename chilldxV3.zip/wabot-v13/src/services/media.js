import fs from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'
import { spawn } from 'node:child_process'

/**
 * sharp = native addon (libvips). Di Pterodactyl sering GAGAL load
 * ("Could not load the sharp module using the linux-x64 runtime" /
 *  "invalid ELF header") dan itu bikin SELURUH bot mati saat start,
 * padahal cuma dipakai buat sticker gambar.
 * Sekarang di-import dinamis + ada fallback ffmpeg, jadi bot tetap hidup.
 */
let sharp = null
try {
  sharp = (await import('sharp')).default
} catch {
  sharp = null
}

/**
 * wa-sticker-formatter = pipeline sticker UTAMA (dipinjam dari bot teman).
 * Type FULL: kanvas 512x512, gambar utuh tanpa kepotong, background
 * transparan, metadata pack/author langsung tertanam di webp.
 * Di-import dinamis juga — kalau gagal, jatuh ke pipeline sharp/ffmpeg.
 */
let stickerFormatter = null
let formatterLoaded  = false

async function loadStickerFormatter() {
  if (formatterLoaded) return stickerFormatter
  formatterLoaded = true
  try {
    stickerFormatter = await import('wa-sticker-formatter')
  } catch {
    stickerFormatter = null
  }
  return stickerFormatter
}

import { downloadContentFromMessage } from '@whiskeysockets/baileys'
import { settings } from '../../settings.js'
import { ffmpegPath, cleanProcessOutput } from '../utils/bin.js'

// Ukuran sticker (sisi terpanjang). WA menampilkan sticker non-persegi
// dengan normal, jadi tidak perlu dipaksa 512x512 + crop/pad.
const SIZE = Number(settings.stickerSize) || 512
const FPS  = Number(settings.stickerVideoFps) || 15

export async function streamToBuffer(stream, maxBytes = Infinity) {
  const chunks = []
  let total = 0

  for await (const chunk of stream) {
    total += chunk.length

    if (total > maxBytes) {
      throw new Error(`Media melewati batas ${settings.stickerMaxInputMb} MB.`)
    }

    chunks.push(Buffer.from(chunk))
  }

  return Buffer.concat(chunks)
}

/** Ada foto/video langsung di pesan ini (bukan reply)? */
export function hasDirectMedia(message = {}) {
  return Boolean(message?.imageMessage || message?.videoMessage || message?.stickerMessage)
}

/**
 * Ambil media dari pesan MANA SAJA: pesan itu sendiri (kirim foto + caption
 * `!s`) atau pesan yang di-reply. Ini yang bikin sticker tidak wajib reply.
 */
export async function downloadAnyMedia(message) {
  return downloadQuotedMedia(message)
}

export async function downloadQuotedMedia(quoted) {
  if (!quoted) return null
  quoted = quoted?.viewOnceMessageV2?.message || quoted?.viewOnceMessage?.message || quoted?.viewOnceMessageV2Extension?.message || quoted

  if (quoted.imageMessage) {
    return {
      type: 'image',
      mime: quoted.imageMessage.mimetype,
      buffer: await streamToBuffer(
        await downloadContentFromMessage(quoted.imageMessage, 'image'),
        settings.stickerMaxInputMb * 1024 * 1024
      )
    }
  }

  if (quoted.stickerMessage) {
    return {
      type: 'image',
      mime: quoted.stickerMessage.mimetype,
      buffer: await streamToBuffer(
        await downloadContentFromMessage(quoted.stickerMessage, 'sticker'),
        settings.stickerMaxInputMb * 1024 * 1024
      )
    }
  }

  if (quoted.videoMessage) {
    return {
      type: 'video',
      mime: quoted.videoMessage.mimetype,
      buffer: await streamToBuffer(
        await downloadContentFromMessage(quoted.videoMessage, 'video'),
        settings.stickerMaxInputMb * 1024 * 1024
      )
    }
  }

  if (quoted.audioMessage) {
    return {
      type: 'audio',
      mime: quoted.audioMessage.mimetype,
      buffer: await streamToBuffer(
        await downloadContentFromMessage(quoted.audioMessage, 'audio'),
        settings.stickerMaxInputMb * 1024 * 1024
      )
    }
  }

  return null
}

/**
 * Pipeline utama: wa-sticker-formatter.
 * Return null kalau library tidak tersedia / gagal / hasil kebesaran —
 * caller otomatis jatuh ke pipeline cadangan (sharp/ffmpeg).
 */
export async function buildStickerWithFormatter(buffer, description = '') {
  const mod = await loadStickerFormatter()
  if (!mod) return null

  try {
    const { Sticker, StickerTypes } = mod
    const sticker = new Sticker(buffer, {
      pack:   (description || '').trim().slice(0, 60) || settings.stickerPackName,
      author: settings.stickerAuthorName,
      type:   StickerTypes.FULL,
      quality: Number(settings.stickerQuality) || 90,
      background: '#FFFFFF00'
    })
    const out = await sticker.toBuffer()
    if (out.length > settings.stickerOutputMaxMb * 1024 * 1024) return null
    return out
  } catch {
    return null
  }
}

async function imageToStickerFfmpeg(buffer) {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'wa-img-'))
  const input = path.join(dir, 'input')
  const output = path.join(dir, 'output.webp')
  try {
    await fs.writeFile(input, buffer)
    await runProcess(ffmpegPath, [
      '-y', '-i', input,
      // Tidak di-crop dan tidak dikasih bantalan hitam: rasio asli
      // dipertahankan, sisi terpanjang dipas ke stickerSize.
      '-vf', `scale=w=${SIZE}:h=${SIZE}:force_original_aspect_ratio=decrease,scale=trunc(iw/2)*2:trunc(ih/2)*2`,
      '-c:v', 'libwebp', '-lossless', '0', '-q:v', String(Number(settings.stickerQuality) || 90), '-frames:v', '1',
      output
    ])
    return await fs.readFile(output)
  } finally {
    await fs.rm(dir, { recursive: true, force: true }).catch(() => {})
  }
}

export async function imageToSticker(buffer) {
  if (!sharp) {
    const fallback = await imageToStickerFfmpeg(buffer)
    if (fallback.length > settings.stickerOutputMaxMb * 1024 * 1024) {
      throw new Error(`Sticker hasil terlalu besar (>${settings.stickerOutputMaxMb} MB).`)
    }
    return fallback
  }

  const output = await sharp(buffer)
    .rotate()
    // fit 'inside' = TANPA crop dan TANPA bantalan kosong; gambar utuh,
    // rasio asli, cuma diperkecil sampai sisi terpanjang = stickerSize.
    .resize({
      width: SIZE,
      height: SIZE,
      fit: 'inside',
      withoutEnlargement: true
    })
    .webp({ quality: Number(settings.stickerQuality) || 90, effort: 4 })
    .toBuffer()

  if (output.length > settings.stickerOutputMaxMb * 1024 * 1024) {
    throw new Error(`Sticker hasil terlalu besar (>${settings.stickerOutputMaxMb} MB).`)
  }

  return output
}

function runProcess(command, args, timeoutMs = 120_000) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      stdio: ['ignore', 'ignore', 'pipe']
    })

    let stderr = ''

    const timer = setTimeout(() => {
      child.kill('SIGKILL')
      reject(new Error(`${command} timeout.`))
    }, timeoutMs)

    child.stderr.on('data', d => {
      stderr += d.toString()
      if (stderr.length > 6000) stderr = stderr.slice(-6000)
    })

    child.on('error', err => {
      clearTimeout(timer)
      reject(err)
    })

    child.on('close', code => {
      clearTimeout(timer)

      if (code === 0) resolve()
      else reject(new Error(`${command} exit ${code}: ${cleanProcessOutput(stderr)}`))
    })
  })
}

export async function videoToSticker(buffer) {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'wa-sticker-'))
  const input = path.join(dir, 'input.mp4')
  const output = path.join(dir, 'output.webp')

  try {
    await fs.writeFile(input, buffer)

    await runProcess(ffmpegPath, [
      '-y',
      '-i', input,
      '-t', String(settings.stickerVideoSeconds),
      '-vf', `fps=${FPS},scale=w=${SIZE}:h=${SIZE}:force_original_aspect_ratio=decrease,scale=trunc(iw/2)*2:trunc(ih/2)*2`,
      '-c:v', 'libwebp',
      '-lossless', '0',
      '-q:v', '70',
      '-loop', '0',
      output
    ])

    const stat = await fs.stat(output)
    if (stat.size > settings.stickerOutputMaxMb * 1024 * 1024) {
      throw new Error(`Sticker video hasil terlalu besar (>${settings.stickerOutputMaxMb} MB).`)
    }

    return await fs.readFile(output)
  } finally {
    await fs.rm(dir, { recursive: true, force: true }).catch(() => {})
  }
}

export async function videoToAudio(buffer, mime = 'video/mp4') {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'wa-audio-'))
  const ext = /audio\//i.test(String(mime)) ? '.audio' : '.mp4'
  const input = path.join(dir, `input${ext}`)
  const output = path.join(dir, 'output.mp3')
  try {
    await fs.writeFile(input, buffer)
    await runProcess(ffmpegPath, [
      '-y', '-i', input,
      '-vn', '-c:a', 'libmp3lame', '-q:a', '4', output
    ], 120_000)
    const stat = await fs.stat(output)
    if (stat.size > settings.maxDownloadMb * 1024 * 1024) {
      throw new Error(`Hasil audio melebihi batas ${settings.maxDownloadMb} MB.`)
    }
    const target = path.join(settings.tempDir, `convert-${Date.now()}-${Math.random().toString(16).slice(2)}.mp3`)
    await fs.copyFile(output, target)
    return target
  } finally {
    await fs.rm(dir, { recursive: true, force: true }).catch(() => {})
  }
}

export async function videoToGif(buffer) {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'wa-gif-'))
  const input = path.join(dir, 'input.mp4')
  const output = path.join(dir, 'output.mp4')
  try {
    await fs.writeFile(input, buffer)
    const seconds = Number(settings.convertVideoSeconds) || 8
    const fps = Number(settings.convertGifFps) || 12
    await runProcess(ffmpegPath, [
      '-y', '-i', input,
      '-t', String(seconds),
      '-an',
      '-vf', `fps=${fps},scale=w=${SIZE}:h=${SIZE}:force_original_aspect_ratio=decrease,scale=trunc(iw/2)*2:trunc(ih/2)*2`,
      '-c:v', 'libx264',
      '-pix_fmt', 'yuv420p',
      '-movflags', '+faststart',
      '-crf', '28',
      output
    ], 120_000)
    const stat = await fs.stat(output)
    if (stat.size > settings.maxDownloadMb * 1024 * 1024) {
      throw new Error(`Hasil GIF melebihi batas ${settings.maxDownloadMb} MB.`)
    }
    const target = path.join(settings.tempDir, `convert-${Date.now()}-${Math.random().toString(16).slice(2)}.mp4`)
    await fs.copyFile(output, target)
    return target
  } finally {
    await fs.rm(dir, { recursive: true, force: true }).catch(() => {})
  }
}
