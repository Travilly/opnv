import fs from 'node:fs/promises'
import fsSync from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { spawn } from 'node:child_process'
import { settings } from '../../settings.js'
import { ensureYtDlp, ffmpegPath, hasFfmpeg, cleanProcessOutput } from '../utils/bin.js'
import { maybeSweepTemp, runWithDownloadQueue } from './performance.js'

// Cookies OPSIONAL -- taruh cookies.txt (format Netscape hasil export extension
// browser) di root project kalau YouTube/IG sering minta login.
const COOKIES_FILE = path.join(settings.root, 'cookies.txt')
const YOUTUBE_RE   = /(?:youtube\.com|youtu\.be)/i
const MEDIAFIRE_RE = /mediafire\.com/i

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0 Safari/537.36'

async function expandShortUrl(url) {
  if (!/^https?:\/\/(?:vt|vm)\.tiktok\.com\//i.test(url)) return url

  try {
    const head = await fetch(url, {
      method: 'HEAD',
      redirect: 'follow',
      headers: { 'User-Agent': UA },
      signal: AbortSignal.timeout(10_000)
    })
    if (head.url && head.url !== url) return head.url
  } catch {}

  // Sebagian short-link TikTok menolak HEAD/405. GET tetap boleh diikuti
  // redirect-nya tetapi body sengaja tidak dibuffer ke memori.
  try {
    const res = await fetch(url, {
      method: 'GET',
      redirect: 'follow',
      headers: { 'User-Agent': UA },
      signal: AbortSignal.timeout(10_000)
    })
    if (res.url && res.url !== url) return res.url
    try { await res.body?.cancel() } catch {}
  } catch {}

  return url
}

function run(command, args, timeoutMs) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      cwd: settings.tempDir,
      stdio: ['ignore', 'pipe', 'pipe']
    })

    let stderr = ''
    const timer = setTimeout(() => {
      child.kill('SIGKILL')
      reject(new Error(`${command} timeout setelah ${Math.round(timeoutMs / 1000)} detik.`))
    }, timeoutMs)

    child.stdout.on('data', () => {})
    child.stderr.on('data', d => {
      stderr += d.toString()
      if (stderr.length > 12000) stderr = stderr.slice(-12000)
    })

    child.on('error', err => {
      clearTimeout(timer)
      reject(err)
    })

    child.on('close', code => {
      clearTimeout(timer)
      if (code === 0) resolve()
      else reject(new Error(`${command} exit ${code}: ${cleanProcessOutput(stderr)}`))
    })
  })
}

async function commandExists(command) {
  try {
    await run(command, ['--version'], 10_000)
    return true
  } catch {
    return false
  }
}

/**
 * ffmpeg TIDAK lagi wajib. Kalau tidak ada, yt-dlp dipaksa mengambil format
 * "progressive" (video+audio sudah jadi satu file) sehingga tidak perlu
 * merge/remux/convert sama sekali. Ini yang dulu bikin semua download gagal
 * dengan pesan "ffmpeg belum tersedia".
 */
let downloaderWarmPromise = null

export async function ensureDownloader() {
  const ytDlpPath = await ensureYtDlp()
  const ffmpegOk  = await hasFfmpeg()
  return { ytDlpPath, ffmpegOk }
}

export function isDownloaderWarm() {
  return Boolean(downloaderWarmPromise)
}

export function warmDownloader() {
  if (!downloaderWarmPromise) {
    downloaderWarmPromise = ensureDownloader().catch(error => {
      downloaderWarmPromise = null
      throw error
    })
  }
  return downloaderWarmPromise
}

function outputTemplate(kind) {
  const id     = crypto.randomBytes(6).toString('hex')
  const prefix = `${kind}-${id}-`
  return {
    prefix,
    template: path.join(settings.tempDir, `${prefix}%(id).60s.%(ext)s`)
  }
}

async function findOutput(prefix) {
  const files = await fs.readdir(settings.tempDir)
  const matches = files.filter(name => name.startsWith(prefix) && !name.endsWith('.part') && !name.endsWith('.ytdl'))

  if (!matches.length) {
    throw new Error('File hasil download tidak ditemukan (kemungkinan diblok situs sumber atau melebihi batas ukuran).')
  }

  const entries = await Promise.all(matches.map(async name => {
    const file = path.join(settings.tempDir, name)
    return { file, stat: await fs.stat(file) }
  }))

  entries.sort((a, b) => b.stat.mtimeMs - a.stat.mtimeMs)
  return entries[0].file
}

// Percobaan player_client YouTube. Client berbeda = nasib berbeda tergantung
// video/wilayah/IP datacenter (Pterodactyl hampir selalu IP datacenter, yang
// paling gampang kena "Sign in to confirm you're not a bot").
const YT_CLIENT_ATTEMPTS = ['tv', 'web_safari', 'android', 'ios']

function looksLikeBotCheck(message = '') {
  return /sign in to confirm|not a bot|confirm you.?re not a bot|429|too many requests|failed to extract|player response|unable to extract|requested format is not available|nsig|precondition check failed|flowcrypt|captcha|tiktok.*blocked|ip.*block|datacenter|access denied|page needs to be reloaded|needs to be reloaded|po_token|requires authentication/i
    .test(message)
}

/** Terjemahkan stderr yt-dlp yang panjang jadi pesan yang bisa ditindaklanjuti. */
export function explainError(message = '') {
  const m = String(message)
  if (/page needs to be reloaded|needs to be reloaded/i.test(m)) {
    return 'YouTube mendeteksi IP/server perlu memuat ulang sesi verifikasi.\nSolusi: coba lagi; bila tetap gagal, gunakan `cookies.txt` Netscape dari browser di root bot.'
  }
  if (/sign in to confirm|not a bot|cookies/i.test(m)) {
    return 'YouTube minta verifikasi login dari IP server ini.\nSolusi: export `cookies.txt` (Netscape) dari browser lalu taruh di folder root bot.'
  }
  if (/tiktok.*blocked|ip.*block|datacenter|access denied|403 forbidden|unable to extract webpage video data/i.test(m)) {
    return 'TikTok/IG memblokir IP server Pterodactyl (IP datacenter).\n' +
      'Solusi:\n' +
      '1. Export cookies dari browser (extension Get cookies.txt)\n' +
      '2. Simpan sebagai cookies.txt di root bot\n' +
      '3. Restart bot'
  }
  if (/max-filesize|file is larger|melebihi batas/i.test(m)) {
    return `Ukuran file melebihi batas ${settings.maxDownloadMb} MB.\nCoba pakai *${settings.prefix}music* (audio saja) atau naikkan \`maxDownloadMb\` di settings.js.`
  }
  if (/private|login required|not available in your country|age.?restrict/i.test(m)) {
    return 'Konten privat / dibatasi umur / diblok region. Butuh cookies.txt untuk aksesnya.'
  }
  if (/unsupported url|no video/i.test(m)) {
    return 'Link ini belum didukung yt-dlp. Pastikan URL langsung ke postingan/video, bukan halaman profil atau hasil share yang dipotong.'
  }
  if (/timeout/i.test(m)) {
    return 'Download timeout. Koneksi container lambat atau file terlalu besar.'
  }
  if (/HTTP Error 404|not found/i.test(m)) {
    return 'Link tidak ditemukan (404). Cek lagi URL-nya.'
  }
  // Ambil baris ERROR terakhir dari yt-dlp saja, jangan seluruh stderr.
  const errLine = m.split('\n').filter(l => /ERROR/i.test(l)).pop()
  return (errLine || m).slice(0, 400)
}

function buildArgs({ mode, template, url, clientArg, useCookies, ffmpegOk }) {
  const args = [
    '--no-playlist',
    '--no-warnings',
    '--no-progress',
    '--no-check-certificates',
    '--ignore-config',
    '--restrict-filenames',
    '--user-agent', UA,
    '--socket-timeout', '20',
    '--retries', '3',
    '--fragment-retries', '5',
    '--concurrent-fragments', '4',
    '--max-filesize', `${settings.maxDownloadMb}M`,
    ...(ffmpegOk ? ['--ffmpeg-location', ffmpegPath] : []),
    '-o', template
  ]

  if (useCookies) {
    args.push('--cookies', COOKIES_FILE)
  } else if (clientArg && YOUTUBE_RE.test(url)) {
    args.push('--extractor-args', `youtube:player_client=${clientArg}`)
  }

  // MediaFire = file hosting biasa, bukan situs video: jangan paksa format
  // selector video/audio, ambil apa adanya.
  if (MEDIAFIRE_RE.test(url)) {
    args.push(url)
    return args
  }

  if (mode === 'audio') {
    if (ffmpegOk) {
      args.push('-f', settings.defaultDownloadAudioQuality, '-x', '--audio-format', 'mp3', '--audio-quality', '5')
    } else {
      // Tanpa ffmpeg: ambil audio siap pakai (m4a/webm), tanpa konversi.
      args.push('-f', settings.noFfmpegAudioQuality)
    }
  } else if (ffmpegOk) {
    args.push('-f', settings.defaultDownloadVideoQuality, '--merge-output-format', 'mp4')
    // Banyak situs (TikTok/IG/FB) kadang cuma punya stream non-mp4; biarkan
    // yt-dlp remux ke mp4 daripada gagal total.
    args.push('--remux-video', 'mp4')
  } else {
    // Tanpa ffmpeg: WAJIB format progressive (audio+video satu file).
    args.push('-f', settings.noFfmpegVideoQuality)
  }

  args.push(url)
  return args
}

export async function downloadMedia(url, mode = 'video') {
  return runWithDownloadQueue(async () => {
    await maybeSweepTemp(sweepTemp)
    url = await expandShortUrl(url)
    const { ytDlpPath, ffmpegOk } = await warmDownloader()
  const { prefix, template } = outputTemplate(mode)
  const isYouTube  = YOUTUBE_RE.test(url)
  const hasCookies = fsSync.existsSync(COOKIES_FILE)

  // Pilih strategi retry sesuai platform:
  // - YouTube: rotate player_client (tv, web_safari, android, ios)
  // - TikTok/platfrom lain: satu attempt; short-link TikTok sudah dinormalisasi.
  const attempts = hasCookies ? [null] : (isYouTube ? YT_CLIENT_ATTEMPTS : [null])

  let lastError = null
  let success = false

  for (let i = 0; i < attempts.length; i++) {
    const args = buildArgs({ mode, template, url, clientArg: attempts[i], useCookies: hasCookies, ffmpegOk })
    try {
      await run(ytDlpPath, args, settings.downloadTimeoutMs)
      lastError = null
      success = true
      break
    } catch (err) {
      lastError = err
      const isLastAttempt = i === attempts.length - 1
      if (isLastAttempt || !looksLikeBotCheck(err.message)) break
    }
  }

  if (!success && lastError) {
    // Kadang yt-dlp exit non-zero tapi filenya sebenarnya sudah utuh
    // (mis. gagal di step post-processing opsional). Cek dulu sebelum menyerah.
    try {
      const salvaged = await findOutput(prefix)
      const stat = await fs.stat(salvaged)
      if (stat.size > 0) return salvaged
    } catch {}
    throw new Error(explainError(lastError.message))
  }

  const output = await findOutput(prefix)
  const stat = await fs.stat(output)

  if (stat.size > settings.maxDownloadMb * 1024 * 1024) {
    await fs.rm(output, { force: true })
    throw new Error(`File melebihi batas ${settings.maxDownloadMb} MB.`)
  }

    return output
  })
}

export async function cleanupFile(filePath) {
  if (filePath) {
    await fs.rm(filePath, { force: true }).catch(() => {})
  }
}

/** Bersihkan sisa file di tmp/ yang lebih tua dari 1 jam (anti disk penuh). */
export async function sweepTemp(maxAgeMs = 3_600_000) {
  try {
    const files = await fs.readdir(settings.tempDir)
    const now = Date.now()
    await Promise.all(files.map(async name => {
      const file = path.join(settings.tempDir, name)
      const stat = await fs.stat(file).catch(() => null)
      if (stat?.isFile() && now - stat.mtimeMs > maxAgeMs) {
        await fs.rm(file, { force: true }).catch(() => {})
      }
    }))
  } catch {}
}
