import fs from 'node:fs/promises'
import fsSync from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import crypto from 'node:crypto'
import { spawn } from 'node:child_process'
import { settings } from '../../settings.js'
import { ffmpegPath, hasFfmpeg, cleanProcessOutput } from '../utils/bin.js'

let cached = null
function esc(v='') { return String(v).replace(/\\/g,'\\\\').replace(/:/g,'\\:').replace(/'/g,"\\'").replace(/%/g,'%%').replace(/\n/g,'\\n') }
function run(args, timeout=45_000) { return new Promise((resolve,reject)=>{ const c=spawn(ffmpegPath,args,{stdio:['ignore','ignore','pipe']}); let e=''; const t=setTimeout(()=>{c.kill('SIGKILL');reject(new Error('menu timeout'))},timeout); c.stderr.on('data',d=>{e+=d;if(e.length>4000)e=e.slice(-4000)}); c.on('error',x=>{clearTimeout(t);reject(x)}); c.on('close',code=>{clearTimeout(t);code===0?resolve():reject(new Error(e?cleanProcessOutput(e):`ffmpeg exit ${code}`))}) }) }
export async function buildMenuCard(captionText='') {
  if (!(await hasFfmpeg()) || !fsSync.existsSync(settings.menuFontPath)) return null
  const key=crypto.createHash('sha1').update(String(captionText)).digest('hex')
  if(cached?.key===key)return cached.buffer
  const out=path.join(os.tmpdir(),`wps-menu-${key}.png`)
  const f=settings.menuFontPath, a=settings.menuAccentFontPath, t=settings.menuTitleFontPath
  const owner = String(settings.adminName || 'OWNER').replace(/[\x00-\x1F]/g, '').trim() || 'OWNER'
  const lines=[
    `VERSION : v${settings.botVersion}`,
    'ACCESS  : OWNER ONLY',
    'MODE    : SELF',
    '',
    'PROFILE',
    `NAME    : ${owner}`,
    `PREFIX  : ${settings.prefix}`,
    '',
    'QUICK ACCESS',
    `${settings.prefix}allmenu`,
    `${settings.prefix}help`
  ]
  const filters=[
    `drawbox=x=0:y=0:w=1200:h=760:color=black@0.52:t=fill`,
    `drawbox=x=64:y=42:w=1072:h=676:color=black@0.35:t=fill`,
    `drawbox=x=64:y=42:w=8:h=676:color=0xA78BFA:t=fill`,
    `drawtext=fontfile='${esc(t)}':text='${esc(settings.botName)}':fontsize=58:fontcolor=white:x=96:y=70`,
    `drawtext=fontfile='${esc(a)}':text='PRIVATE TOOLBOT':fontsize=21:fontcolor=0xD4D4D4:x=100:y=136`,
    `drawbox=x=96:y=175:w=960:h=2:color=0x777777@0.65:t=fill`,
    ...lines.map((line,i)=>`drawtext=fontfile='${esc(i<3?t:f)}':text='${esc(line)}':fontsize=${i<3?27:23}:fontcolor=${i<3?'white':'0xE5E5E5'}:x=100:y=${208+i*36}`),
    `drawtext=fontfile='${esc(a)}':text='${esc(settings.footerText)}':fontsize=19:fontcolor=0xB0B0B0:x=100:y=675`
  ].join(',')
  const input = fsSync.existsSync(settings.bannerPath) ? ['-ss','0','-i',settings.bannerPath] : ['-f','lavfi','-i','color=c=0x111111:s=1200x760:d=1']
  try {
    await run(['-y',...input,'-frames:v','1','-vf',`scale=1200:760:force_original_aspect_ratio=increase,crop=1200:760,${filters}`,'-frames:v','1','-f','image2',out])
    const b=await fs.readFile(out); cached={key,buffer:b}; await fs.rm(out,{force:true}); return b
  } catch {
    await fs.rm(out,{force:true}).catch(()=>{})
    return null
  }
}
export function clearMenuCardCache(){cached=null}
