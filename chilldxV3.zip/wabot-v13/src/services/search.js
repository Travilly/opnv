import { settings } from '../../settings.js'
import { ui } from '../utils/logger.js'

/**
 * ─── SEARCH SERVICE (Tavily API) ─────────────────────────────────────────────
 * Tavily adalah search API yang ramah untuk bot: hasilnya sudah bersih,
 * relevan, dan tidak perlu scraping. Free tier: 1000 credit/bulan.
 *
 * Daftar API key: https://tavily.com
 * Isi tavilyApiKey di settings.js dengan key hasil registrasi.
 */

const TAVILY_URL = 'https://api.tavily.com/search'

/**
 * Lakukan pencarian via Tavily.
 * @param {string} query - kata kunci pencarian
 * @returns {Promise<TavilyResult[]>}
 */
export async function tavilySearch(query) {
  const apiKey = settings.tavilyApiKey
  if (!apiKey || apiKey === 'tvly-YOUR_API_KEY_HERE') {
    throw new Error('Tavily API key belum diisi.\nIsi `tavilyApiKey` di `settings.js` — daftar gratis di https://tavily.com')
  }

  const controller = new AbortController()
  const timer = setTimeout(
    () => controller.abort(),
    Number(settings.searchTimeoutMs) || 15_000
  )

  let res
  try {
    res = await fetch(TAVILY_URL, {
      method:  'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        query,
        search_depth: 'basic',       // 'basic' = cepat; 'advanced' = lebih dalam tapi lebih lambat
        max_results:  Number(settings.searchMaxResults) || 5,
        include_answer: true,        // ringkasan AI singkat di atas hasil
        include_raw_content: false   // tidak butuh raw HTML, hemat bandwidth
      }),
      signal: controller.signal
    })
  } finally {
    clearTimeout(timer)
  }

  if (!res.ok) {
    const body = await res.text().catch(() => '')
    // Pesan error yang ramah berdasarkan HTTP status
    if (res.status === 401) throw new Error('API key Tavily tidak valid atau sudah kedaluwarsa.')
    if (res.status === 429) throw new Error('Kuota Tavily habis. Cek dashboard di tavily.com.')
    throw new Error(`Tavily error ${res.status}: ${body.slice(0, 200)}`)
  }

  const data = await res.json()
  return data
}

/**
 * Format hasil Tavily menjadi teks pesan WhatsApp.
 * @param {string} query
 * @param {object} data - respons JSON dari Tavily
 * @returns {string}
 */
export function formatSearchResult(query, data) {
  const results = data?.results || []
  const answer  = data?.answer  || ''

  const lines = [
    `╭──────────〔 *SEARCH* 〕`,
    `│ Query : _${query.slice(0, 80)}_`,
    '╰──────────────────────────'
  ]

  // Tampilkan ringkasan AI Tavily kalau ada
  if (answer && answer.trim()) {
    lines.push('', '*📝 Ringkasan*')
    // Potong ringkasan agar tidak terlalu panjang
    const summaryText = answer.trim().slice(0, 500)
    lines.push(summaryText.length < answer.trim().length ? summaryText + '...' : summaryText)
  }

  if (!results.length) {
    lines.push('', '_Tidak ada hasil ditemukan._')
  } else {
    lines.push('', '*🔍 Hasil Pencarian*')
    const maxResults = Math.min(results.length, Number(settings.searchMaxResults) || 5)
    for (let i = 0; i < maxResults; i++) {
      const r = results[i]
      const title   = (r.title   || 'Tanpa judul').trim().slice(0, 80)
      const url     = (r.url     || '').trim()
      const snippet = (r.content || r.snippet || '').trim().slice(0, 200)

      lines.push(`\n*${i + 1}. ${title}*`)
      if (snippet) lines.push(`_${snippet}${snippet.length >= 200 ? '...' : ''}_`)
      if (url)     lines.push(`🔗 ${url}`)
    }
  }

  lines.push('', `_Powered by Tavily Search_`)
  return lines.join('\n')
}
