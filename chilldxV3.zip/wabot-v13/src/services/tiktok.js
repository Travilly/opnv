import fs from 'node:fs/promises'
import path from 'node:path'
import crypto from 'node:crypto'
import { settings } from '../../settings.js'

const TIKWM_API = 'https://www.tikwm.com/api/'
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0 Safari/537.36'
const TIKTOK_RE = /(?:https?:\/\/)?(?:www\.|m\.|vm\.|vt\.)?tiktok\.com\//i

function isTikTokUrl(url = '') {
  return TIKTOK_RE.test(String(url))
}

async function expandShortUrl(url) {
  if (!/https?:\/\/(?:vt|vm)\.tiktok\.com\//i.test(url)) return url

  // TikWM sendiri menyebut short-link baru kadang perlu 3–5 detik sebelum
  // berhasil diproses, jadi jangan terlalu agresif memanggil provider.
  await new Promise(resolve => setTimeout(resolve, 1200))

  try {
    const response = await fetch(url, {
      method: 'GET',
      redirect: 'follow',
      headers: {
        'User-Agent': UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
      },
      signal: AbortSignal.timeout(15_000)
    })
    if (response.url && response.url !== url) return response.url
    try { await response.body?.cancel() } catch {}
  } catch {}

  return url
}

async function callTikwm(url) {
  const body = new URLSearchParams({
    url,
    count: '12',
    cursor: '0',
    web: '1',
    hd: '1'
  })

  let lastError

  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const response = await fetch(TIKWM_API, {
        method: 'POST',
        headers: {
          'User-Agent': UA,
          'Accept': 'application/json, text/javascript, */*; q=0.01',
          'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Origin': 'https://www.tikwm.com',
          'Referer': 'https://www.tikwm.com/',
          'X-Requested-With': 'XMLHttpRequest'
        },
        body,
        signal: AbortSignal.timeout(45_000)
      })

      const data = await response.json().catch(() => null)
      if (!response.ok) throw new Error(`TikWM HTTP ${response.status}`)
      if (!data?.data) throw new Error(data?.msg || 'TikWM tidak mengembalikan media')

      return data.data
    } catch (err) {
      lastError = err
      if (attempt < 3) {
        await new Promise(resolve => setTimeout(resolve, 700 * attempt + Math.floor(Math.random() * 600)))
      }
    }
  }

  throw lastError || new Error('TikWM gagal')
}

function chooseMedia(data, mode) {
  if (mode === 'audio') {
    const url = data.music || data.music_info?.play
    if (url) return { url, ext: 'mp3', kind: 'audio' }
    throw new Error('TikTok audio tidak tersedia')
  }

  if (Number(data.duration) === 0 && Array.isArray(data.images) && data.images.length) {
    return { url: data.images[0], ext: 'jpg', kind: 'image' }
  }

  const url =
    data.hdplay ||
    data.play ||
    data.wmplay ||
    null

  if (!url) throw new Error('TikTok video tidak tersedia')
  return { url, ext: 'mp4', kind: 'video' }
}

async function saveRemote(url, mode, hint) {
  const media = chooseMedia(hint, mode)
  const id = crypto.randomBytes(6).toString('hex')
  const file = path.join(settings.tempDir, `tiktok-${id}.${media.ext}`)

  const response = await fetch(media.url, {
    headers: { 'User-Agent': UA, 'Referer': 'https://www.tikwm.com/' },
    signal: AbortSignal.timeout(settings.downloadTimeoutMs)
  })

  if (!response.ok || !response.body) {
    throw new Error(`Gagal mengambil media TikTok (HTTP ${response.status})`)
  }

  const maxBytes = settings.maxDownloadMb * 1024 * 1024
  const handle = await fs.open(file, 'w')

  try {
    let total = 0
    for await (const chunk of response.body) {
      total += chunk.length
      if (total > maxBytes) {
        throw new Error(`File TikTok melebihi batas ${settings.maxDownloadMb} MB.`)
      }
      await handle.write(chunk)
    }
  } catch (error) {
    await fs.rm(file, { force: true }).catch(() => {})
    throw error
  } finally {
    await handle.close()
  }

  return { file, kind: media.kind, ext: media.ext }
}

export async function tryTikTokDownload(originalUrl, mode = 'video') {
  if (!isTikTokUrl(originalUrl)) return null

  const url = await expandShortUrl(originalUrl)
  const data = await callTikwm(url)
  return saveRemote(url, mode, data)
}
