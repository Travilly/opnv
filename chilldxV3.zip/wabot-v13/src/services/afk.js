import { afkStore } from '../database.js'
import { settings } from '../../settings.js'

/**
 * ─── AFK PER-CHAT ────────────────────────────────────────────────────────────
 * Key penyimpanan = JID chat tempat `!afk` diketik (bukan 1 key global).
 *
 * Efeknya:
 *  • `!afk` di grup A  → AFK cuma hidup di grup A
 *  • chat/japri di grup B, C, DM manapun → AFK grup A TIDAK ikut mati
 *  • AFK grup A mati hanya kalau owner chat biasa DI GRUP A, atau `!afk off`
 *  • bisa AFK di banyak chat sekaligus, masing-masing independen
 */
export function setAfk(jid, reason = '') {
  afkStore.set(jid, Date.now(), reason.trim())
}

export function clearAfk(jid) {
  return afkStore.remove(jid)
}

export function getAfk(jid) {
  return afkStore.get(jid)
}

/**
 * Normalisasi pesan buat dicocokkan dengan frasa "aku kembali":
 * lowercase, buang emoji/tanda baca, rapikan spasi.
 */
function normalizePhrase(text = '') {
  return String(text)
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s']/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

/**
 * true kalau pesan owner ini niatnya "gw udah balik" -> matikan AFK.
 * Sengaja ketat: harus persis salah satu frasa (atau frasa + sedikit basa-basi
 * maks 2 kata), supaya chat biasa saat AFK tidak asal mematikan sesi.
 */
export function isReturnPhrase(text = '') {
  const value = normalizePhrase(text)
  if (!value) return false

  const phrases = (settings.afkReturnPhrases || []).map(normalizePhrase).filter(Boolean)
  if (!phrases.length) return false

  const words = value.split(' ')
  if (words.length > 6) return false

  return phrases.some(phrase => {
    if (value === phrase) return true
    // "aku kembali guys", "im back semua" -> tetap dihitung
    if (value.startsWith(`${phrase} `)) {
      return value.slice(phrase.length + 1).split(' ').length <= 2
    }
    return false
  })
}

export function formatDuration(ms) {
  const total = Math.max(0, Math.floor(ms / 1000))
  const days = Math.floor(total / 86400)
  const hours = Math.floor((total % 86400) / 3600)
  const minutes = Math.floor((total % 3600) / 60)
  const seconds = total % 60
  const parts = []
  if (days) parts.push(`${days}d`)
  if (hours) parts.push(`${hours}h`)
  if (minutes) parts.push(`${minutes}m`)
  if (seconds || !parts.length) parts.push(`${seconds}s`)
  return parts.join(' ')
}
