import fs from 'node:fs/promises'
import os from 'node:os'
import { settings } from '../../settings.js'

class TaskQueue {
  constructor(limit = 2) {
    this.limit = Math.max(1, Number(limit) || 2)
    this.active = 0
    this.pending = []
  }
  get size() { return this.pending.length }
  get running() { return this.active }
  add(task, timeoutMs = 300_000) {
    if (typeof task !== 'function') return Promise.reject(new TypeError('Task harus berupa function.'))
    const limit = Math.max(1, Number(timeoutMs) || 300_000)
    return new Promise((resolve, reject) => {
      this.pending.push({ task, timeoutMs: limit, resolve, reject })
      this.pump()
    })
  }
  pump() {
    while (this.active < this.limit && this.pending.length) {
      const job = this.pending.shift()
      this.active++
      let timer
      const timeout = new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error(`Task timeout after ${job.timeoutMs}ms`)), job.timeoutMs)
        timer.unref?.()
      })
      const taskPromise = Promise.resolve().then(job.task)
      taskPromise.then(
        () => { clearTimeout(timer); this.release() },
        () => { clearTimeout(timer); this.release() }
      )
      Promise.race([taskPromise, timeout])
        .then(job.resolve, job.reject)
    }
  }
  release() {
    this.active--
    this.pump()
  }
}

export const downloadQueue = new TaskQueue(settings.downloadConcurrency)
let lastTempSweepAt = 0

export function runWithDownloadQueue(task) {
  return downloadQueue.add(task, settings.downloadTimeoutMs)
}

export async function maybeSweepTemp(sweepFn) {
  const now = Date.now()
  if (now - lastTempSweepAt < settings.tempSweepIntervalMs) return
  lastTempSweepAt = now
  await sweepFn().catch(() => {})
}

export async function countTempFiles() {
  try { return (await fs.readdir(settings.tempDir)).length } catch { return 0 }
}

export function getPerformanceSnapshot(downloaderWarm = false) {
  const mem = process.memoryUsage()
  return {
    queueRunning: downloadQueue.running,
    queueWaiting: downloadQueue.size,
    queueLimit: downloadQueue.limit,
    heapUsedMb: Math.round(mem.heapUsed / 1024 / 1024),
    rssMb: Math.round(mem.rss / 1024 / 1024),
    load1m: os.loadavg?.()[0] ?? 0,
    uptimeSec: Math.floor(process.uptime()),
    downloaderWarm,
  }
}
