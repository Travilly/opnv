import fs from 'node:fs/promises'
import path from 'node:path'
import { downloadMedia, cleanupFile } from '../services/downloader.js'
import { formatBytes } from '../utils/message.js'
import { sendBranded } from '../services/banner.js'
import { tryTikTokDownload } from '../services/tiktok.js'

const URL_RE = /^https?:\/\/\S+$/i

const AUDIO_MIME = {
  '.mp3':  'audio/mpeg',
  '.m4a':  'audio/mp4',
  '.aac':  'audio/aac',
  '.opus': 'audio/ogg; codecs=opus',
  '.ogg':  'audio/ogg',
  '.webm': 'audio/mp4'   // WA lebih aman diberi mp4 daripada webm
}

export async function handlePlay(sock, jid, query, mode = 'audio') {
  const q = String(query || '').trim()
  if (!q) return sendBranded(sock, jid, '*Format*\n`!play judul lagu`')
  let filePath
  try {
    await sendBranded(sock, jid, '*MENCARI MEDIA*\n_yt-dlp sedang mencari hasil pertama..._')
    filePath = await downloadMedia(`ytsearch1:${q}`, mode)
    const ext = path.extname(filePath).toLowerCase()
    if (mode === 'audio') {
      await sock.sendMessage(jid, { audio: { url: filePath }, mimetype: AUDIO_MIME[ext] || 'audio/mp4', fileName: `audio${ext || '.m4a'}` })
    } else {
      await sock.sendMessage(jid, { video: { url: filePath }, mimetype: 'video/mp4', fileName: `video${ext || '.mp4'}` })
    }
  } catch (error) {
    await sendBranded(sock, jid, `*PLAY GAGAL*\n\n${error.message || 'Terjadi kesalahan.'}`).catch(() => {})
  } finally {
    await cleanupFile(filePath)
  }
}

export async function handleDownload(sock, jid, args, mode = 'video') {
  const url = args[0]

  if (!url || !URL_RE.test(url)) {
    return sendBranded(sock, jid, mode === 'audio'
      ? '*FORMAT AUDIO*\n`!mp3 <link>`\nContoh: `!mp3 https://...`'
      : '*FORMAT DOWNLOAD*\n`!dl <link>`\nContoh: `!dl https://...`')
  }

  await sendBranded(sock, jid, mode === 'audio'
    ? '*MENGAMBIL AUDIO*\n_yt-dlp sedang memproses URL..._'
    : '*MENGUNDUH MEDIA*\n_yt-dlp sedang memproses URL..._')

  let filePath
  let tiktokKind = null

  try {
    // TikTok memakai provider khusus terlebih dahulu. yt-dlp tetap menjadi
    // fallback kalau provider eksternal sedang down.
    if (/tiktok\.com/i.test(url)) {
      const direct = await tryTikTokDownload(url, mode).catch(() => null)
      if (direct) {
        filePath = direct.file
        tiktokKind = direct.kind
      }
    }

    if (!filePath) filePath = await downloadMedia(url, mode)
    const stat = await fs.stat(filePath)
    const ext  = path.extname(filePath).toLowerCase()

    if (mode === 'audio') {
      await sock.sendMessage(jid, {
        audio: { url: filePath },
        mimetype: AUDIO_MIME[ext] || 'audio/mp4',
        fileName: `audio${ext || '.m4a'}`,
        ptt: false
      })
    } else if (tiktokKind === 'image') {
      await sock.sendMessage(jid, {
        image: { url: filePath },
        mimetype: 'image/jpeg',
        caption: `*SELESAI* - ${formatBytes(stat.size)}`
      })
    } else if (ext && ext !== '.mp4' && ext !== '.mov' && ext !== '.webm') {
      // Hasilnya bukan video (mis. file dari MediaFire) -> kirim as document.
      await sock.sendMessage(jid, {
        document: { url: filePath },
        mimetype: 'application/octet-stream',
        fileName: path.basename(filePath),
        caption: `*SELESAI* - ${formatBytes(stat.size)}`
      })
    } else {
      await sock.sendMessage(jid, {
        video: { url: filePath },
        mimetype: 'video/mp4',
        fileName: `video${ext || '.mp4'}`,
        caption: `*SELESAI* - ${formatBytes(stat.size)}`
      })
    }
  } catch (error) {
    await sendBranded(sock, jid, `*DOWNLOAD GAGAL*\n\n${error.message || 'Terjadi kesalahan.'}`).catch(() => {})
  } finally {
    await cleanupFile(filePath)
  }
}
