import { downloadContentFromMessage } from '@whiskeysockets/baileys'
import { sendBranded } from '../services/banner.js'
import { logger } from '../utils/logger.js'
import { settings } from '../../settings.js'

/**
 * ─── !dl (reply media) ───────────────────────────────────────────────────────
 * Reply ke pesan yang berisi foto/video/audio/sticker/dokumen lalu ketik !dl.
 * Bot mengambil ulang media dari server WA dan mengirimnya kembali sebagai file.
 */
const MEDIA_MAP = {
  imageMessage:    { type: 'image',    ext: 'jpg' },
  videoMessage:    { type: 'video',    ext: 'mp4' },
  audioMessage:    { type: 'audio',    ext: 'mp3' },
  documentMessage: { type: 'document', ext: 'bin' },
  stickerMessage:  { type: 'sticker',  ext: 'webp' }
}

export function extractDownloadUrl(text = '') {
  const match = String(text).match(/https?:\/\/[^\s<>]+/i)
  return match ? match[0].replace(/[),.!?]+$/, '') : null
}

/** Buka pembungkus view-once supaya media di dalamnya tetap terbaca. */
function unwrapQuoted(quoted) {
  return quoted?.viewOnceMessageV2?.message
    || quoted?.viewOnceMessage?.message
    || quoted?.viewOnceMessageV2Extension?.message
    || quoted?.ephemeralMessage?.message
    || quoted
}

export async function handleDownloadReply(sock, jid, quoted, rawMsg) {
  const node = unwrapQuoted(quoted)
  const msgType = node && typeof node === 'object'
    ? Object.keys(node).find(k => MEDIA_MAP[k])
    : null

  if (!msgType) {
    return sendBranded(sock, jid, '*DOWNLOAD*\nReply ke pesan yang ada media (foto/video/audio/sticker).')
  }

  try {
    const stream = await downloadContentFromMessage(node[msgType], msgType.replace('Message', ''))
    const chunks = []
    let total = 0
    const maxBytes = settings.maxDownloadMb * 1024 * 1024
    for await (const chunk of stream) {
      total += chunk.length
      if (total > maxBytes) throw new Error(`Media melebihi batas ${settings.maxDownloadMb} MB.`)
      chunks.push(Buffer.from(chunk))
    }
    const buffer = Buffer.concat(chunks)

    if (!buffer.length) throw new Error('Media kosong atau sudah expired di server WhatsApp.')

    const info = MEDIA_MAP[msgType]
    const mime = node[msgType]?.mimetype || 'application/octet-stream'

    if (info.type === 'image')   return sock.sendMessage(jid, { image: buffer }, { quoted: rawMsg })
    if (info.type === 'video')   return sock.sendMessage(jid, { video: buffer }, { quoted: rawMsg })
    if (info.type === 'audio')   return sock.sendMessage(jid, { audio: buffer, mimetype: mime }, { quoted: rawMsg })
    if (info.type === 'sticker') return sock.sendMessage(jid, { sticker: buffer }, { quoted: rawMsg })

    return sock.sendMessage(jid, {
      document: buffer,
      mimetype: mime,
      fileName: node[msgType]?.fileName || `download_${Date.now()}.${info.ext}`
    }, { quoted: rawMsg })
  } catch (err) {
    logger.debug({ err: err?.message, msgType }, 'download reply failed')
    return sendBranded(sock, jid, `*DOWNLOAD GAGAL*\n${err?.message || 'Media tidak bisa diambil.'}`)
  }
}
