import { settings } from '../../settings.js'
import { sendBranded } from '../services/banner.js'

const URL_RE = /^https?:\/\/(?:open\.)?spotify\.com\/(track|artist|album|playlist)\/([A-Za-z0-9]+)(?:\?.*)?$/i
const tokenCache = { value: '', expiresAt: 0 }
const cache = new Map()
const TTL = 5 * 60 * 1000

function getCache(key) {
  const hit = cache.get(key)
  if (!hit || Date.now() - hit.at > TTL) { if (hit) cache.delete(key); return null }
  return hit.value
}
function setCache(key, value) {
  cache.set(key, { at: Date.now(), value })
  while (cache.size > 100) cache.delete(cache.keys().next().value)
  return value
}
function parseUrl(input) {
  const m = String(input).trim().match(URL_RE)
  return m ? { type: m[1].toLowerCase(), id: m[2] } : null
}
function duration(ms) {
  const total = Math.floor(Number(ms || 0) / 1000)
  return total ? `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}` : '-'
}
async function fetchJson(url, options = {}) {
  const res = await fetch(url, { ...options, signal: AbortSignal.timeout(settings.spotifyApiTimeoutMs) })
  if (!res.ok) throw new Error(`Spotify HTTP ${res.status}`)
  return res.json()
}
async function getToken() {
  if (!settings.spotifyClientId || !settings.spotifyClientSecret) {
    throw new Error('Spotify API belum dikonfigurasi. Isi SPOTIFY_CLIENT_ID dan SPOTIFY_CLIENT_SECRET di environment.')
  }
  if (tokenCache.value && Date.now() < tokenCache.expiresAt) return tokenCache.value
  const basic = Buffer.from(`${settings.spotifyClientId}:${settings.spotifyClientSecret}`).toString('base64')
  const data = await fetchJson('https://accounts.spotify.com/api/token', {
    method: 'POST',
    headers: { Authorization: `Basic ${basic}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'grant_type=client_credentials'
  })
  if (!data?.access_token) throw new Error('Spotify tidak mengembalikan access token')
  tokenCache.value = data.access_token
  tokenCache.expiresAt = Date.now() + Math.max(60, Number(data.expires_in || 3600) - 60) * 1000
  return tokenCache.value
}
async function api(pathname, params = {}) {
  const token = await getToken()
  const url = new URL(`https://api.spotify.com/v1${pathname}`)
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, String(v))
  return fetchJson(url, { headers: { Authorization: `Bearer ${token}` } }).catch(err => {
    if (/HTTP 401/.test(err.message)) tokenCache.expiresAt = 0
    throw err
  })
}
async function embed(url) {
  return fetchJson(`https://open.spotify.com/oembed?url=${encodeURIComponent(url)}`)
}
function trackText(t) {
  return [
    '╭──────────〔 SPOTIFY TRACK 〕',
    `│ Title    : ${t.name || '-'}`,
    `│ Artist   : ${(t.artists || []).map(a => a.name).join(', ') || '-'}`,
    `│ Album    : ${t.album?.name || '-'}`,
    `│ Duration : ${duration(t.duration_ms)}`,
    `│ Release  : ${t.album?.release_date || '-'}`,
    '╰──────────────────────────', '',
    t.external_urls?.spotify || ''
  ].join('\n')
}

export async function handleSpotify(sock, jid, args) {
  const input = args.join(' ').trim()
  if (!input) return sendBranded(sock, jid, `*SPOTIFY*\n\n${settings.prefix}spotify <judul>\n${settings.prefix}spotify <link>\n${settings.prefix}spotifyinfo <track>`)
  try {
    const parsed = parseUrl(input)
    if (parsed) {
      // Link lookup tetap berguna tanpa credential Web API: oEmbed memberi
      // metadata dasar dari URL Spotify publik. Jika credential tersedia,
      // gunakan Web API untuk detail yang lebih lengkap.
      if (!settings.spotifyClientId || !settings.spotifyClientSecret) {
        const data = await embed(input)
        return sendBranded(sock, jid, [
          `╭──────────〔 SPOTIFY ${parsed.type.toUpperCase()} 〕`,
          `│ Title    : ${data.title || '-'}`,
          `│ Provider : ${data.provider_name || 'Spotify'}`,
          '╰──────────────────────────', '',
          input
        ].join('\n'))
      }
      if (parsed.type === 'track') return sendBranded(sock, jid, trackText(await api(`/tracks/${parsed.id}`)))
      const data = await api(`/${parsed.type}s/${parsed.id}`)
      return sendBranded(sock, jid, [
        `╭──────────〔 SPOTIFY ${parsed.type.toUpperCase()} 〕`,
        `│ Name     : ${data.name || '-'}`,
        `│ Owner    : ${data.owner?.display_name || '-'}`,
        `│ Items    : ${data.tracks?.total ?? '-'}`,
        '╰──────────────────────────', '',
        data.external_urls?.spotify || input
      ].join('\n'))
    }
    const key = `search:${input.toLowerCase()}`
    const data = getCache(key) || setCache(key, await api('/search', { q: input, type: 'track', limit: 10 }))
    const items = data?.tracks?.items || []
    if (!items.length) return sendBranded(sock, jid, '*SPOTIFY*\n\nLagu tidak ditemukan.')
    const lines = ['╭──────────〔 SPOTIFY SEARCH 〕', '│']
    items.forEach((x, i) => {
      lines.push(`│ ${i + 1}. ${x.name || '-'}`)
      lines.push(`│    ${(x.artists || []).map(a => a.name).join(', ') || '-'}`)
      lines.push(`│    ${x.external_urls?.spotify || ''}`)
      if (i < items.length - 1) lines.push('│')
    })
    lines.push('╰──────────────────────────')
    return sendBranded(sock, jid, lines.join('\n'))
  } catch (error) {
    return sendBranded(sock, jid, `*SPOTIFY GAGAL*\n\n${error.message}`)
  }
}

export async function handleSpotifyInfo(sock, jid, args) {
  const input = args.join(' ').trim()
  const parsed = parseUrl(input)
  if (!parsed || parsed.type !== 'track') return sendBranded(sock, jid, `*Format*\n${settings.prefix}spotifyinfo <Spotify track link>`)
  try { return sendBranded(sock, jid, trackText(await api(`/tracks/${parsed.id}`))) }
  catch (error) { return sendBranded(sock, jid, `*SPOTIFY GAGAL*\n\n${error.message}`) }
}

export async function handleSpotifyEmbed(sock, jid, args) {
  const input = args.join(' ').trim()
  if (!parseUrl(input)) return sendBranded(sock, jid, `*Format*\n${settings.prefix}spotifyembed <Spotify link>`)
  try {
    const data = await embed(input)
    return sendBranded(sock, jid, [
      '╭──────────〔 SPOTIFY INFO 〕',
      `│ Title    : ${data.title || '-'}`,
      `│ Provider : ${data.provider_name || 'Spotify'}`,
      '╰──────────────────────────', '', input
    ].join('\n'))
  } catch (error) { return sendBranded(sock, jid, `*SPOTIFY INFO GAGAL*\n\n${error.message}`) }
}
