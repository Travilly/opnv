import { tavilySearch, formatSearchResult } from '../services/search.js'
import { sendBranded } from '../services/banner.js'
import { settings } from '../../settings.js'

/**
 * Handler command !search <kata kunci>
 * Gunakan Tavily API untuk mencari informasi dari web.
 *
 * Cara pakai:
 *   !search cuaca Jakarta hari ini
 *   !search cara membuat nasi goreng
 *   !search latest AI news 2025
 */
export async function handleSearch(sock, jid, args) {
  const query = args.join(' ').trim()

  if (!query) {
    return sendBranded(sock, jid, [
      '*FORMAT PENCARIAN*',
      '',
      `\`${settings.prefix}search <kata kunci>\``,
      '',
      '*Contoh:*',
      `▸ \`${settings.prefix}search cuaca Jakarta hari ini\``,
      `▸ \`${settings.prefix}search cara install Node.js\``,
      `▸ \`${settings.prefix}search latest AI news\``
    ].join('\n'))
  }

  // Kirim status "sedang mencari" lebih dulu
  await sendBranded(sock, jid,
    `*🔍 MENCARI...*\n_Tavily sedang memproses: "${query.slice(0, 60)}"_`
  )

  try {
    const data   = await tavilySearch(query)
    const result = formatSearchResult(query, data)
    return sendBranded(sock, jid, result)
  } catch (error) {
    return sendBranded(sock, jid,
      `*SEARCH GAGAL*\n\n${error.message || 'Terjadi kesalahan saat mencari.'}`
    )
  }
}
