import { helpText as mergedHelpText } from './menu.js'
import { sendBranded } from '../services/banner.js'

export function helpText() {
  return mergedHelpText()
}

export async function sendHelp(sock, jid) {
  return sendBranded(sock, jid, helpText())
}
