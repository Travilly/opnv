import os from 'node:os'
import fs from 'node:fs/promises'
import path from 'node:path'
import { settings } from '../../settings.js'
import { getContextInfo, getQuotedMessage, getSenderJid, getMentionedJids, isGroupJid } from '../utils/message.js'
import { downloadMediaMessage } from '@whiskeysockets/baileys'
import { sendBranded } from '../services/banner.js'
import { logger } from '../utils/logger.js'

// ─── Retry helper for flaky external APIs ────────────────────────────────────
async function fetchWithRetry(url, options, timeoutMs, maxRetries = 2) {
  for (let i = 0; i <= maxRetries; i++) {
    try {
      const res = await fetchWithTimeout(url, options, timeoutMs)
      if (res.ok) return res
      if (res.status >= 500) throw new Error(`Server error ${res.status}`)
      return res // 4xx = don't retry
    } catch (err) {
      if (i === maxRetries) throw err
      await new Promise(r => setTimeout(r, 1000 * Math.pow(2, i)))
    }
  }
}


// ─── Anime: Jikan (utama) + Kitsu (fallback), masing-masing dengan retry ─────
async function fetchAnime(query, retries = 2) {
  const sources = [
    {
      name: 'jikan',
      url: `https://api.jikan.moe/v4/anime?q=${encodeURIComponent(query)}&limit=5`,
      normalize: (d) => (d?.data || []).map(a => ({
        id: a.mal_id,
        title: a.title,
        score: a.score,
        episodes: a.episodes,
        url: a.url
      }))
    },
    {
      name: 'kitsu',
      url: `https://kitsu.io/api/edge/anime?filter[text]=${encodeURIComponent(query)}&page[limit]=5`,
      normalize: (d) => (d?.data || []).map(a => ({
        title: a?.attributes?.canonicalTitle || a?.attributes?.titles?.en || a?.attributes?.titles?.en_jp,
        score: a?.attributes?.averageRating ? (Number(a.attributes.averageRating) / 10).toFixed(2) : null,
        episodes: a?.attributes?.episodeCount,
        url: a?.attributes?.slug ? `https://kitsu.io/anime/${a.attributes.slug}` : ''
      }))
    }
  ]

  let lastErr = null
  for (const source of sources) {
    for (let i = 0; i <= retries; i++) {
      try {
        const res = await fetchWithTimeout(source.url, {}, 15_000)
        if (!res.ok) throw new Error(`HTTP ${res.status}`)
        const rows = source.normalize(await res.json()).filter(r => r.title)
        if (rows.length) return rows
        throw new Error('Hasil kosong')
      } catch (err) {
        lastErr = err
        logger.debug({ err: err?.message, source: source.name, attempt: i + 1 }, 'anime lookup failed')
        if (i === retries) break
        await new Promise(r => setTimeout(r, 2000 * (i + 1)))
      }
    }
  }
  throw new Error(`Semua API anime tidak tersedia (Jikan & Kitsu). ${lastErr?.message || ''}`.trim())
}

const UA = 'WPSBot/3.2 (WhatsApp; Node.js)'

async function fetchWithTimeout(url, options = {}, timeout = 30_000) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeout)
  try {
    const headers = { 'user-agent': UA, ...(options.headers || {}) }
    const res = await fetch(url, { ...options, headers, signal: controller.signal })
    return res
  } finally {
    clearTimeout(timer)
  }
}

async function json(url, options = {}, timeout = 30_000) {
  const res = await fetchWithTimeout(url, options, timeout)
  const text = await res.text()
  if (!res.ok) throw new Error(`HTTP ${res.status}`)
  try {
    return JSON.parse(text)
  } catch (err) {
    logger.debug({ err: err?.message, url }, 'Response API bukan JSON')
    throw new Error('Response API bukan JSON')
  }
}

async function jsonWithRetry(url, options = {}, timeout = 30_000, retries = 2) {
  const res = await fetchWithRetry(url, options, timeout, retries)
  const text = await res.text()
  if (!res.ok) throw new Error(`HTTP ${res.status}`)
  try {
    return JSON.parse(text)
  } catch {
    throw new Error('Response API bukan JSON')
  }
}

async function buffer(url, options = {}, timeout = 90_000) {
  const res = await fetchWithTimeout(url, options, timeout)
  if (!res.ok) throw new Error(`HTTP ${res.status}`)
  return Buffer.from(await res.arrayBuffer())
}

async function uploadUguu(data, filename = 'image.jpg', mime = 'image/jpeg') {
  const form = new FormData()
  form.append('files[]', new Blob([data], { type: mime }), filename)
  const res = await fetchWithTimeout('https://uguu.se/upload.php', { method: 'POST', body: form }, 60_000)
  if (!res.ok) throw new Error(`Upload HTTP ${res.status}`)
  const out = await res.json()
  const url = out?.files?.[0]?.url
  if (!url) throw new Error('Upload gambar gagal')
  return url
}

async function uploadCatbox(data, filename = 'media.bin', mime = 'application/octet-stream') {
  const form = new FormData()
  form.append('reqtype', 'fileupload')
  form.append('fileToUpload', new Blob([data], { type: mime }), filename)
  const res = await fetchWithTimeout('https://catbox.moe/user/api.php', { method: 'POST', body: form }, 60_000)
  if (!res.ok) throw new Error(`Catbox HTTP ${res.status}`)
  const url = (await res.text()).trim()
  if (!url.startsWith('http')) throw new Error('Catbox gagal mengembalikan URL')
  return url
}

/** Tipe media yang bisa didownload */
const MEDIA_TYPES = {
  imageMessage:    'image',
  videoMessage:    'video',
  audioMessage:    'audio',
  stickerMessage:  'sticker',
  documentMessage: 'document'
}

/**
 * Download media dari quoted message (termasuk view-once).
 *
 * Pakai `downloadMediaMessage` dari Baileys + `sock.updateMediaMessage`
 * sebagai reuploadRequest — jadi kalau URL CDN WhatsApp expired,
 * Baileys otomatis minta server WA untuk generate ulang URL-nya,
 * tanpa perlu kirim ulang pesan. Ini yang bikin !rvo bisa andal.
 *
 * @param {object} sock   - Baileys socket (butuh sock.updateMediaMessage)
 * @param {object} message - unwrapped message object
 * @param {string} jid    - chat JID (untuk fake WAMessage key)
 */
async function getQuotedMedia(sock, message, jid = '') {
  const q = getQuotedMessage(message)
  if (!q) return null

  // Unwrap semua varian view-once (V2, V2Extension, V1 legacy)
  const node = q?.viewOnceMessageV2?.message
    || q?.viewOnceMessage?.message
    || q?.viewOnceMessageV2Extension?.message
    || q

  if (!node || typeof node !== 'object') return null

  // Cari tipe media yang ada
  const msgType = Object.keys(node).find(k => MEDIA_TYPES[k])
  if (!msgType) return null

  const ctx = getContextInfo(message)

  // Bangun objek WAMessage yang valid untuk downloadMediaMessage.
  const fakeWAMsg = {
    key: {
      remoteJid: jid || 'status@broadcast',
      fromMe:    false,
      id:        ctx?.stanzaId || `dl_${Date.now()}`
    },
    message: node,
    messageTimestamp: Math.floor(Date.now() / 1000)
  }

  // FIX v14.1: sock.updateMediaMessage tidak tersedia di Baileys 6.7.24.
  // Strategy: coba downloadMediaMessage langsung → fallback ke downloadContentFromMessage.
  let buffer = null
  try {
    buffer = await downloadMediaMessage(fakeWAMsg, 'buffer', {}, {})
  } catch (e1) {
    try {
      const { downloadContentFromMessage } = await import('@whiskeysockets/baileys')
      const stream = await downloadContentFromMessage(node[msgType], msgType.replace('Message', ''))
      const chunks = []
      for await (const chunk of stream) chunks.push(chunk)
      buffer = Buffer.concat(chunks)
    } catch (e2) {
      throw new Error('Media sudah expired atau tidak bisa diakses. Minta pengirimnya kirim ulang dalam 30 detik.')
    }
  }

  if (!buffer || buffer.length < 64) {
    throw new Error('Buffer media kosong — media mungkin sudah expired')
  }

  const mime = node[msgType]?.mimetype || ''
  return { buffer, type: MEDIA_TYPES[msgType], mime }
}

async function sendError(sock, jid, label, err) {
  return sendBranded(sock, jid, `*${label} GAGAL*\n\n${err?.message || 'Coba lagi beberapa saat.'}`)
}

/**
 * Kirim reaction emoji ke pesan (untuk progress indicator).
 * Silent fail — emoji adalah kosmetik, bukan fungsional.
 *
 * ⏱️  = sedang diproses
 * ✅  = selesai
 * ❌  = gagal
 */
const react = (sock, msgKey, emoji) =>
  sock.sendMessage(msgKey.remoteJid, { react: { text: emoji, key: msgKey } }).catch(() => {})

export async function handleFeatures(sock, jid, message, rawMsg, command, args) {
  const text = args.join(' ').trim()
  const q = getQuotedMessage(message)

  // ── Image/video enhancement ──────────────────────────────────────────────
  if (['hd', 'remini', 'hdr'].includes(command)) {
    if (!q) return sendBranded(sock, jid, `*${command.toUpperCase()}*\nReply gambar dulu, baru ketik *!${command}*.`)
    await react(sock, rawMsg.key, '⏱️')
    try {
      const media = await getQuotedMedia(sock, message, jid)
      if (!media || !['image', 'sticker'].includes(media.type)) {
        await react(sock, rawMsg.key, '❌')
        return sendBranded(sock, jid, `*${command.toUpperCase()}*\nFitur ini hanya untuk gambar atau sticker.`)
      }
      let result
      if (command === 'remini') {
        try {
          const form = new FormData()
          form.append('model_version', '1')
          form.append('image', new Blob([media.buffer], { type: 'image/jpeg' }), 'enhance_image_body.jpg')
          const out = await fetchWithRetry('https://inferenceengine.vyro.ai/enhance', {
            method: 'POST',
            headers: { 'accept-encoding': 'gzip', 'user-agent': 'okhttp/4.9.3', 'connection': 'Keep-Alive' },
            body: form
          }, 120_000, 2)
          if (!out.ok) throw new Error(`Remini HTTP ${out.status}`)
          result = Buffer.from(await out.arrayBuffer())
        } catch (err) {
          logger.debug({ err: err?.message, provider: 'vyro-remini' }, 'Remini provider failed, fallback ke HDV3')
          const url = await uploadUguu(media.buffer, 'image.jpg', 'image/jpeg')
          result = await buffer(`https://api-faa.my.id/faa/hdv3?image=${encodeURIComponent(url)}`, {}, 120_000)
        }
      } else {
        try {
          const url = await uploadUguu(media.buffer, 'image.jpg', 'image/jpeg')
          result = await buffer(`https://api-faa.my.id/faa/hdv3?image=${encodeURIComponent(url)}`, {}, 120_000)
        } catch (err) {
          logger.debug({ err: err?.message }, 'HDV3 fallback failed')
          throw err
        }
      }
      await react(sock, rawMsg.key, '✅')
      return sock.sendMessage(jid, { image: result, caption: `${settings.botName}\nMode: ${command.toUpperCase()}\nSelesai.` }, { quoted: rawMsg })
    } catch (err) {
      await react(sock, rawMsg.key, '❌')
      return sendError(sock, jid, 'Image enhancement', err)
    }
  }

  if (command === 'removebg') {
    if (!q) return sendBranded(sock, jid, '*REMOVEBG*\nReply gambar dulu, baru ketik *!removebg*.')
    await react(sock, rawMsg.key, '⏱️')
    try {
      const media = await getQuotedMedia(sock, message, jid)
      if (!media || !['image', 'sticker'].includes(media.type)) {
        await react(sock, rawMsg.key, '❌')
        return sendBranded(sock, jid, '*REMOVEBG*\nFitur ini hanya untuk gambar atau sticker.')
      }
      const form = new FormData()
      form.append('image', new Blob([media.buffer], { type: 'image/jpeg' }), 'image.jpg')
      form.append('format', 'png')
      form.append('model', 'v1')
      const out = await fetchWithTimeout('https://api2.pixelcut.app/image/matte/v1', {
        method: 'POST',
        headers: { 'accept': 'application/json, text/plain, */*', 'x-locale': 'en', 'x-client-version': 'web:pixa.com:4a5b0af2', 'origin': 'https://www.pixa.com', 'referer': 'https://www.pixa.com/' },
        body: form
      }, 120_000)
      if (!out.ok) throw new Error(`Remove background HTTP ${out.status}`)
      const result = Buffer.from(await out.arrayBuffer())
      await react(sock, rawMsg.key, '✅')
      return sock.sendMessage(jid, { image: result, caption: `${settings.botName}\nBackground berhasil dihapus.` }, { quoted: rawMsg })
    } catch (err) {
      await react(sock, rawMsg.key, '❌')
      return sendError(sock, jid, 'Remove background', err)
    }
  }

  if (['enhancevideo', 'hdvideo', 'hdvid'].includes(command)) {
    if (!q) return sendBranded(sock, jid, `*${command.toUpperCase()}*\nReply video dulu, baru ketik *!${command}*.`)
    await react(sock, rawMsg.key, '⏱️')
    try {
      const media = await getQuotedMedia(sock, message, jid)
      if (!media || media.type !== 'video') {
        await react(sock, rawMsg.key, '❌')
        return sendBranded(sock, jid, `*${command.toUpperCase()}*\nFitur ini hanya untuk video.`)
      }
      const url = await uploadCatbox(media.buffer, 'video.mp4', media.mime)
      const data = await json(`https://api-faa.my.id/faa/hdvid?url=${encodeURIComponent(url)}`, {}, 180_000)
      const resultUrl = data?.result?.download_url
      if (!resultUrl) throw new Error('Provider tidak mengembalikan video hasil')
      await react(sock, rawMsg.key, '✅')
      return sock.sendMessage(jid, { video: { url: resultUrl }, caption: `${settings.botName}\nVideo enhancement selesai.\nQuality: ${data?.result?.quality || '-'}` }, { quoted: rawMsg })
    } catch (err) {
      await react(sock, rawMsg.key, '❌')
      return sendError(sock, jid, 'Video enhancement', err)
    }
  }

  // ── Quote / fake chat / TTS ──────────────────────────────────────────────
  if (command === 'quote') {
    if (!text) return sendBranded(sock, jid, '*QUOTE GENERATOR*\nFormat: `!quote Nama @handle "waktu" true isi_quote URL_PFP`\nAtau reply gambar sebagai PFP.')
    try {
      const parts = text.match(/"[^"]+"|\S+/g) || []
      const username = parts.shift() || 'User'
      const handle = parts.shift() || '@user'
      const verifiedIndex = parts.findIndex(v => /^(true|false)$/i.test(v))
      if (verifiedIndex < 0) throw new Error('Parameter verified true/false tidak ditemukan')
      const verified = parts[verifiedIndex].toLowerCase() === 'true'
      const time = parts.slice(0, verifiedIndex).join(' ').replace(/^"|"$/g, '') || 'Now'
      const rest = parts.slice(verifiedIndex + 1)
      let pfp = rest.find(v => /^https?:\/\//i.test(v))
      const tweet = rest.filter(v => v !== pfp).join(' ')
      if (!tweet) throw new Error('Teks quote kosong')
      if (!pfp && q) {
        const media = await getQuotedMedia(sock, message, jid)
        if (media?.type === 'image') pfp = await uploadUguu(media.buffer)
      }
      if (!pfp) throw new Error('Reply gambar atau berikan URL PFP')
      const api = `https://myapi.radzzoffc.tech/gen/quote?username=${encodeURIComponent(username)}&handle=${encodeURIComponent(handle)}&text=${encodeURIComponent(tweet)}&time=${encodeURIComponent(time)}&verified=${verified}&pfp=${encodeURIComponent(pfp)}`
      const img = await buffer(api, {}, 120_000)
      return sock.sendMessage(jid, { image: img, caption: `${settings.botName}\nQuote generated.` }, { quoted: rawMsg })
    } catch (err) { return sendError(sock, jid, 'Quote generator', err) }
  }

  if (['fakechat', 'fakequote'].includes(command)) {
    const [name = 'User', fakeText = ''] = text.split('|').map(v => v.trim())
    if (!fakeText) return sendBranded(sock, jid, `*${command.toUpperCase()}*\nFormat: *!${command} Nama|Pesan palsu*`)
    const participant = q ? (getContextInfo(message)?.participant || getSenderJid(rawMsg) || settings.ownerJid + '@s.whatsapp.net') : `${settings.ownerJid}@s.whatsapp.net`
    const fakeQuoted = { key: { remoteJid: jid, fromMe: false, participant }, message: { conversation: fakeText } }
    return sock.sendMessage(jid, { text: `*FAKECHAT*\n${name}: ${fakeText}` }, { quoted: fakeQuoted })
  }

  if (['say', 'tts', 'gtts'].includes(command)) {
    if (!text) return sendBranded(sock, jid, `*TTS / SAY*\nFormat: *!${command} teks yang ingin diucapkan*\nContoh: *!tts halo apa kabar*`)
    if (text.length > 200) return sendBranded(sock, jid, '*TTS*\nTeks maksimal 200 karakter.')

    // Encode & build multiple TTS URL fallbacks.
    // IP datacenter Pterodactyl sering diblokir URL tertentu,
    // jadi kita prefetch audio sebagai buffer sebelum dikirim ke WA.
    const q = encodeURIComponent(text)
    const ttsUrls = [
      `https://translate.googleapis.com/translate_tts?ie=UTF-8&tl=id&client=gtx&q=${q}`,
      `https://translate.google.com/translate_tts?ie=UTF-8&tl=id&client=tw-ob&q=${q}`,
      `https://translate.google.com/translate_tts?ie=UTF-8&tl=id&client=at&q=${q}`
    ]
    const ttsHeaders = {
      'referer': 'https://translate.google.com/',
      'accept-language': 'id-ID,id;q=0.9,en;q=0.8',
      'user-agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36'
    }
    let audioBuf = null
    let lastErr = null
    for (const tUrl of ttsUrls) {
      try {
        const res = await fetchWithTimeout(tUrl, { headers: ttsHeaders }, 12_000)
        if (!res.ok) throw new Error(`HTTP ${res.status}`)
        audioBuf = Buffer.from(await res.arrayBuffer())
        if (audioBuf.length < 512) throw new Error('Audio terlalu kecil — kemungkinan diblokir')
        break
      } catch (err) { lastErr = err }
    }
    if (!audioBuf) {
      await react(sock, rawMsg.key, '❌')
      return sendBranded(sock, jid, [
        '*TTS GAGAL*',
        '',
        lastErr?.message || 'Semua URL Google TTS diblokir dari IP server ini.',
        '',
        '_Solusi: install gTTS lokal dengan `npm install gtts`_',
        '_Coba lagi nanti, atau gunakan teks yang lebih pendek._'
      ].join('\n'))
    }
    await react(sock, rawMsg.key, '✅')
    return sock.sendMessage(jid, { audio: audioBuf, mimetype: 'audio/mpeg', ptt: true }, { quoted: rawMsg })
  }

  // ── View once ─────────────────────────────────────────────────────────────
  if (['rvo', 'readviewonce', 'viewonce'].includes(command)) {
    if (!q) return sendBranded(sock, jid, [
      '*RVO — Read View Once*',
      '',
      'Reply langsung ke pesan view-once (yang ada ikon ●), lalu ketik *!rvo*.',
      '',
      '_Note: bot harus masih sesi yang sama waktu pesan itu dikirim._'
    ].join('\n'))

    await react(sock, rawMsg.key, '⏱️')
    try {
      const media = await getQuotedMedia(sock, message, jid)
      if (!media) {
        await react(sock, rawMsg.key, '❌')
        return sendBranded(sock, jid, [
          '*RVO GAGAL*',
          '',
          '_Media tidak bisa diambil. Penyebab umum:_',
          '• Pesan sudah terlalu lama (>5-30 menit) — URL CDN WhatsApp expired',
          '• Sesi bot baru restart — key decrypt hilang',
          '• Yang di-reply bukan view-once (reply langsung ke ikon ●)',
          '',
          '_SOLUSI: Minta pengirimnya kirim ulang view-once, lalu langsung reply !rvo (jangan tunggu lama)._'
        ].join('\n'))
      }

      let payload
      if (media.type === 'image') {
        payload = { image: media.buffer, caption: '🔓 *View-once dibuka*' }
      } else if (media.type === 'video') {
        payload = { video: media.buffer, caption: '🔓 *View-once dibuka*' }
      } else if (media.type === 'audio') {
        payload = { audio: media.buffer, mimetype: media.mime, ptt: /ogg|opus/.test(media.mime || '') }
      } else {
        payload = { sticker: media.buffer }
      }

      await react(sock, rawMsg.key, '✅')
      return sock.sendMessage(jid, payload, { quoted: rawMsg })
    } catch (err) {
      await react(sock, rawMsg.key, '❌')
      return sendBranded(sock, jid, [
        '*RVO GAGAL*',
        '',
        err?.message || 'Media tidak bisa diambil.',
        '',
        '_Penyebab umum: URL CDN WhatsApp expired (>5-30 menit) atau bot baru restart._',
        '_SOLUSI: minta pengirimnya kirim ulang view-once, lalu langsung reply !rvo._'
      ].join('\n'))
    }
  }

  // ── AI: Gemini + Groq ──────────────────────────────────────────────────────
  // !ai     = auto — coba Gemini dulu, fallback ke Groq kalau Gemini gagal/kosong.
  // !gemini = paksa Gemini saja.  !groq = paksa Groq saja.
  if (['ai', 'gemini', 'groq'].includes(command)) {
    if (!text) return sendBranded(sock, jid, `*AI CHAT*\nFormat: *!${command} pertanyaan*\nContoh: *!ai apa itu quantum computing?*`)
    await react(sock, rawMsg.key, '⏱️')
    try {
      const prompt = `Kamu adalah asisten pribadi. Jawab dalam bahasa Indonesia secara jelas dan ringkas.\n\n${text}`
      // Alasan gagal per-provider dikumpulkan supaya kalau semuanya gagal,
      // pesan error ke WhatsApp jelas ("Gemini: HTTP 429 | Groq: key belum diisi")
      // — bukan cuma "semua provider gagal" tanpa detail (harus buka log Pterodactyl).
      const failReasons = []

      const askGemini = async () => {
        const geminiKeys = (settings.geminiApiKeys || []).filter(Boolean)
        if (!geminiKeys.length) { failReasons.push('Gemini: API key belum diisi'); return null }
        // Ambil key berikutnya secara round-robin (state sederhana via module-level counter)
        handleFeatures._geminiIdx = ((handleFeatures._geminiIdx || 0) + 1) % geminiKeys.length
        const apiKey = geminiKeys[handleFeatures._geminiIdx]
        try {
          const res = await fetchWithRetry(
            `https://generativelanguage.googleapis.com/v1beta/models/${settings.geminiModel}:generateContent?key=${apiKey}`,
            {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] })
            },
            60_000,
            2
          )
          if (!res.ok) {
            const body = await res.text().catch(() => '')
            logger.debug({ status: res.status, body: body.slice(0, 300), provider: 'gemini' }, 'AI provider returned an error')
            failReasons.push(`Gemini: HTTP ${res.status}`)
            return null
          }
          const d = await res.json()
          const out = d?.candidates?.[0]?.content?.parts?.[0]?.text || null
          if (!out) failReasons.push('Gemini: respons kosong')
          return out
        } catch (err) {
          logger.debug({ err: err?.message, provider: 'gemini' }, 'AI provider failed')
          failReasons.push(`Gemini: ${err?.message || 'gagal terhubung'}`)
          return null
        }
      }

      const askGroq = async () => {
        if (!settings.groqApiKey) { failReasons.push('Groq: API key belum diisi'); return null }
        try {
          const res = await fetchWithRetry('https://api.groq.com/openai/v1/chat/completions', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${settings.groqApiKey}`
            },
            body: JSON.stringify({
              model: settings.groqModel,
              messages: [{ role: 'user', content: prompt }],
              temperature: 0.7
            })
          }, 60_000, 2)
          if (!res.ok) {
            const body = await res.text().catch(() => '')
            logger.debug({ status: res.status, body: body.slice(0, 300), provider: 'groq' }, 'AI provider returned an error')
            failReasons.push(`Groq: HTTP ${res.status}`)
            return null
          }
          const d = await res.json()
          const out = d?.choices?.[0]?.message?.content || d?.choices?.[0]?.text || null
          if (!out) failReasons.push('Groq: respons kosong')
          return out
        } catch (err) {
          logger.debug({ err: err?.message, provider: 'groq' }, 'AI provider failed')
          failReasons.push(`Groq: ${err?.message || 'gagal terhubung'}`)
          return null
        }
      }

      let answer = null
      if (command === 'gemini') {
        answer = await askGemini()
      } else if (command === 'groq') {
        answer = await askGroq()
      } else {
        answer = await askGemini()
        if (!answer) answer = await askGroq()
      }

      if (!answer) throw new Error(failReasons.length ? failReasons.join(' | ') : 'Provider AI tidak mengembalikan jawaban.')
      await react(sock, rawMsg.key, '✅')
      return sendBranded(sock, jid, `*AI CHAT*\n\n${answer}`)
    } catch (err) {
      await react(sock, rawMsg.key, '❌')
      return sendError(sock, jid, 'AI', err)
    }
  }

  if (['aimage', 'aiimage', 'imagine'].includes(command)) {
    if (!text) return sendBranded(sock, jid, `*AI IMAGE*\nFormat: *!${command} deskripsi gambar*\nContoh: *!aimage anime girl with katana in rain*`)
    await react(sock, rawMsg.key, '⏱️')
    try {
      const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(text)}?width=1024&height=1024&nologo=true`
      const img = await buffer(url, {}, 120_000)
      await react(sock, rawMsg.key, '✅')
      return sock.sendMessage(jid, { image: img, caption: `${settings.botName} AI Image\n${text}` }, { quoted: rawMsg })
    } catch (err) {
      await react(sock, rawMsg.key, '❌')
      return sendError(sock, jid, 'AI image', err)
    }
  }

  if (command === 'img2prompt') {
    if (!q) return sendBranded(sock, jid, '*IMG2PROMPT*\nReply gambar dulu, baru ketik *!img2prompt*.')
    return sendBranded(sock, jid, '*IMG2PROMPT*\nFitur ini membutuhkan vision API key yang belum dikonfigurasi.\n_Sengaja tidak dipalsukan sebagai fitur aktif._')
  }

  // ── Anime ────────────────────────────────────────────────────────────────
  if (['anime', 'animesearch'].includes(command)) {
    if (!text) return sendBranded(sock, jid, '*ANIME SEARCH*\nFormat: *!anime judul*\nContoh: *!anime naruto*')
    await react(sock, rawMsg.key, '⏱️')
    try {
      const results = await fetchAnime(text)
      const rows = results.slice(0, 5).map((a, i) => `${i + 1}. *${a.title}*\n   Score: ${a.score ?? '-'} | Episodes: ${a.episodes ?? '-'}${a.id ? ` | MAL ID: ${a.id}` : ''}\n   ${a.url || ''}`)
      await react(sock, rawMsg.key, '✅')
      return sendBranded(sock, jid, `*ANIME SEARCH*\n\n${rows.join('\n\n') || 'Tidak ditemukan.'}`)
    } catch (err) {
      await react(sock, rawMsg.key, '❌')
      return sendError(sock, jid, 'Anime search', err)
    }
  }
  if (command === 'animedetail') {
    if (!args[0]) return sendBranded(sock, jid, '*ANIME DETAIL*\nFormat: *!animedetail MAL_ID*\nDapat MAL ID dari hasil *!anime*.')
    try {
      const a = (await jsonWithRetry(`https://api.jikan.moe/v4/anime/${encodeURIComponent(args[0])}/full`, {}, 30_000)).data
      return sock.sendMessage(jid, { image: { url: a.images?.jpg?.large_image_url || a.images?.jpg?.image_url }, caption: `ANIME DETAIL\n\n${a.title}\nScore: ${a.score ?? '-'}\nEpisodes: ${a.episodes ?? '-'}\nStatus: ${a.status || '-'}\nGenres: ${(a.genres || []).map(x => x.name).join(', ') || '-'}\n\n${a.synopsis || '-'}` }, { quoted: rawMsg })
    } catch (err) { return sendError(sock, jid, 'Anime detail', err) }
  }
  if (command === 'animeschedule') {
    try {
      const data = await jsonWithRetry('https://api.jikan.moe/v4/schedules?filter=tv', {}, 30_000)
      const rows = (data.data || []).slice(0, 12).map(a => `• *${a.title}* — ${a.broadcast?.day || '-'} ${a.broadcast?.time || ''}`)
      return sendBranded(sock, jid, `*ANIME SCHEDULE*\n\n${rows.join('\n')}`)
    } catch (err) { return sendError(sock, jid, 'Anime schedule', err) }
  }

  // ── Search/stalker ───────────────────────────────────────────────────────
  if (['githubstalk', 'ghstalk', 'github'].includes(command)) {
    if (!text) return sendBranded(sock, jid, '*GITHUB STALK*\nFormat: *!githubstalk username*')
    try {
      const r = await json(`https://api.github.com/users/${encodeURIComponent(text)}`, { headers: { accept: 'application/vnd.github+json' } }, 30_000)
      return sock.sendMessage(jid, { image: { url: r.avatar_url }, caption: `GITHUB STALK\n\nUsername: ${r.login}\nName: ${r.name || '-'}\nBio: ${r.bio || '-'}\nID: ${r.id}\nRepo: ${r.public_repos}\nGist: ${r.public_gists}\nFollowers: ${r.followers}\nFollowing: ${r.following}\nCompany: ${r.company || '-'}\nLocation: ${r.location || '-'}\nBlog: ${r.blog || '-'}\nURL: ${r.html_url}` }, { quoted: rawMsg })
    } catch (err) { return sendError(sock, jid, 'GitHub stalk', err) }
  }
  if (['npmstalk', 'npm'].includes(command)) {
    if (!text) return sendBranded(sock, jid, '*NPM INFO*\nFormat: *!npm nama-package*')
    try {
      const r = await json(`https://registry.npmjs.org/${encodeURIComponent(text)}`, {}, 30_000)
      return sendBranded(sock, jid, `*NPM INFO*\n\nName: ${r.name}\nLatest: ${r['dist-tags']?.latest || '-'}\nDescription: ${r.description || '-'}\nAuthor: ${typeof r.author === 'string' ? r.author : r.author?.name || '-'}\nLicense: ${r.license || '-'}\nHomepage: ${r.homepage || '-'}\nRepository: ${r.repository?.url || '-'}\nUpdated: ${r.time?.modified || '-'}`)
    } catch (err) { return sendError(sock, jid, 'NPM info', err) }
  }
  if (['ttstalk', 'tiktokstalk'].includes(command)) {
    if (!text) return sendBranded(sock, jid, '*TIKTOK STALK*\nFormat: *!ttstalk username*')
    try {
      const r = await json(`https://api.nexray.web.id/stalker/tiktok?username=${encodeURIComponent(text)}`, {}, 45_000)
      const d = r?.result
      if (!r?.status || !d) throw new Error('Username TikTok tidak ditemukan')
      const s = d.stats || {}
      return sock.sendMessage(jid, { image: { url: d.avatar || d.profile || d.avatarUrl }, caption: `TIKTOK STALK\n\nName: ${d.name || '-'}\nUsername: @${d.username || text}\nBio: ${d.bio || '-'}\nVerified: ${d.verified ?? '-'}\nPrivate: ${d.private ?? '-'}\nFollowers: ${s.followers ?? '-'}\nFollowing: ${s.following ?? '-'}\nLikes: ${s.likes ?? '-'}\nVideos: ${s.videos ?? '-'}` }, { quoted: rawMsg })
    } catch (err) { return sendError(sock, jid, 'TikTok stalk', err) }
  }
  if (command === 'igstalk') {
    if (!text) return sendBranded(sock, jid, '*INSTAGRAM STALK*\nFormat: *!igstalk username*')
    try {
      const html = await (await fetchWithTimeout(`https://dumpor.com/v/${encodeURIComponent(text)}`, { headers: { 'user-agent': 'Mozilla/5.0' } }, 45_000)).text()
      const clean = v => String(v || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim()
      const profile = html.match(/user__img[^>]*style=["']background-image:\s*url\(["']?([^"')]+)["']?\)/i)?.[1]
      const fullname = clean(html.match(/<h1[^>]*>([^<]+)<\/h1>/i)?.[1])
      const stats = [...html.matchAll(/<li[^>]*>([^<]+)<\/li>/gi)].slice(0, 3).map(x => clean(x[1]))
      return sock.sendMessage(jid, { ...(profile ? { image: { url: profile } } : {}), caption: `INSTAGRAM STALK\n\nUsername: @${text}\nName: ${fullname || '-'}\n${stats.join('\n') || 'Data statistik tidak tersedia.'}` }, { quoted: rawMsg })
    } catch (err) { return sendError(sock, jid, 'Instagram stalk', err) }
  }

  if (command === 'gsmarena') {
    if (!text) return sendBranded(sock, jid, '*GSMARENA*\nFormat: *!gsmarena nama HP*\nContoh: *!gsmarena samsung galaxy s24*')
    try {
      const r = await json(`https://api.siputzx.my.id/api/s/gsmarena?query=${encodeURIComponent(text)}`, {}, 45_000)
      const rows = (r?.data || []).slice(0, 5)
      if (!rows.length) return sendBranded(sock, jid, `*GSMARENA*\nPerangkat *${text}* tidak ditemukan.`)
      for (const hp of rows) {
        await sock.sendMessage(jid, { image: { url: hp.thumbnail }, caption: `${hp.name || '-'}\n\n${hp.description || '-'}` }, { quoted: rawMsg })
      }
      return true
    } catch (err) { return sendError(sock, jid, 'GSMArena search', err) }
  }

  if (['wastalk', 'whatsappstalk', 'wastalker'].includes(command)) {
    if (!isGroupJid(jid)) return sendBranded(sock, jid, '*WASTALK*\nCommand ini hanya untuk grup.')
    const number = String(text || '').replace(/\D/g, '')
    if (number.length < 8) return sendBranded(sock, jid, '*WASTALK*\nFormat: *!wastalk 628xxxxxxxxx*')
    try {
      const target = `${number}@s.whatsapp.net`
      const check = await sock.onWhatsApp(target)
      if (!check?.[0]?.exists) return sendBranded(sock, jid, `*WASTALK*\nNomor *${number}* tidak terdaftar di WhatsApp.`)
      const name = await sock.getName(target).catch(() => '')
      const status = await sock.fetchStatus(target).catch(() => null)
      return sendBranded(sock, jid, `*WHATSAPP STALK*\n\nNumber: ${number}\nName: ${name || '-'}\nStatus: ${status?.status || '-'}\nURL: https://wa.me/${number}`)
    } catch (err) { return sendError(sock, jid, 'WhatsApp stalk', err) }
  }

  // ── Fun ──────────────────────────────────────────────────────────────────
  if (command === '8ball') {
    if (!text) return sendBranded(sock, jid, '*8BALL*\nFormat: *!8ball pertanyaan*')
    const answers = ['✅ Ya.', '❌ Tidak.', '🔮 Kemungkinan besar.', '🤷 Belum tentu.', '⏳ Coba lagi nanti.', '🌟 Jawabannya terlihat positif.', '⚠️ Jangan berharap terlalu tinggi.']
    return sendBranded(sock, jid, `*🎱 8BALL*\n\nPertanyaan: ${text}\nJawaban: *${answers[Math.floor(Math.random() * answers.length)]}*`)
  }
  if (command === 'rate') {
    if (!text) return sendBranded(sock, jid, '*RATE*\nFormat: *!rate sesuatu*')
    return sendBranded(sock, jid, `*📊 RATE*\n\n${text}\nNilai: *${1 + Math.floor(Math.random() * 100)}%*`)
  }
  if (['stupidcheck', 'uncleancheck', 'hotcheck', 'smartcheck', 'greatcheck', 'evilcheck', 'dogcheck', 'coolcheck', 'waifucheck'].includes(command)) {
    if (!text) return sendBranded(sock, jid, `*${command.toUpperCase()}*\nFormat: *!${command} nama*`)
    const emoji = { hotcheck:'🔥', smartcheck:'🧠', coolcheck:'😎', waifucheck:'🌸', greatcheck:'⭐', evilcheck:'😈', dogcheck:'🐶', stupidcheck:'💀', uncleancheck:'🤡' }
    return sendBranded(sock, jid, `*${emoji[command] || '🎯'} ${command.toUpperCase()}*\n\n${text}: *${1 + Math.floor(Math.random() * 100)}%*`)
  }
  if (command === 'fact') {
    try {
      const r = await json('https://uselessfacts.jsph.pl/api/v2/facts/random?language=en')
      return sendBranded(sock, jid, `*💡 RANDOM FACT*\n\n${r.text}`)
    } catch (err) {
      logger.debug({ err: err?.message, provider: 'uselessfacts' }, 'Fact provider failed')
      return sendBranded(sock, jid, '*FACT*\nProvider sedang tidak tersedia.')
    }
  }
  if (command === 'pick') {
    if (!isGroupJid(jid)) return sendBranded(sock, jid, '*PICK*\nCommand ini hanya untuk grup.')
    const meta = await sock.groupMetadata(jid)
    const members = (meta.participants || []).map(p => p.id).filter(Boolean)
    if (!members.length) return sendBranded(sock, jid, '*PICK*\nMember grup tidak ditemukan.')
    const chosen = members[Math.floor(Math.random() * members.length)]
    return sock.sendMessage(jid, { text: `*🎯 PICK*\n\nYang paling *${text || 'beruntung'}* di sini adalah @${chosen.split('@')[0]}! 🎉`, mentions: [chosen] }, { quoted: rawMsg })
  }
  if (command === 'jodoh' || command === 'jodohku') {
    if (!isGroupJid(jid)) return sendBranded(sock, jid, '*JODOH*\nCommand ini hanya untuk grup.')
    const meta = await sock.groupMetadata(jid)
    const members = (meta.participants || []).map(p => p.id).filter(Boolean)
    const chosen = members[Math.floor(Math.random() * members.length)]
    const me = getSenderJid(rawMsg) || settings.ownerJid + '@s.whatsapp.net'
    return sock.sendMessage(jid, { text: `*💕 JODOH*\n\n@${me.split('@')[0]} × @${chosen.split('@')[0]} 💘`, mentions: [me, chosen] }, { quoted: rawMsg })
  }

  // ── Group tools ──────────────────────────────────────────────────────────
  if (['tagall', 'hidetag', 'groupinfo', 'linkgroup', 'add', 'kick', 'promote', 'demote', 'setname', 'setdesc'].includes(command)) {
    if (!isGroupJid(jid)) return sendBranded(sock, jid, `*${command.toUpperCase()}*\nCommand ini hanya untuk grup.`)
    let meta = null
    try { meta = await sock.groupMetadata(jid) } catch (err) { return sendError(sock, jid, 'Group metadata', err) }
    const botIds = [sock.user?.id, sock.user?.lid, sock.user?.phoneNumber].filter(Boolean).map(x => String(x).split('@')[0].split(':')[0])
    const botParticipant = (meta.participants || []).find(p => botIds.includes(String(p.id || '').split('@')[0].split(':')[0]) || botIds.includes(String(p.jid || '').split('@')[0].split(':')[0]))
    const botAdmin = ['admin', 'superadmin'].includes(botParticipant?.admin)
    if (['add', 'kick', 'promote', 'demote', 'setname', 'setdesc'].includes(command) && !botAdmin) return sendBranded(sock, jid, `*${command.toUpperCase()}*\nBot harus menjadi *admin grup* untuk command ini.`)

    if (command === 'tagall' || command === 'hidetag') {
      const mentions = (meta.participants || []).map(p => p.id).filter(Boolean)
      const body = text || 'Semua member.'
      // tagall  = body + daftar @tag yang kelihatan di teks
      // hidetag = body saja, tapi `mentions` tetap diisi semua peserta —
      //           semua tetap ke-notif, cuma daftar tag-nya tidak tampil di teks
      const visibleTagList = command === 'tagall' ? `\n\n${mentions.map(x => '@' + x.split('@')[0]).join(' ')}` : ''
      return sock.sendMessage(jid, { text: `${body}${visibleTagList}`, mentions }, { quoted: rawMsg })
    }
    if (command === 'groupinfo') return sendBranded(sock, jid, `*GROUP INFO*\n\nName: ${meta.subject}\nID: ${jid}\nMembers: ${(meta.participants || []).length}\nDescription: ${meta.desc || '-'}`)
    if (command === 'linkgroup') {
      const code = await sock.groupInviteCode(jid)
      return sendBranded(sock, jid, `*GROUP LINK*\n\nhttps://chat.whatsapp.com/${code}`)
    }
    const mentioned = getMentionedJids(message)
    const target = mentioned[0] || getContextInfo(message)?.participant || args.find(x => /^\d{8,15}$/.test(x)) && `${args.find(x => /^\d{8,15}$/.test(x))}@s.whatsapp.net`
    if (['add', 'kick', 'promote', 'demote'].includes(command)) {
      if (!target) return sendBranded(sock, jid, `*${command.toUpperCase()}*\nTag atau reply target dulu.`)
      if (command === 'add') await sock.groupParticipantsUpdate(jid, [target], 'add')
      if (command === 'kick') await sock.groupParticipantsUpdate(jid, [target], 'remove')
      if (command === 'promote') await sock.groupParticipantsUpdate(jid, [target], 'promote')
      if (command === 'demote') await sock.groupParticipantsUpdate(jid, [target], 'demote')
      return sock.sendMessage(jid, { text: `*${command.toUpperCase()}* selesai untuk @${target.split('@')[0]}. ✅`, mentions: [target] }, { quoted: rawMsg })
    }
    if (command === 'setname') {
      if (!text) return sendBranded(sock, jid, '*SETNAME*\nFormat: *!setname nama baru*')
      await sock.groupUpdateSubject(jid, text)
      return sendBranded(sock, jid, `*SETNAME*\nNama grup diperbarui jadi: *${text}* ✅`)
    }
    if (command === 'setdesc') {
      if (!text) return sendBranded(sock, jid, '*SETDESC*\nFormat: *!setdesc deskripsi baru*')
      await sock.groupUpdateDescription(jid, text)
      return sendBranded(sock, jid, '*SETDESC*\nDeskripsi grup berhasil diperbarui ✅')
    }
  }

  return false
}

export const FEATURE_COMMANDS = new Set([
  'hd','remini','hdr','removebg','enhancevideo','hdvideo','hdvid','quote','fakechat','fakequote','say','tts','gtts','rvo','readviewonce','viewonce',
  'ai','gemini','groq','aimage','aiimage','imagine','img2prompt',
  'anime','animesearch','animedetail','animeschedule','githubstalk','ghstalk','github','npmstalk','npm','ttstalk','tiktokstalk','igstalk','gsmarena','wastalk','whatsappstalk','wastalker',
  '8ball','rate','stupidcheck','uncleancheck','hotcheck','smartcheck','greatcheck','evilcheck','dogcheck','coolcheck','waifucheck','fact','pick','jodoh','jodohku',
  'tagall','hidetag','groupinfo','linkgroup','add','kick','promote','demote','setname','setdesc'
])
