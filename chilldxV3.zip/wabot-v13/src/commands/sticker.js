import { getQuotedMessage } from '../utils/message.js'
import {
  buildStickerWithFormatter,
  downloadAnyMedia,
  downloadQuotedMedia,
  hasDirectMedia,
  imageToSticker,
  videoToSticker
} from '../services/media.js'
import { attachStickerMetadata } from '../utils/exif.js'
import { sendBranded } from '../services/banner.js'
import { settings } from '../../settings.js'
import { sweepTemp } from '../services/downloader.js'

/**
 * ─── MODE "KETIK !s DULU, KIRIM FOTO KEMUDIAN" ───────────────────────────────
 * Kalau `!s` dikirim tanpa media & tanpa reply, chat itu "di-arm". Foto/video
 * berikutnya dari owner di chat yang sama langsung dijadikan sticker.
 */
const pending = new Map()
const MAX_PENDING = 200

function sweepPending() {
  const now = Date.now()
  const ttl = Number(settings.stickerPendingMs) || 120_000
  for (const [key, entry] of pending) {
    if (!entry || now - entry.at > ttl) pending.delete(key)
  }
  while (pending.size > MAX_PENDING) {
    const first = pending.keys().next().value
    if (first === undefined) break
    pending.delete(first)
  }
}

export function armPendingSticker(jid, description = '') {
  sweepPending()
  pending.set(jid, { at: Date.now(), description })
  sweepPending()
}

export function consumePendingSticker(jid) {
  sweepPending()
  const entry = pending.get(jid)
  if (!entry) return null
  pending.delete(jid)
  const ttl = Number(settings.stickerPendingMs) || 120_000
  if (Date.now() - entry.at > ttl) return null
  return entry
}

/**
 * Pipeline 1: wa-sticker-formatter (FULL, 512x512, transparan, metadata
 * tertanam) — hasil paling konsisten bagus, sama seperti bot teman.
 * Pipeline 2 (fallback): sharp/ffmpeg bawaan + tempel metadata manual.
 */
async function buildSticker(media, description) {
  const formatted = await buildStickerWithFormatter(media.buffer, description)
  if (formatted) return formatted

  const raw = media.type === 'image'
    ? await imageToSticker(media.buffer)
    : await videoToSticker(media.buffer)
  return attachStickerMetadata(raw, description)
}

/**
 * Dipakai untuk 3 cara pakai:
 *   1. `!s` / `!sticker` sambil reply foto/video/sticker
 *   2. kirim foto/video dengan CAPTION `!s <deskripsi>`
 *   3. ketik `!s` duluan, lalu kirim fotonya
 */
export async function handleSticker(sock, jid, message, args = []) {
  await sweepTemp().catch(() => {})
  const description = args.join(' ').trim()

  const source = hasDirectMedia(message)
    ? message                      // foto/video dikirim bareng caption !s
    : getQuotedMessage(message)    // atau hasil reply

  if (!source) {
    armPendingSticker(jid, description)
    return sendBranded(sock, jid, [
      '*STICKER — MODE SIAP*',
      '',
      'Kirim foto/videonya sekarang, otomatis jadi sticker.',
      '',
      'Cara lain:',
      `▸ kirim foto dengan caption \`${settings.prefix}s\``,
      `▸ reply foto/video lalu ketik \`${settings.prefix}s\``
    ].join('\n'))
  }

  try {
    const media = hasDirectMedia(message)
      ? await downloadAnyMedia(source)
      : await downloadQuotedMedia(source)

    if (!media) {
      return sendBranded(sock, jid, 'Media itu bukan foto/video yang didukung.')
    }

    const sticker = await buildSticker(media, description)
    return sock.sendMessage(jid, { sticker })
  } catch (error) {
    return sendBranded(sock, jid, `*STICKER GAGAL*\n\n${error.message || 'Media tidak dapat diproses.'}`)
  }
}

/** Dipanggil index.js saat foto masuk setelah `!s` diketik duluan. */
export async function handlePendingSticker(sock, jid, message, entry) {
  await sweepTemp().catch(() => {})
  try {
    const media = await downloadAnyMedia(message)
    if (!media) return
    const sticker = await buildSticker(media, entry?.description || '')
    return sock.sendMessage(jid, { sticker })
  } catch (error) {
    return sendBranded(sock, jid, `*STICKER GAGAL*\n\n${error.message || 'Media tidak dapat diproses.'}`)
  }
}
