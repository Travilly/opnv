import os from 'node:os'
import { settings } from '../../settings.js'
import { getAfk } from '../services/afk.js'
import { sendBranded } from '../services/banner.js'
import { buildMenuCard } from '../services/menu-card.js'

export { prewarmBanner } from '../services/banner.js'

// Menu ini sengaja mengikuti pola ALYA: menu utama singkat, lalu ALL MENU
// berisi daftar command lengkap per kategori + deskripsi. Yang ditampilkan
// hanya command yang benar-benar ditangani WPSBot.
const sections = [
  ['OWNER / SYSTEM', [
    ['!menu', 'Menu utama singkat.'],
    ['!allmenu', 'Menampilkan seluruh command berdasarkan kategori.'],
    ['!help', 'Bantuan + info bot + cara pakai command.'],
    ['!status', 'Status runtime, memory, temporary files, dan statistik.'],
    ['!booster', 'Status queue dan optimasi performa downloader.'],
    ['!afk [alasan]', 'Aktifkan/nonaktifkan mode AFK di chat ini.'],
    ['!del', 'Reply pesan lalu hapus untuk semua jika diizinkan.'],
  ]],
  ['MEDIA / ENHANCEMENT', [
    ['!hd', 'Meningkatkan kualitas gambar.'],
    ['!remini', 'Enhancement gambar gaya Remini.'],
    ['!removebg', 'Menghapus background gambar.'],
    ['!enhancevideo', 'Meningkatkan kualitas video.'],
    ['!convert mp3', 'Konversi audio/video menjadi MP3.'],
    ['!convert gif', 'Konversi video menjadi GIF-style WhatsApp.'],
  ]],
  ['DOWNLOAD', [
    ['!dl <link>', 'Download video/media dari URL.'],
    ['!tiktok <link>', 'Download media TikTok.'],
    ['!ig <link>', 'Download media Instagram.'],
    ['!fb <link>', 'Download media Facebook.'],
    ['!twitter <link>', 'Download media X/Twitter.'],
    ['!threads <link>', 'Download media Threads.'],
    ['!pinterest <link>', 'Download media Pinterest.'],
    ['!mediafire <link>', 'Download file MediaFire.'],
    ['!spotify <judul/link>', 'Search track atau lihat metadata Spotify.'],
    ['!spotifyinfo <track>', 'Detail track Spotify.'],
    ['!spotifyembed <link>', 'Metadata Spotify via oEmbed.'],
    ['!yt <link>', 'Download media YouTube.'],
    ['!play <judul>', 'Cari hasil pertama lalu kirim audio/video.'],
    ['!mp3 <link>', 'Ambil audio/MP3 dari URL.'],
  ]],
  ['SEARCH / STALK', [
    ['!search <query>', 'Cari informasi menggunakan web search.'],
    ['!githubstalk <user>', 'Informasi profil GitHub.'],
    ['!npm <package>', 'Informasi package NPM.'],
    ['!igstalk <user>', 'Informasi profil Instagram.'],
    ['!ttstalk <user>', 'Informasi profil TikTok.'],
    ['!gsmarena <query>', 'Cari perangkat di GSMArena.'],
    ['!wastalk <628xxx>', 'Cek informasi nomor WhatsApp di grup.'],
  ]],
  ['AI', [
    ['!ai <pertanyaan>', 'Chat AI — otomatis Gemini, fallback ke Groq.'],
    ['!gemini <pertanyaan>', 'Chat AI — paksa pakai Gemini.'],
    ['!groq <pertanyaan>', 'Chat AI — paksa pakai Groq.'],
    ['!aimage <prompt>', 'Generate gambar dari prompt.'],
  ]],
  ['MESSAGE', [
    ['!quote <data>', 'Generate gambar quote.'],
    ['!fakechat Nama|Pesan', 'Buat tampilan chat palsu untuk prank/desain.'],
    ['!tts <teks>', 'Text-to-speech menjadi voice note.'],
    ['!rvo', 'Reply media view-once lalu buka kembali sebagai media biasa.'],
  ]],
  ['STICKER', [
    ['!sticker', 'Reply/kirim gambar atau video menjadi sticker.'],
  ]],
  ['ANIME', [
    ['!anime <judul>', 'Cari anime.'],
    ['!animedetail <mal_id>', 'Detail anime berdasarkan MAL ID.'],
    ['!animeschedule', 'Jadwal tayang anime.'],
  ]],
  ['FUN', [
    ['!8ball <pertanyaan>', 'Jawaban acak ala 8-ball.'],
    ['!rate <sesuatu>', 'Nilai acak 1–100%.'],
    ['!fact', 'Fakta acak.'],
    ['!pick [kategori]', 'Pilih satu member secara acak di grup.'],
    ['!jodoh', 'Pilih soulmate acak dari member grup.'],
    ['!hotcheck <nama>', 'Persentase acak untuk fun check.'],
    ['!smartcheck <nama>', 'Fun check persentase.'],
    ['!coolcheck <nama>', 'Fun check persentase.'],
    ['!waifucheck <nama>', 'Fun check persentase.'],
  ]],
  ['GROUP', [
    ['!tagall [pesan]', 'Mention semua member.'],
    ['!hidetag [pesan]', 'Mention semua member tanpa daftar teks.'],
    ['!groupinfo', 'Informasi grup.'],
    ['!linkgroup', 'Ambil link undangan grup.'],
    ['!add <nomor>', 'Tambah member.'],
    ['!kick <reply/tag>', 'Keluarkan member.'],
    ['!promote <reply/tag>', 'Jadikan member admin.'],
    ['!demote <reply/tag>', 'Turunkan admin.'],
    ['!setname <nama>', 'Ganti nama grup.'],
    ['!setdesc <deskripsi>', 'Ganti deskripsi grup.'],
    ['!welcome on|off|status', 'Atur welcome sederhana dan tersimpan.'],
  ]],
  ['TOOLS', [
    ['!convert <mode>', 'Tool konversi media.'],
    ['!search <query>', 'Web search.'],
    ['!status', 'Dashboard status bot.'],
  ]],
]

const descriptions = {
  'OWNER / SYSTEM': 'Navigasi, bantuan, status, dan command utama bot.',
  'MEDIA / ENHANCEMENT': 'HD, enhancement, remove background, dan converter.',
  DOWNLOAD: 'Downloader media dan audio dari berbagai sumber.',
  'SEARCH / STALK': 'Pencarian web dan informasi akun/perangkat.',
  AI: 'AI chat (Gemini/Groq) dan image generation.',
  MESSAGE: 'Quote, fake chat, TTS, dan view-once.',
  STICKER: 'Pembuatan dan konversi sticker.',
  ANIME: 'Search, detail, dan schedule anime.',
  FUN: 'Fitur hiburan ringan.',
  GROUP: 'Utility grup; sebagian membutuhkan bot admin.',
  TOOLS: 'Command utilitas tambahan.',
}

function sectionBlock(title, items) {
  const lines = [`┏━━〔 ${title} 〕`]
  for (const [cmd, desc] of items) {
    lines.push(`┣ ${cmd}`, `┃   ${desc}`)
  }
  lines.push('┗━━━━━━━━━━━━━━━━━━━━')
  return lines.join('\n')
}

export function menuCaption(jid) {
  const afk = jid ? getAfk(jid) : null
  const status = afk ? 'SLEEP / AFK' : 'READY / ONLINE'
  return [
    `╭────────〔 ${settings.botName} 〕`,
    `│ Version : v${settings.botVersion}`,
    `│ Access  : OWNER ONLY`,
    `│ Mode    : SELF`,
    `│ Status  : ${status}`,
    `╰────────────────────`,
    '',
    'PROFILE',
    `│ Name    : ${settings.adminName}`,
    `│ Prefix  : ${settings.prefix}`,
    '',
    'QUICK ACCESS',
    `│ ${settings.prefix}allmenu`,
    `│ ${settings.prefix}help`,
    '',
    settings.footerText
  ].join('\n')
}

export function helpText() {
  const mem = process.memoryUsage()
  const uptime = Math.floor(process.uptime())
  return [
    `╭━━━━〔 ${settings.botName} HELP / INFO 〕━━━━╮`,
    `┃ Version : v${settings.botVersion}`,
    `┃ Access  : OWNER ONLY`,
    `┃ Mode    : SELF / PRIVATE`,
    `┃ Prefix  : ${settings.prefix}`,
    `┃ Node    : ${process.version}`,
    `┃ RAM     : ${Math.round(mem.rss / 1024 / 1024)} MB`,
    `┃ Uptime  : ${uptime}s`,
    `╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯`,
    '',
    'COMMAND GUIDE',
    '',
    `• ${settings.prefix}help` ,
    '  Pusat bantuan utama bot. `!info` adalah alias kompatibilitas.',
    '',
    `• ${settings.prefix}allmenu`,
    '  Menampilkan seluruh fitur + deskripsi per kategori.',
    '',
    `• ${settings.prefix}dl <link>`,
    '  Download media dari link.',
    `• ${settings.prefix}mp3 <link>`,
    '  Ambil audio dari link.',
    `• ${settings.prefix}search <query>`,
    '  Cari informasi di web.',
    `• ${settings.prefix}hd`,
    '  Reply gambar, lalu gunakan command.',
    `• ${settings.prefix}removebg`,
    '  Reply gambar untuk hapus background.',
    `• ${settings.prefix}s`,
    '  Reply gambar/video untuk membuat sticker.',
    `• ${settings.prefix}del`,
    '  Reply pesan yang ingin dihapus.',
    '',
    'Untuk command lain, buka !allmenu.',
    '',
    `HELP / CONTACT`,
    'Bila ada fitur rusak atau butuh bantuan, hubungi owner bot.',
    `Owner : ${settings.adminName}`,
    `WhatsApp : https://wa.me/${String(settings.ownerJid).replace(/\D/g, '')}`,
    '',
    settings.footerText,
  ].join('\n')
}

export function infoText() {
  return helpText()
}

export function allMenuText() {
  const totalCommands = sections.reduce((n, [, items]) => n + items.length, 0)
  const body = [
    `╭━━━━〔 ${settings.botName} ALL MENU 〕━━━━╮`,
    `┃ Version : v${settings.botVersion}`,
    '┃ Mode    : PRIVATE / SELF',
    '┃ Access  : OWNER ONLY',
    `┃ Prefix  : ${settings.prefix}`,
    `┃ Listed  : ${totalCommands} command entries`,
    `╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯`,
    '',
    'DAFTAR FITUR',
    '',
    ...sections.flatMap(([title, items]) => [
      sectionBlock(title, items),
      `> ${descriptions[title] || 'Feature category.'}`,
      ''
    ]),
    'CATATAN',
    'Format command akan meminta parameter atau reply media bila diperlukan.',
    'Gunakan !help untuk panduan singkat command penting.',
    '',
    settings.footerText,
  ]
  return body.join('\n')
}

export async function sendMenu(sock, jid) {
  const caption = menuCaption(jid)
  const card = await buildMenuCard(caption).catch(() => null)
  if (!card) return sendBranded(sock, jid, caption)
  return sock.sendMessage(jid, {
    image: card,
    mimetype: 'image/png',
    caption: `*${settings.botName}*\n${settings.footerText}`
  })
}

export async function sendAllMenu(sock, jid) {
  return sendBranded(sock, jid, allMenuText())
}

export function sendCategoryMenu(sock, jid, category) {
  const normalized = String(category || '').toUpperCase()
  const found = sections.find(([title]) => title.toUpperCase() === normalized)
  if (!found) return false
  return sock.sendMessage(jid, {
    text: [
      `╭━━━━〔 ${found[0]} 〕━━━━╮`,
      `┃ ${descriptions[found[0]] || ''}`,
      `╰━━━━━━━━━━━━━━━━━━━━╯`,
      '',
      sectionBlock(found[0], found[1]),
      '',
      settings.footerText,
    ].join('\n')
  })
}

export const CATEGORY_ALIASES = {
  ownermenu: 'OWNER / SYSTEM',
  systemmenu: 'OWNER / SYSTEM',
  toolsmenu: 'TOOLS',
  mediamenu: 'MEDIA / ENHANCEMENT',
  downloadmenu: 'DOWNLOAD',
  searchmenu: 'SEARCH / STALK',
  searchstalkmenu: 'SEARCH / STALK',
  aimenu: 'AI',
  messagemenu: 'MESSAGE',
  quotemenu: 'MESSAGE',
  stickermenu: 'STICKER',
  animemenu: 'ANIME',
  funmenu: 'FUN',
  groupmenu: 'GROUP',
}
