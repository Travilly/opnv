import { clearAfk, formatDuration, getAfk, setAfk } from '../services/afk.js'
import { sendBranded } from '../services/banner.js'
import { settings } from '../../settings.js'

const MAX_REASON = 120

function clock(ts) {
  return new Date(ts).toLocaleString('id-ID', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: 'short' })
}

export function afkOnText(entry) {
  return [
    '╭──────────〔 *AFK MODE* 〕',
    `│ Alasan : _${entry.reason || 'sedang istirahat'}_`,
    `│ Mulai  : \`${clock(entry.since)}\``,
    '│ Status : `AFK TIME`',
    '╰────────────────────────',
    '',
    'Aku pergi, Adios😹🥀.'
  ].join('\n')
}

export function afkOffText(previous) {
  return [
    '╭──────────〔 *AFK OFF* 〕',
    `│ Durasi : *${formatDuration(Date.now() - previous.since)}*`,
    '│ Status : `I kembali`',
    '╰────────────────────────',
    '',
    'Orang ganteng sudah kembali🤭💜.'
  ].join('\n')
}

export function afkStatusText(entry) {
  return [
    '╭──────────〔 *MASIH AFK* 〕',
    `│ Alasan : _${entry.reason || 'Gausa Tag Su'}_`,
    `│ Durasi : *${formatDuration(Date.now() - entry.since)}*`,
    '╰────────────────────────',
    '',
    'Lagi sibokk,',
  ].join('\n')
}

export function afkMentionText(entry, ownerLabel) {
  return [
    `╭──────────〔 *${ownerLabel} SEDANG AFK* 〕`,
    `│ Alasan : _${entry.reason || 'Gausa Tag su'}_`,
    `│ Durasi : *${formatDuration(Date.now() - entry.since)}*`,
    '╰────────────────────────',
    '',
    'gausa tag klo ga penting.',
    'lagi sibokk, nanti ajalah wok.'
  ].join('\n')
}

export async function handleAfk(sock, jid, args) {
  const sub = (args[0] || '').toLowerCase()

  if (sub === 'off' || sub === 'stop' || sub === 'balik' || sub === 'kembali') {
    const previous = getAfk(jid)
    if (!previous) {
      return sendBranded(sock, jid, '*AFK*\nTidak sedang aktif di chat ini.')
    }
    clearAfk(jid)
    return sendBranded(sock, jid, afkOffText(previous))
  }

  const existing = getAfk(jid)
  if (!args.length && existing) {
    // !afk tanpa argumen saat SUDAH afk -> tampilkan status, bukan reset alasan
    return sendBranded(sock, jid, afkStatusText(existing))
  }

  const rawReason = args.join(' ').trim()
  const reason = (rawReason || 'sedang istirahat').slice(0, MAX_REASON)

  setAfk(jid, reason)

  return sendBranded(sock, jid, afkOnText(getAfk(jid)))
}
