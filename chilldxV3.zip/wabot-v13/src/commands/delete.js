import { getContextInfo, getReplyTargetCandidates, isGroupJid } from '../utils/message.js'
import { wasSentByBot } from '../utils/self.js'

/**
 * ─── !del <reply pesan> ──────────────────────────────────────────────────────
 *
 *  • Reply pesan bot / pesan sendiri
 *      → hapus untuk SEMUA orang (delete for everyone).
 *  • Reply pesan orang lain DI GRUP + bot jadi admin
 *      → hapus untuk SEMUA orang.
 *  • Reply pesan orang lain di grup, bot BUKAN admin
 *      → info: jadiin bot admin dulu.
 *  • Reply pesan orang lain di chat pribadi
 *      → tidak bisa (batasan WhatsApp, bukan bug bot).
 *
 * Sukses = tanpa pesan konfirmasi (pesannya hilang = buktinya).
 * Gagal / tidak bisa = info singkat & jelas, tidak ada fallback deleteForMe
 * yang diam-diam gagal karena salah timestamp.
 */

function sameUser(a, b) {
  if (!a || !b) return false
  return String(a).split('@')[0].split(':')[0] === String(b).split('@')[0].split(':')[0] &&
    String(a).includes('@') && String(b).includes('@') &&
    (String(a).split('@')[1] === String(b).split('@')[1])
}

function selfJids(sock) {
  return [
    sock?.user?.id,
    sock?.user?.lid,
    sock?.user?.phoneNumber
  ].filter(Boolean)
}

function isSelfParticipant(sock, candidates) {
  const me = selfJids(sock)
  return candidates.some(candidate => me.some(owner => sameUser(candidate, owner)))
}

async function isBotGroupAdmin(sock, groupJid) {
  try {
    const meta = await Promise.race([
      sock.groupMetadata(groupJid),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error('timeout')), 5000)
      )
    ])
    const me = selfJids(sock)
    const self = (meta?.participants || []).find(p =>
      me.some(owner => sameUser(p.id, owner)) ||
      me.some(owner => sameUser(p.phoneNumber, owner)) ||
      me.some(owner => sameUser(p.jid, owner))
    )
    return self?.admin === 'admin' || self?.admin === 'superadmin'
  } catch {
    return false
  }
}

export async function handleDelete(sock, jid, message, rawMsg) {
  const ctx = getContextInfo(message)

  // Belum reply ke pesan manapun
  if (!ctx?.quotedMessage || !ctx?.stanzaId) {
    return sock.sendMessage(jid, {
      text: '*DEL*\nReply pesan yang mau dihapus, lalu ketik command ini.'
    })
  }

  const inGroup = isGroupJid(jid)
  const replyCandidates = getReplyTargetCandidates(message)

  // Baileys biasanya mengisi contextInfo.participant saat sebuah pesan direply.
  // Pada versi/addressing tertentu bisa muncul participantAlt/participantPn.
  // Hanya pesan yang benar-benar teridentifikasi sebagai milik kita yang boleh
  // memakai fromMe=true. Fallback registry dipakai khusus untuk echo pesan bot.
  const fromMe = replyCandidates.length
    ? isSelfParticipant(sock, replyCandidates)
    : (!inGroup && wasSentByBot(ctx.stanzaId))

  // Bangun key delete berdasarkan participant yang diterima WhatsApp. Simpan
  // alternate participant juga bila tersedia agar kompatibel PN/LID.
  const key = {
    remoteJid: jid,
    id:        ctx.stanzaId,
    fromMe,
    ...(inGroup && ctx.participant ? { participant: ctx.participant } : {}),
    ...(inGroup && ctx.participantAlt ? { participantAlt: ctx.participantAlt } : {})
  }

  // ── Case 1: Pesan sendiri — selalu bisa hapus untuk semua ──────────────────
  if (fromMe) {
    try {
      await sock.sendMessage(jid, { delete: key })
      return // sukses, tanpa konfirmasi
    } catch (err) {
      return sock.sendMessage(jid, {
        text: `*DEL GAGAL*\n${err?.message || 'Pesan tidak bisa dihapus.'}`
      })
    }
  }

  // ── Case 2: Pesan orang lain di grup — perlu bot jadi admin ────────────────
  if (inGroup) {
    const isAdmin = await isBotGroupAdmin(sock, jid)

    if (!isAdmin) {
      return sock.sendMessage(jid, {
        text: [
          '*DEL — PERLU ADMIN*',
          '',
          'Untuk hapus pesan orang lain di grup,',
          'jadiin nomor ini *admin grup* dulu.'
        ].join('\n')
      })
    }

    try {
      await sock.sendMessage(jid, { delete: key })
      return // sukses
    } catch (err) {
      return sock.sendMessage(jid, {
        text: `*DEL GAGAL*\n${err?.message || 'Pesan tidak bisa dihapus.'}`
      })
    }
  }

  // ── Case 3: Pesan orang lain di chat pribadi — tidak bisa ─────────────────
  return sock.sendMessage(jid, {
    text: [
      '*DEL — TIDAK BISA*',
      '',
      '_Pesan orang lain di chat pribadi memang tidak bisa',
      'dihapus untuk semua orang — batasan WhatsApp._'
    ].join('\n')
  })
}
