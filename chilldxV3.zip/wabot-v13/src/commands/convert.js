import fs from 'node:fs/promises'
import { getQuotedMessage } from '../utils/message.js'
import { downloadQuotedMedia, videoToAudio, videoToGif } from '../services/media.js'
import { sendBranded } from '../services/banner.js'
import { settings } from '../../settings.js'

export async function handleConvert(sock, jid, message, args = []) {
  const mode = String(args[0] || '').toLowerCase()
  const supported = new Set(['mp3', 'audio', 'gif'])
  if (!supported.has(mode)) {
    return sendBranded(sock, jid, [
      '*CONVERT*',
      '',
      `Reply video/audio lalu gunakan *${settings.prefix}convert mp3*`,
      `Reply video lalu gunakan *${settings.prefix}convert gif*`,
      '',
      'Image ke sticker tetap memakai !s.'
    ].join('\n'))
  }

  const quoted = getQuotedMessage(message)
  if (!quoted) return sendBranded(sock, jid, '*CONVERT*\nReply media yang ingin diproses.')

  await sendBranded(sock, jid, `*MEMPROSES CONVERT*\nMode: \`${mode}\``)

  let media = null
  try {
    media = await downloadQuotedMedia(quoted)
    if (!media) throw new Error('Media tidak didukung. Gunakan video atau audio.')

    if (mode === 'mp3' || mode === 'audio') {
      const file = await videoToAudio(media.buffer, media.mime)
      try {
        return await sock.sendMessage(jid, {
          audio: { url: file },
          mimetype: 'audio/mpeg',
          fileName: 'converted.mp3'
        })
      } finally {
        await fs.rm(file, { force: true }).catch(() => {})
      }
    }

    const file = await videoToGif(media.buffer)
    try {
      return await sock.sendMessage(jid, {
        video: { url: file },
        mimetype: 'video/mp4',
        gifPlayback: true,
        caption: '*CONVERT SELESAI*'
      })
    } finally {
      await fs.rm(file, { force: true }).catch(() => {})
    }
  } catch (error) {
    return sendBranded(sock, jid, `*CONVERT GAGAL*\n\n${error.message || 'Media gagal diproses.'}`)
  }
}
