import fs from 'node:fs/promises'
import fsSync from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { settings } from '../../settings.js'
import { statsStore } from '../database.js'
import { sendBranded } from '../services/banner.js'
import { formatBytes } from '../utils/message.js'

async function directoryBytes(dir) {
  let total = 0
  const stack = [dir]
  while (stack.length) {
    const current = stack.pop()
    let entries = []
    try { entries = await fs.readdir(current, { withFileTypes: true }) } catch { continue }
    for (const entry of entries) {
      const full = path.join(current, entry.name)
      if (entry.isDirectory()) stack.push(full)
      else {
        try { total += (await fs.stat(full)).size } catch {}
      }
    }
  }
  return total
}

function formatDuration(seconds) {
  const s = Math.max(0, Math.floor(seconds))
  const d = Math.floor(s / 86400)
  const h = Math.floor((s % 86400) / 3600)
  const m = Math.floor((s % 3600) / 60)
  const sec = s % 60
  return `${d}d ${h}h ${m}m ${sec}s`
}

export async function handleStatus(sock, jid) {
  const [tempBytes, dataBytes] = await Promise.all([
    directoryBytes(settings.tempDir),
    directoryBytes(settings.dataDir)
  ])
  const mem = process.memoryUsage()
  const rss = mem.rss
  const heap = mem.heapUsed
  const load = os.loadavg?.()[0]
  const free = os.freemem()
  const total = os.totalmem()

  const text = [
    '╭──────────〔 STATUS 〕',
    `│ Uptime   : \`${formatDuration(process.uptime())}\``,
    `│ Node     : \`${process.version}\``,
    `│ Platform : \`${process.platform}/${process.arch}\``,
    `│ Memory   : \`${formatBytes(rss)} RSS / ${formatBytes(heap)} heap\``,
    `│ System   : \`${formatBytes(free)} free / ${formatBytes(total)} total\``,
    `│ Load     : \`${Number.isFinite(load) ? load.toFixed(2) : 'n/a'}\``,
    `│ Temp     : \`${formatBytes(tempBytes)}\``,
    `│ Data     : \`${formatBytes(dataBytes)}\``,
    `│ Commands : \`${statsStore.get('commands_total')}\``,
    `│ Download : \`${statsStore.get('download_video')} video / ${statsStore.get('download_audio')} audio\``,
    `│ Sticker  : \`${statsStore.get('sticker')}\``,
    `│ Search   : \`${statsStore.get('search')}\``,
    '╰────────────────────────',
    '',
    'Owner dashboard. Dipakai untuk memantau kondisi runtime sebelum error menyebar.'
  ].join('\n')

  return sendBranded(sock, jid, text)
}

export function statusSummary() {
  return {
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    tempExists: fsSync.existsSync(settings.tempDir)
  }
}
