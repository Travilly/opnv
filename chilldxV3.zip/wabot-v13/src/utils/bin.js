import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { spawn, execFileSync } from 'node:child_process'
import { settings } from '../../settings.js'

// ─── ffmpeg ───────────────────────────────────────────────────────────────────
// Dependency npm `ffmpeg-static` mendownload binary ffmpeg sendiri saat
// `npm install` (lihat package.json -> allowScripts). Kalau karena suatu sebab
// gagal ke-resolve, fallback ke command PATH biasa (kalau-kalau custom egg-nya
// kebetulan sudah menyediakan ffmpeg sendiri).
let ffmpegStaticPath = null
try {
  const mod = await import('ffmpeg-static')
  ffmpegStaticPath = (mod?.default || mod) ?? null
} catch {
  ffmpegStaticPath = null
}

export const ffmpegPath = (ffmpegStaticPath && fs.existsSync(ffmpegStaticPath))
  ? ffmpegStaticPath
  : 'ffmpeg'

export const usingLocalFfmpeg = ffmpegPath !== 'ffmpeg'

// ─── yt-dlp ───────────────────────────────────────────────────────────────────
// TIDAK lagi lewat "postinstall" npm -- npm versi baru bisa BLOKIR install
// script dependency pihak ketiga secara default (persis yang bikin ffmpeg-static
// gagal, lihat package.json). Supaya yt-dlp tidak kena masalah yang sama, kode
// di bawah ini men-download binary standalone-nya sendiri saat PERTAMA KALI
// dibutuhkan (dipanggil dari ensureDownloader() di downloader.js) -- ini kode
// aplikasi biasa, bukan install script siapa pun, jadi tidak pernah diblokir.
const BIN_DIR      = path.join(settings.root, 'bin')
const YT_DLP_LOCAL = path.join(BIN_DIR, 'yt-dlp')
const RELEASE_BASE = 'https://github.com/yt-dlp/yt-dlp/releases/latest/download'

function isMusl() {
  try {
    if (fs.existsSync('/etc/alpine-release')) return true
  } catch {}
  try {
    const report = process.report?.getReport?.()
    if (report?.header && !report.header.glibcVersionRuntime) return true
  } catch {}
  return false
}

function pickAsset() {
  const arch = os.arch()
  const musl = isMusl()
  if (arch === 'x64')   return musl ? 'yt-dlp_musllinux' : 'yt-dlp'
  if (arch === 'arm64') return musl ? 'yt-dlp_musllinux_aarch64' : 'yt-dlp_linux_aarch64'
  return null // arsitektur tanpa binary standalone resmi (mis. armv7)
}

function isValidBinary(target) {
  if (!fs.existsSync(target)) return false
  try {
    const stat = fs.statSync(target)
    if (stat.size < 1_000_000) return false // file korup/kosong
    execFileSync(target, ['--version'], { stdio: 'ignore', timeout: 10_000 })
    return true
  } catch {
    return false
  }
}

function systemYtDlpAvailable() {
  return new Promise(resolve => {
    try {
      const child = spawn('yt-dlp', ['--version'], { stdio: 'ignore' })
      child.on('error', () => resolve(false))
      child.on('exit', code => resolve(code === 0))
    } catch {
      resolve(false)
    }
  })
}

async function downloadYtDlp() {
  const asset = pickAsset()
  if (!asset) {
    throw new Error(`Arsitektur "${os.arch()}" tidak punya binary standalone yt-dlp resmi. Install manual lalu pastikan ada di PATH container.`)
  }

  const url = `${RELEASE_BASE}/${asset}`
  const res = await fetch(url, { redirect: 'follow' })
  if (!res.ok || !res.body) {
    throw new Error(`Gagal download yt-dlp dari GitHub Releases (HTTP ${res.status}). Cek akses internet keluar dari container.`)
  }

  const buffer = Buffer.from(await res.arrayBuffer())
  if (buffer.length < 1_000_000) {
    throw new Error(`File yt-dlp hasil download mencurigakan (${buffer.length} bytes), dibatalkan.`)
  }

  fs.mkdirSync(BIN_DIR, { recursive: true })
  fs.writeFileSync(YT_DLP_LOCAL, buffer)
  fs.chmodSync(YT_DLP_LOCAL, 0o755)

  if (!isValidBinary(YT_DLP_LOCAL)) {
    throw new Error('yt-dlp sudah terdownload tapi gagal dijalankan (--version error).')
  }
}

let resolvedYtDlpPath = null
let pendingEnsure     = null

/**
 * Pastikan yt-dlp siap dipakai, resolve ke path yang valid.
 * Idempotent & aman dipanggil bersamaan (concurrent call menunggu proses yang
 * sama, tidak trigger download dobel). Urutan: binary lokal valid -> yt-dlp
 * sistem di PATH -> download binary standalone dari GitHub Releases.
 */
export function ensureYtDlp() {
  if (resolvedYtDlpPath) return Promise.resolve(resolvedYtDlpPath)
  if (pendingEnsure) return pendingEnsure

  pendingEnsure = (async () => {
    if (isValidBinary(YT_DLP_LOCAL)) {
      resolvedYtDlpPath = YT_DLP_LOCAL
      return resolvedYtDlpPath
    }

    if (await systemYtDlpAvailable()) {
      resolvedYtDlpPath = 'yt-dlp'
      return resolvedYtDlpPath
    }

    await downloadYtDlp()
    resolvedYtDlpPath = YT_DLP_LOCAL
    return resolvedYtDlpPath
  })().finally(() => {
    pendingEnsure = null
  })

  return pendingEnsure
}

// ─── Cek ffmpeg benar-benar bisa dijalankan ───────────────────────────────────
// `ffmpeg-static` sering gagal (npm memblokir install script, atau binary-nya
// tidak cocok dengan container). Dulu itu bikin SEMUA download gagal dengan
// pesan "ffmpeg belum tersedia". Sekarang bot cuma perlu tahu ada/tidaknya,
// lalu downloader otomatis pindah ke mode tanpa ffmpeg.
let ffmpegCheck = null

export function hasFfmpeg() {
  if (ffmpegCheck) return ffmpegCheck
  ffmpegCheck = new Promise(resolve => {
    try {
      const child = spawn(ffmpegPath, ['-version'], { stdio: 'ignore' })
      child.on('error', () => resolve(false))
      child.on('exit', code => resolve(code === 0))
      setTimeout(() => resolve(false), 10_000)
    } catch {
      resolve(false)
    }
  })
  return ffmpegCheck
}

// ─── Pembersih output subprocess (yt-dlp / ffmpeg) ────────────────────────────
// stderr yt-dlp/ffmpeg mentah bisa berisi ANSI escape code (warna/cursor) dan
// baris progress yang ditumpuk pakai '\r' tanpa newline (ffmpeg apalagi —
// "frame=... fps=... size=..." nimpa diri sendiri berkali-kali). Kalau ini
// di-slice mentah lalu langsung dibungkus ke pesan Error, hasilnya bisa
// kepotong di tengah escape sequence / baris progress dan tampil sebagai
// teks acak — baik di console Pterodactyl (via logger.error) maupun di
// pesan error yang dikirim balik ke WhatsApp. Fungsi ini strip ANSI +
// karakter kontrol, buang baris kosong, lalu ambil beberapa baris TEKS
// terakhir saja supaya yang tersisa benar-benar bisa dibaca.
export function cleanProcessOutput(raw, maxLen = 500) {
  const stripped = String(raw || '')
    .replace(/\x1b\[[0-9;]*[a-zA-Z]/g, '') // ANSI escape code (warna, cursor movement)
    .replace(/[\x00-\x09\x0B-\x1F\x7F]/g, '\n') // karakter kontrol lain (termasuk \r progress bar) -> pemisah baris
  const lines = stripped.split('\n').map(l => l.trim()).filter(Boolean)
  if (!lines.length) return 'Tidak ada detail dari proses (exit tanpa output).'
  const tail = lines.slice(-6).join('\n')
  return tail.length > maxLen ? tail.slice(-maxLen) : tail
}
