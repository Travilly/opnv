export function jidNumber(jid = '') {
  return String(jid).split('@')[0].split(':')[0]
}

export function normalizeJid(jid = '') {
  const value = String(jid || '')
  if (!value) return ''
  return value.includes('@')
    ? `${value.split('@')[0]}@${value.split('@')[1]}`
    : `${jidNumber(value)}@s.whatsapp.net`
}

export function messageText(message = {}) {
  return (
    message.conversation ||
    message.extendedTextMessage?.text ||
    message.imageMessage?.caption ||
    message.videoMessage?.caption ||
    message.documentMessage?.caption ||
    message.buttonsResponseMessage?.selectedButtonId ||
    message.listResponseMessage?.singleSelectReply?.selectedRowId ||
    message.templateButtonReplyMessage?.selectedId ||
    message.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson ||
    ''
  ).trim()
}

export function unwrapMessage(message = {}) {
  return message?.ephemeralMessage?.message ||
    message?.viewOnceMessage?.message ||
    message?.viewOnceMessageV2?.message ||
    message?.viewOnceMessageV2Extension?.message ||
    message?.documentWithCaptionMessage?.message ||
    message
}

export function getQuotedMessage(message = {}) {
  return message?.extendedTextMessage?.contextInfo?.quotedMessage ||
    message?.imageMessage?.contextInfo?.quotedMessage ||
    message?.videoMessage?.contextInfo?.quotedMessage ||
    message?.documentMessage?.contextInfo?.quotedMessage ||
    message?.stickerMessage?.contextInfo?.quotedMessage ||
    message?.audioMessage?.contextInfo?.quotedMessage ||
    null
}

export function getSenderJid(msg) {
  return (
    msg?.key?.participantAlt ||
    msg?.key?.participant ||
    msg?.key?.remoteJidAlt ||
    msg?.key?.remoteJid ||
    ''
  )
}

export function getSenderCandidates(msg) {
  return [
    msg?.key?.participant,
    msg?.key?.participantAlt,
    msg?.key?.remoteJid,
    msg?.key?.remoteJidAlt
  ].filter(Boolean)
}

export function isGroupJid(jid = '') {
  return String(jid).endsWith('@g.us')
}

export function getContextInfo(message = {}) {
  return (
    message?.extendedTextMessage?.contextInfo ||
    message?.imageMessage?.contextInfo ||
    message?.videoMessage?.contextInfo ||
    message?.documentMessage?.contextInfo ||
    message?.stickerMessage?.contextInfo ||
    message?.audioMessage?.contextInfo ||
    null
  )
}

export function getMentionedJids(message = {}) {
  return getContextInfo(message)?.mentionedJid || []
}

export function getReplyTargetJid(message = {}) {
  const ctx = getContextInfo(message)
  return ctx?.participant || ctx?.participantAlt || ctx?.participantPn || ''
}

export function getReplyTargetCandidates(message = {}) {
  const ctx = getContextInfo(message) || {}
  return [
    ctx.participant,
    ctx.participantAlt,
    ctx.participantPn
  ].filter(Boolean)
}

export function parseCommand(text, prefix = '!') {
  if (!text.startsWith(prefix)) return null
  const body = text.slice(prefix.length).trim()
  if (!body) return null

  const parts = body.split(/\s+/)

  return {
    command: parts.shift().toLowerCase(),
    args: parts,
    rawArgs: parts.join(' ')
  }
}

export function formatBytes(bytes = 0) {
  if (!bytes) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  const i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1)
  return `${(bytes / 1024 ** i).toFixed(i === 0 ? 0 : 2)} ${units[i]}`
}
