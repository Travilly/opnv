import pino from 'pino'
import chalk from 'chalk'
import { settings } from '../../settings.js'

/**
 * DUA logger berbeda:
 *
 * 1. `waLogger`  -> dipakai Baileys. Default level 'silent' supaya console
 *    Pterodactyl TIDAK dispam JSON internal WA (pkmsg, app state sync,
 *    "error in handling message", presence update, dsb) — ini sumber
 *    "random string" yang dulu muncul di panel.
 *
 * 2. `logger` / `ui` -> log bot sendiri, output plain text rapi (bukan JSON),
 *    hanya info penting: pairing code, connected, disconnect, error fatal.
 *
 * 3. `ui.chatLog` -> chat log gaya bot teman (alya.js): kotak GROUP/PRIVATE
 *    dengan warna chalk. Bisa dimatikan via settings.chatLogEnabled.
 */

export const waLogger = pino({ level: settings.waLogLevel || 'silent' })

const LEVELS = { debug: 10, info: 20, warn: 30, error: 40, silent: 99 }
const threshold = LEVELS[settings.logLevel] ?? LEVELS.info

function chatTimestamp() {
  return new Date().toISOString().slice(0, 19).replace('T', ' ')
}

function clip(text, max = 120) {
  const value = String(text || '')
  return value.length > max ? `${value.slice(0, max)}…` : value
}

// Tema warna per level — supaya SELURUH console konsisten (dulu cuma
// chatLog yang berwarna, sisanya (startup/connect/error) polos hitam-putih).
const STYLE = {
  debug: { tag: chalk.gray, text: chalk.gray },
  info:  { tag: chalk.cyanBright, text: chalk.white },
  warn:  { tag: chalk.yellowBright.bold, text: chalk.yellowBright },
  error: { tag: chalk.redBright.bold, text: chalk.redBright },
  ok:    { tag: chalk.greenBright.bold, text: chalk.greenBright }
}

function out(level, tag, lines) {
  if ((LEVELS[level === 'ok' ? 'info' : level] ?? 20) < threshold) return
  const text  = Array.isArray(lines) ? lines.join('\n') : String(lines)
  const style = STYLE[level] || STYLE.info
  const stream = level === 'error' ? process.stderr : process.stdout
  stream.write(`${style.tag(tag)} ${style.text(text)}\n`)
}

/** UI console bersih untuk Pterodactyl */
export const ui = {
  info: (msg) => out('info', '›', msg),
  ok: (msg) => out('ok', '✓', msg),
  warn: (msg) => out('warn', '!', msg),
  error: (msg) => out('error', '✗', msg),
  raw: (msg) => process.stdout.write(`${Array.isArray(msg) ? msg.join('\n') : msg}\n`),
  // `color` = fungsi chalk untuk border+title (default cyan, senada tema info).
  // Padding dihitung dari teks MENTAH dulu (title/rows belum diwarnai) baru
  // dibungkus chalk paling akhir — supaya kode warna ANSI (yang invisible
  // tapi tetap dihitung karakter kalau taruh sebelum padEnd) tidak bikin
  // box-nya miring/kepanjangan.
  box: (title, rows, color = chalk.cyanBright) => {
    const width = Math.max(title.length, ...rows.map((r) => r.length)) + 4
    const line = '─'.repeat(width)
    const border = (s) => color(s)
    process.stdout.write(
      [
        '',
        border(`┌${line}┐`),
        `${border('│')}  ${chalk.bold.whiteBright(title.padEnd(width - 2))}${border('│')}`,
        border(`├${line}┤`),
        ...rows.map((r) => `${border('│')}  ${chalk.whiteBright(r.padEnd(width - 2))}${border('│')}`),
        border(`└${line}┘`),
        ''
      ].join('\n') + '\n'
    )
  },

  /**
   * Chat log — box keren dengan chalk truecolor + emoji + command detector.
   *
   * GROUP  : border cyan    ╔═══╗  header bold bgCyan
   * PRIVATE: border magenta ╭───╯  header bold bgMagenta
   * Command (starts with prefix): row kuning + tag [CMD]
   */
  chatLog: ({ isGroup, message, senderName, senderJid, groupName, chatJid }) => {
    if (settings.chatLogEnabled === false) return

    const pfx    = settings.prefix || '!'
    const msgStr = String(message || '')
    const isCmd  = msgStr.startsWith(pfx)

    const time   = chalk.gray(chatTimestamp())
    const body   = isCmd
      ? chalk.yellowBright.bold(`⚡ ${clip(msgStr)}`) + ' ' + chalk.bgYellow.black(' CMD ')
      : chalk.whiteBright(clip(msgStr))
    const name   = chalk.bold(senderName || 'Unknown')
    const jidFmt = chalk.gray(senderJid || '-')

    if (isGroup) {
      const C = chalk.cyanBright
      const label  = chalk.bgCyan.black.bold(' 🌐 GROUP ')
      const grpTxt = chalk.greenBright.bold(clip(groupName || '-', 40))
      const grpJid = chalk.gray(chatJid || '-')
      process.stdout.write([
        C('╔══') + label + C('══════════════════════════════════════'),
        C('║') + '  🕒 ' + time,
        C('║') + '  💬 ' + body,
        C('║') + '  👤 ' + chalk.cyanBright(name) + '  ' + jidFmt,
        C('║') + '  🏠 ' + grpTxt + '  ' + grpJid,
        C('╚' + '═'.repeat(54)),
        ''
      ].join('\n'))
    } else {
      const C = chalk.magentaBright
      const label = chalk.bgMagenta.white.bold(' 💬 PRIVATE ')
      process.stdout.write([
        C('╭──') + label + C('────────────────────────────────────'),
        C('│') + '  🕒 ' + time,
        C('│') + '  ' + (isCmd ? '⚡' : '📨') + '  ' + body,
        C('│') + '  👤 ' + chalk.magentaBright(name) + '  ' + jidFmt,
        C('╰' + '─'.repeat(54)),
        ''
      ].join('\n'))
    }
  }
}

/**
 * Kompatibilitas: modul lain masih memanggil logger.info({...}, 'msg').
 * Signature pino tetap diterima, tapi output-nya plain text.
 */
function normalize(a, b) {
  if (typeof a === 'string') return a
  if (typeof b === 'string') {
    const err = a?.err || a?.error
    return err ? `${b} — ${err.message || err}` : b
  }
  const err = a?.err || a?.error
  return err ? err.message || String(err) : ''
}

export const logger = {
  debug: (a, b) => out('debug', '·', normalize(a, b)),
  info: (a, b) => out('info', '›', normalize(a, b)),
  warn: (a, b) => out('warn', '!', normalize(a, b)),
  error: (a, b) => out('error', '✗', normalize(a, b)),
  fatal: (a, b) => out('error', '✗', normalize(a, b)),
  trace: () => {},
  child: () => logger,
  level: settings.logLevel
}
