import { settings } from '../../settings.js'

/**
 * Tempelkan nama pack / author ke file .webp sticker.
 * node-webpmux = pure JS (tidak ada native binding), tapi kalau paketnya belum
 * terpasang di panel, fungsi ini diam-diam mengembalikan buffer aslinya —
 * sticker tetap terkirim, cuma tanpa label pack. Tidak pernah bikin bot mati.
 */
let webpmux = null
let loaded  = false

async function loadWebpmux() {
  if (loaded) return webpmux
  loaded = true
  try {
    webpmux = (await import('node-webpmux')).default
  } catch {
    webpmux = null
  }
  return webpmux
}

function buildExif(packName, authorName) {
  const json = JSON.stringify({
    'sticker-pack-id':        'private-wa-toolbot',
    'sticker-pack-name':      packName,
    'sticker-pack-publisher': authorName,
    emojis:                   ['✨']
  })

  const head = Buffer.from([
    0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00,
    0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00,
    0x00, 0x00
  ])
  const payload = Buffer.from(json, 'utf8')
  head.writeUIntLE(payload.length, 14, 4)
  return Buffer.concat([head, payload])
}

export async function attachStickerMetadata(buffer, description = '') {
  const mux = await loadWebpmux()
  if (!mux) return buffer

  try {
    const pack   = (description || '').trim().slice(0, 60) || settings.stickerPackName
    const author = settings.stickerAuthorName

    const img = new mux.Image()
    await img.load(buffer)
    img.exif = buildExif(pack, author)
    return await img.save(null)
  } catch {
    return buffer
  }
}
