/**
 * ─── REGISTRY PESAN KELUARAN BOT ─────────────────────────────────────────────
 * Bot jalan di nomor SAMA dengan owner, jadi setiap pesan yang bot kirim
 * balik lagi ke `messages.upsert` sebagai `key.fromMe = true`.
 *
 * Solusi: catat id setiap pesan yang bot kirim. Saat echo balik, id ketemu
 * → pesan diabaikan total. Auto-reply tidak membunuh sesi AFK sendiri.
 */

const ids = new Map()
const TTL = 10 * 60 * 1000   // 10 menit
const MAX = 500

function sweep() {
  const now = Date.now()
  for (const [id, ts] of ids) {
    if (now - ts > TTL) ids.delete(id)
  }
  if (ids.size > MAX) {
    const excess = ids.size - MAX
    let i = 0
    for (const id of ids.keys()) {
      if (i++ >= excess) break
      ids.delete(id)
    }
  }
}

export function rememberBotMessage(id) {
  if (!id) return
  ids.set(String(id), Date.now())
  sweep()
}

/** true kalau id pesan ini tercatat sebagai pesan yang bot kirim. */
export function wasSentByBot(id) {
  return id ? ids.has(String(id)) : false
}

// Regex cadangan kalau id pesan tidak sempat tercatat.
// Mencakup semua pola teks yang bot kirim: menu, afk, sticker, download,
// search, error — diperluas agar lebih sedikit false-positive.
const BOT_TEXT_RE = /^\s*(?:╭|╰|\*(?:MENGUNDUH MEDIA|MENGAMBIL AUDIO|DOWNLOAD GAGAL|SELESAI|Format|AFK|STICKER|SEARCH|🔍 MENCARI|📝 Ringkasan|🔍 Hasil|FORMAT PENCARIAN)\*)/

function outgoingText(msg) {
  const m = msg?.message || {}
  return (
    m.conversation              ||
    m.extendedTextMessage?.text ||
    m.videoMessage?.caption     ||
    m.imageMessage?.caption     ||
    ''
  )
}

export function isBotOwnMessage(msg) {
  const id = msg?.key?.id
  if (id && ids.has(String(id))) return true
  if (!msg?.key?.fromMe) return false
  return BOT_TEXT_RE.test(outgoingText(msg))
}

/**
 * Bungkus sock.sendMessage agar SEMUA pengiriman otomatis tercatat.
 * Tidak perlu ingat menandai satu per satu di setiap command.
 */
export function trackOutgoing(sock) {
  if (!sock || sock.__lovableTracked) return sock
  const original = sock.sendMessage.bind(sock)

  sock.sendMessage = async (...args) => {
    const sent = await original(...args)
    rememberBotMessage(sent?.key?.id)
    return sent
  }

  sock.__lovableTracked = true
  return sock
}
