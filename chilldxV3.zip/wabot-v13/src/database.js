import fs from 'node:fs'
import path from 'node:path'
import { settings } from '../settings.js'

/**
 * ─── KENAPA BUKAN better-sqlite3 LAGI? ───────────────────────────────────────
 * better-sqlite3 adalah native addon: dia harus di-compile / download prebuild
 * yang COCOK dengan versi Node + arsitektur + libc container. Di Pterodactyl
 * (image node alpine/musl, atau versi Node yang beda dari prebuild) ini gagal
 * dan bot mati SEBELUM konek, dengan error khas:
 *
 *   Error: Could not locate the bindings file
 *   invalid ELF header / NODE_MODULE_VERSION mismatch
 *   node-gyp ... gyp ERR! build error
 *
 * Data bot ini cuma beberapa key-value kecil (owner_jid, afk, counter), jadi
 * SQLite berlebihan. Diganti store JSON atomic tanpa dependency sama sekali —
 * nol kemungkinan gagal build di panel manapun.
 */

const FILE = path.join(settings.dataDir, 'bot.json')
const TMP  = `${FILE}.tmp`

fs.mkdirSync(settings.dataDir, { recursive: true })

function emptyState() {
  return { settings: {}, afk: {}, stats: {} }
}

function load() {
  try {
    const raw = fs.readFileSync(FILE, 'utf8')
    const parsed = JSON.parse(raw)
    return {
      settings: parsed.settings && typeof parsed.settings === 'object' ? parsed.settings : {},
      afk:      parsed.afk      && typeof parsed.afk      === 'object' ? parsed.afk      : {},
      stats:    parsed.stats    && typeof parsed.stats    === 'object' ? parsed.stats    : {}
    }
  } catch {
    return emptyState()
  }
}

const state = load()

let flushTimer = null
function persistNow() {
  try {
    fs.writeFileSync(TMP, JSON.stringify(state, null, 2))
    fs.renameSync(TMP, FILE) // atomic: file tidak pernah korup walau bot dimatikan paksa
  } catch {
    /* disk read-only / kuota habis: jangan sampai bikin bot crash */
  }
}

/** Tulis di-debounce 150ms supaya burst update tidak spam disk panel. */
function persist() {
  if (flushTimer) return
  flushTimer = setTimeout(() => {
    flushTimer = null
    persistNow()
  }, 150)
  flushTimer.unref?.()
}

export const store = {
  get(key, fallback = null) {
    const value = state.settings[key]
    return value === undefined ? fallback : value
  },
  set(key, value) {
    state.settings[key] = String(value)
    persist()
    return value
  },
  delete(key) {
    if (!(key in state.settings)) return false
    delete state.settings[key]
    persist()
    return true
  }
}

export const afkStore = {
  get(jid) {
    const entry = state.afk[jid]
    if (!entry) return null
    return { jid, since: Number(entry.since) || 0, reason: entry.reason || '' }
  },
  set(jid, since, reason = '') {
    state.afk[jid] = { since, reason }
    persist()
  },
  remove(jid) {
    if (!state.afk[jid]) return false
    delete state.afk[jid]
    persist()
    return true
  }
}

export const statsStore = {
  inc(key, amount = 1) {
    state.stats[key] = (Number(state.stats[key]) || 0) + amount
    persist()
  },
  get(key) {
    return Number(state.stats[key]) || 0
  }
}

export function closeDatabase() {
  if (flushTimer) {
    clearTimeout(flushTimer)
    flushTimer = null
  }
  persistNow()
}
